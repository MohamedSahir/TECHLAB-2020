import { HomeEffects } from './home.effects';

export const effects: any[] = [HomeEffects];

export * from './home.effects';
