export class Ingredient {
  public id: string;
  public quantity: number;
  public weight: number;
  public description: string;
}
