import { CoreEffects } from './core.effects';

export const effects: any[] = [CoreEffects];

export * from './core.effects';
