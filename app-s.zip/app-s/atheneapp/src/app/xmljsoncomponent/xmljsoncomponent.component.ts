import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-xmljsoncomponent',
  templateUrl: './xmljsoncomponent.component.html',
  styleUrls: ['./xmljsoncomponent.component.scss']
})
export class XmljsoncomponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
