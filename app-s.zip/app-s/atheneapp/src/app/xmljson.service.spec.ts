import { TestBed } from '@angular/core/testing';

import { XmljsonService } from './xmljson.service';

describe('XmljsonService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: XmljsonService = TestBed.get(XmljsonService);
    expect(service).toBeTruthy();
  });
});
