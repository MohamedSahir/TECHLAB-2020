import { Component,OnInit } from '@angular/core';
import{XmljsonService} from './xmljson.service'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent  implements OnInit{
  constructor(private xmljsonService: XmljsonService){


  }
  title = 'atheneapp';
name:string;
  ngOnInit(){
    this.name = this.xmljsonService.getName();


 

  }
}
