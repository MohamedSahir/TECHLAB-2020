import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class XmljsonService {

  constructor() { }





getName():string{
  return "saahir";
}

  xmlreport(xmls){


  let oParser = new DOMParser();
  var xml = oParser.parseFromString(xmls, "text/xml");
  this.xmlToJson(xml);
  }
  // Changes XML to JSON
xmlToJson(xml) {


    // Create the return object
    var obj = {};
  
    if (xml.nodeType == 1) { // element
      // do attributes
      if (xml.attributes.length > 0) {
        //obj["attributes"] = {};
        for (var j = 0; j < xml.attributes.length; j++) {
          var attribute = xml.attributes.item(j);
          //obj["attributes"][attribute.nodeName] = attribute.nodeValue;
          obj['@' + attribute.nodeName] = attribute.nodeValue;
        }
      }
    } else if (xml.nodeType == 3) { // text
      obj = xml.nodeValue.trim(); // add trim here
    }
  
    // do children
    if (xml.hasChildNodes()) {
      for (var i = 0; i < xml.childNodes.length; i++) {
        var tmp;
        var item = xml.childNodes.item(i);
        var nodeName = item.nodeName;
        // 	console.debug('child',nodeName,item)
        if (typeof(obj[nodeName]) == "undefined") {
          tmp = this.xmlToJson(item);
          if (tmp !== "") // if not empty string
            obj[nodeName] = tmp;
        } else {
          if (typeof(obj[nodeName].push) == "undefined") {
            var old = obj[nodeName];
            obj[nodeName] = [];
            obj[nodeName].push(old);
          }
          tmp = this.xmlToJson(item);
          if (tmp !== "") // if not empty string
            obj[nodeName].push(tmp);
        }
      }
    }
    if (!Array.isArray(obj) && typeof obj == 'object') {
      var keys = Object.keys(obj);
      if (keys.length == 1 && keys[0] == '#text') return obj['#text'];
      if (keys.length === 0) return null;
    }
    return obj;
  }
  

 


}
