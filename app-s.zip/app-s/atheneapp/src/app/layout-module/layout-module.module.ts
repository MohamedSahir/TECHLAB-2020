import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {FooterComponent,SidebarComponent,TopbarComponent} from './index';
import { RouterModule } from '@angular/router';
import { layoutRoutes } from './layout.routing';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LayoutComponent } from './layout/layout.component';



@NgModule({
  declarations: [ FooterComponent,
    SidebarComponent,
    TopbarComponent,
    DashboardComponent,
    LayoutComponent
  ],
  
  imports: [
    CommonModule,
    RouterModule.forChild(layoutRoutes),
  ]
})
export class LayoutmoduleModule { }
