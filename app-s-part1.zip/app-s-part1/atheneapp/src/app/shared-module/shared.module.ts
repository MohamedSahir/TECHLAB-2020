import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
// import { LayoutComponent } from '../layout-module/layout/layout.component';
import { LayoutmoduleModule } from '../layout-module/layout-module.module';
import { CoreModuleModule } from '../core-module/core-module.module';


@NgModule({
  imports: [
    // Modules
    CommonModule,
    RouterModule,
    LayoutmoduleModule,
    CoreModuleModule
  ],

  declarations: [
    // Components & directives
    
  ],

  providers: [
    // Services
 
  ],

  exports: [LayoutmoduleModule,CoreModuleModule],
})
export class SharedModule {}
