import { Routes } from '@angular/router';
import { CoreModuleComponent } from './core-module.component';
// import{ LayoutComponent } from './layout/layout.component';

export const coreRoutes: Routes = [
  {
    path: '',
    component: CoreModuleComponent
  }
];
