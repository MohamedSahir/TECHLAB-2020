import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { coreRoutes } from './core.routing';
import { CoreModuleComponent } from './core-module.component';



@NgModule({
  declarations: [CoreModuleComponent],
  imports: [
    CommonModule,
    RouterModule.forChild( coreRoutes),
  ]
})
export class CoreModuleModule { }
