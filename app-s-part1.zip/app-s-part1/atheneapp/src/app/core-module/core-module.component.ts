import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-core-module',
  templateUrl: './core-module.component.html',
  styleUrls: ['./core-module.component.scss']
})
export class CoreModuleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
