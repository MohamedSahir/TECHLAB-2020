import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { LayoutmoduleModule } from './layout-module/layout-module.module';

import { AppComponent } from './app.component';

import { XmljsoncomponentComponent } from './xmljsoncomponent/xmljsoncomponent.component';
import { SharedModule } from './shared-module/shared.module';



@NgModule({
  declarations: [
    AppComponent,
  
    XmljsoncomponentComponent,
  
   
  ],
  imports: [
    BrowserModule,
    
    AppRoutingModule,
    SharedModule
 
    // LayoutmoduleModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
