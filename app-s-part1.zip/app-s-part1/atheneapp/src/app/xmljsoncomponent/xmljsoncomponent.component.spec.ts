import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { XmljsoncomponentComponent } from './xmljsoncomponent.component';

describe('XmljsoncomponentComponent', () => {
  let component: XmljsoncomponentComponent;
  let fixture: ComponentFixture<XmljsoncomponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ XmljsoncomponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(XmljsoncomponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
