import { ModuleWithProviders } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NotProdGuard } from '@transom/guards';
import {
  AddDriverGuard,
  DQDriverQueryViewGuard,
  DriverCalendarGuard,
  DriverProfileQueryGuard,
  NotCertGuard,
  OBCMessageQueryGuard,
  OBCSendMessageGuard,
  OfficeCalendarGuard
} from './common/guards';
import { DQDriverQueryComponent } from './driver-management/dq-driver-query/dq-driver-query.component';
import { DriverCalendarViewComponent } from './driver-management/driver-calendar-view/driver-calendar-view.component';
import { AddDriverComponent } from './driver-management/driver-profile/add-driver/add-driver.component';
import { DriverQueryComponent } from './driver-management/driver-query/driver-query.component';
import { OfficeCalendarComponent } from './driver-management/office-calendar/office-calendar.component';
import { DriverRootComponent } from './driver-root/driver-root.component';
import { MessageQueryCompositeViewComponent } from './messaging/obc-message-query/obc-message-query-composite.component';
import { SendMessageComponent } from './messaging/obc-send-message/obc-send-message.component';
const appRoutes: Routes = [
  {
    path: '',
    component: DriverRootComponent,
    children: [
      {
        path: 'Message_Management',
        children: [
          {
            path: 'Send_Message',
            canActivate: [OBCSendMessageGuard],
            component: SendMessageComponent
          },
          {
            path: 'Message_Query',
            canActivate: [OBCMessageQueryGuard],
            component: MessageQueryCompositeViewComponent
          }
        ]
      },
      {
        path: 'Driver_Management',
        children: [
          {
            path: 'Driver_Query',
            canActivate: [DriverProfileQueryGuard, NotProdGuard],
            component: DriverQueryComponent
          },
          {
            path: 'Add_Driver',
            canActivate: [AddDriverGuard, NotProdGuard, NotCertGuard],
            component: AddDriverComponent
          },
          {
            path: 'DQ - Driver_Query',
            canActivate: [DQDriverQueryViewGuard, NotProdGuard],
            component: DQDriverQueryComponent
          },
          {
            path: 'Driver_Calendar',
            canActivate: [DriverCalendarGuard, NotProdGuard, NotCertGuard],
            component: DriverCalendarViewComponent
          },
          {
            path: 'Office_Calendar',
            canActivate: [OfficeCalendarGuard, NotProdGuard, NotCertGuard],
            component: OfficeCalendarComponent
          }
        ]
      }
    ]
  }
];
// tslint:disable-next-line:variable-name
export const DriverRouting: ModuleWithProviders = RouterModule.forChild(appRoutes);
