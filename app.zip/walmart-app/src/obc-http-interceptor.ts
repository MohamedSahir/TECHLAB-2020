import {
    HttpEvent,
    HttpHandler,
    HttpInterceptor,
    HttpRequest
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EnvService, UserService } from '@transom/services';
import { Observable } from 'rxjs';
@Injectable()
export class OBCHttpInterceptor implements HttpInterceptor {
    constructor(private envService: EnvService, private userService: UserService) { }
    intercept(request: HttpRequest<any>, handler: HttpHandler): Observable<HttpEvent<any>> {
        request = request.clone({
            headers: request.headers.set('Accept', 'Application/json')
                .set('Accept-Language', this.envService ? this.envService.headerDefaults.acceptLanguage : 'en-US')
                .set('Content-Type', 'application/json')
                .set('countryCode', this.envService ? this.envService.market.toUpperCase() : 'US')
                .set('userId', this.userService.userId)
        });
        return handler.handle(request);
    }
}