import { DatePipe } from '@angular/common';
import { ViewEncapsulation } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { MatDialog } from '@angular/material/dialog';
import { TranslateService } from '@ngx-translate/core';
import { UserService } from '@transom/services';
import * as moment from 'moment-timezone';
import { of as observableOf } from 'rxjs';
import { MatDialogRefMock } from './../../mock/md-dialog-ref-mock';

import { LoadingDialogService } from './../../common/loading-dialog/loading-dialog.service';
import {
  ActivateDedicatedDriverServiceMock,
  DriverManagementLockServiceMock,
  DriverManagementServiceMock,
  LoadingDialogServiceMock,
  MatDialogMock,
  TranslateServiceMock,
  UserServiceMock
} from './../../mock';
import { DriverManagementLockService, DriverManagementService } from './../common-services/';
import { ActivateDedicatedDriversComponent } from './activate-dedicated-drivers.component';
import {
  ActivateDedicatedDriverColumnsService,
  ActivateDedicatedDriverService,
  ActivateDedicatedDriversFormService
} from './services';
declare var require: any;
const driverQueryProfileMock = require('../../mock/json-files/driver-query-profile.json');
const activateDedicatedDriverMock = require('../../mock/json-files/activate-dedicated-driver.json');
const driverProfileDetailsMock = require('../../mock/json-files/driver-profile-details.json');

describe('ActivateDedicatedDriversComponent', () => {
  let component: ActivateDedicatedDriversComponent;
  let translateServiceMock: TranslateServiceMock;
  let activateDedicatedDriverServiceMock: ActivateDedicatedDriverServiceMock;
  let driverManagementLockServiceMock: DriverManagementLockServiceMock;
  let userServiceMock: UserServiceMock;
  let driverManagementServiceMock: DriverManagementServiceMock;
  let loadingServiceMock: LoadingDialogServiceMock;
  let fixture: ComponentFixture<ActivateDedicatedDriversComponent>;
  let mockMatDialog: MatDialogMock;
  let mockDialogRef: MatDialogRefMock;

  beforeEach(async(() => {
    translateServiceMock = new TranslateServiceMock();
    activateDedicatedDriverServiceMock = new ActivateDedicatedDriverServiceMock();
    driverManagementLockServiceMock = new DriverManagementLockServiceMock();
    userServiceMock = new UserServiceMock();
    driverManagementServiceMock = new DriverManagementServiceMock();
    loadingServiceMock = new LoadingDialogServiceMock();
    mockMatDialog = new MatDialogMock();
    mockDialogRef = new MatDialogRefMock();
    TestBed.configureTestingModule({
      declarations: [ActivateDedicatedDriversComponent]
    }).overrideComponent(ActivateDedicatedDriversComponent, {
      set: {
        providers: [
          ActivateDedicatedDriversFormService,
          ActivateDedicatedDriverColumnsService,
          FormBuilder,
          { provide: MatDialogRef, useValue: mockDialogRef },
          { provide: DriverManagementService, useValue: driverManagementServiceMock },
          { provide: TranslateService, useValue: translateServiceMock },
          { provide: ActivateDedicatedDriverService, useValue: activateDedicatedDriverServiceMock },
          { provide: DriverManagementLockService, useValue: driverManagementLockServiceMock },
          { provide: UserService, useValue: userServiceMock },
          { provide: LoadingDialogService, useValue: loadingServiceMock },
          { provide: MAT_DIALOG_DATA, useValue: [{}] },
          { provide: MatDialogRef, useValue: mockDialogRef },
          { provide: MatDialog, useValue: mockMatDialog },
          DatePipe
        ],

        template: `<div></div>`,
        encapsulation: ViewEncapsulation.Emulated
      }
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivateDedicatedDriversComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterAll(() => {
    component = null;
    fixture.destroy();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Initializing grid ', () => {
    it('should bind the rows with valid data to the grid', () => {
      component.selectedDriverQueryData = [driverQueryProfileMock];
      component.getActivateDedicatedDrivers();
      expect(component.selectedRows.length).toEqual(2);
    });
    it('should bind the driver id to the row', () => {
      component.selectedDriverQueryData = [driverQueryProfileMock];
      component.getActivateDedicatedDrivers();
      expect(component.selectedRows[0].driverId).toEqual(1034);
    });
    it('should bind the first name to the row', () => {
      component.selectedDriverQueryData = [driverQueryProfileMock];
      component.getActivateDedicatedDrivers();
      expect(component.selectedRows[0].firstName).toEqual('CHRIS');
    });
    it('should bind the start of work week date to 30 when the minutes is between 30 to 59', () => {
      component.selectedRows = [];
      component.selectedDriverQueryData = [driverQueryProfileMock];
      component.workWeekStartDate = new Date('2018-11-24 09:45:00.000');
      component.getActivateDedicatedDrivers();
      expect(component.selectedRows[0].sowwTsField).toEqual('11/24/2018 09:30');
    });
    it('should bind the start of work week date to 00 when the minutes is between 00 to 29', () => {
      component.selectedRows = [];
      component.selectedDriverQueryData = [driverQueryProfileMock];
      component.workWeekStartDate = new Date('2018-11-24 10:15:00.000');
      component.getActivateDedicatedDrivers();
      expect(component.selectedRows[0].sowwTsField).toEqual('11/24/2018 10:00');
    });
    it('should lock the selected driver and bind it to the grid', () => {
      component.selectedRows = [];
      const locks = [];
      component.driverOperationProfileList = [driverProfileDetailsMock];
      locks.push({
        lockId: '1034',
        lockTimeStamp: moment(new Date()).format(),
        lockType: 'Driver',
        userId: 'test',
        versionId: null
      });
      spyOn(driverManagementLockServiceMock, 'allDriversLock').and.returnValue(
        observableOf({ error: [], lock: locks })
      );
      component.getActivateDedicatedDrivers();
      expect(component.selectedRows.length).toEqual(1);
    });
    it('should open error popup if the drivers are locked by other user', () => {
      spyOn(mockMatDialog, 'open').and.callThrough();
      const locks = [];
      component.selectedRows = [];
      component.driverOperationProfileList = [driverProfileDetailsMock];
      component.selectedRows = [...activateDedicatedDriverMock.inactiveValidDrivers];
      locks.push({
        lockId: '1034',
        lockTimeStamp: moment(new Date()).format(),
        lockType: 'Driver',
        userId: 'test1',
        versionId: null
      });
      spyOn(driverManagementLockServiceMock, 'allDriversLock').and.returnValue(
        observableOf({ error: [], lock: locks })
      );
      component.getActivateDedicatedDrivers();
      expect(mockMatDialog.open).toHaveBeenCalled();
    });
    it('should empty all the rows in grid if all the selected drivers are locked by other user', () => {
      component.selectedRows = [];
      const locks = [];
      component.driverOperationProfileList = [driverProfileDetailsMock];
      locks.push({
        lockId: '1034',
        lockTimeStamp: moment(new Date()).format(),
        lockType: 'Driver',
        userId: 'test1',
        versionId: null
      });
      spyOn(driverManagementLockServiceMock, 'allDriversLock').and.returnValue(
        observableOf({ error: [], lock: locks })
      );
      component.getActivateDedicatedDrivers();
      expect(component.selectedRows.length).toEqual(0);
    });
  });

  describe('Activate button  ', () => {
    it('should be enabled when the first name, last name and work week end date is valid', () => {
      component.selectedRows = [
        ...activateDedicatedDriverMock.payPendingDrivers,
        ...activateDedicatedDriverMock.inactiveDrivers
      ];
      expect(component.isActivateButtonDisabled()).toEqual(false);
    });
    it('should be disabled when first name field is invalid', () => {
      component.selectedRows = [...activateDedicatedDriverMock.driversWithoutFirstName];
      expect(component.isActivateButtonDisabled()).toEqual(true);
    });
    it('should be disabled when last name field is invalid', () => {
      component.selectedRows = [...activateDedicatedDriverMock.driversWithoutLastName];
      expect(component.isActivateButtonDisabled()).toEqual(true);
    });
    it('should be disabled when eowwDateTime field is invalid', () => {
      component.selectedRows = [...activateDedicatedDriverMock.driversWithouteowwDateTime];
      expect(component.isActivateButtonDisabled()).toEqual(true);
    });
    it('should be activate the driver and clear the selected drivers from grid', () => {
      component.selectedRows = [...activateDedicatedDriverMock.inactiveValidDrivers];
      spyOn(activateDedicatedDriverServiceMock, 'activateDedicatedDrivers').and.returnValue(
        observableOf([driverProfileDetailsMock])
      );
      component.activateDedicatedDrivers();
      expect(component.selectedRows.length).toEqual(0);
    });
    it('should be activate the drivers and release the locked drivers', () => {
      component.selectedRows = [
        ...activateDedicatedDriverMock.inactiveValidDrivers,
        ...activateDedicatedDriverMock.inactiveValidDrivers
      ];
      const errorResponse = {
        status: 409,
        statusText: 'Conflict',
        url: '/us/driverMgmt/v1/driverprofiles/1034',
        ok: false,
        name: 'HttpErrorResponse'
      };
      spyOn(activateDedicatedDriverServiceMock, 'activateDedicatedDrivers').and.returnValue(
        observableOf([driverProfileDetailsMock, errorResponse])
      );
      spyOn(driverManagementLockServiceMock, 'releaseAllLock').and.returnValue(observableOf(null));
      component.activateDedicatedDrivers();
      expect(driverManagementLockServiceMock.releaseAllLock).toHaveBeenCalled();
    });
    it('should display error popup, if activation of driver fails', () => {
      spyOn(mockMatDialog, 'open').and.callThrough();
      component.selectedRows = [...activateDedicatedDriverMock.inactiveValidDrivers];
      const errorResponse = {
        status: 409,
        statusText: 'Conflict',
        url: '/us/driverMgmt/v1/driverprofiles/1034',
        ok: false,
        name: 'HttpErrorResponse'
      };
      spyOn(activateDedicatedDriverServiceMock, 'activateDedicatedDrivers').and.returnValue(
        observableOf([errorResponse])
      );
      component.activateDedicatedDrivers();
      expect(mockMatDialog.open).toHaveBeenCalled();
    });
  });

  describe('Activate dedicated driver grid  ', () => {
    describe('with row length zero', () => {
      it('should reset the form and set the default value for lastName', () => {
        component.selected = [];
        component.activateDedicatedDriversForm.controls.lastName.setValue('CHRIS');
        component.updateSelectedDriver();
        expect(component.activateDedicatedDriversForm.controls.lastName.value).toEqual(null);
      });
      it('should reset the form and set the default value for firstName', () => {
        component.selected = [];
        component.activateDedicatedDriversForm.controls.firstName.setValue('JANE');
        component.updateSelectedDriver();
        expect(component.activateDedicatedDriversForm.controls.firstName.value).toEqual(null);
      });
      it('should disable the form ', () => {
        component.selected = [];
        component.updateSelectedDriver();
        expect(component.activateDedicatedDriversForm.disabled).toEqual(true);
      });
    });
    describe('with more rows selected', () => {
      describe('having driver status code inactive', () => {
        it('should enable the first name field ', () => {
          component.selected = [
            ...activateDedicatedDriverMock.inactiveDrivers,
            ...activateDedicatedDriverMock.inactiveDrivers
          ];
          component.updateSelectedDriver();
          expect(component.activateDedicatedDriversForm.controls.firstName.enabled).toEqual(true);
        });
        it('should enable the last name field ', () => {
          component.selected = [
            ...activateDedicatedDriverMock.inactiveDrivers,
            ...activateDedicatedDriverMock.inactiveDrivers
          ];
          component.updateSelectedDriver();
          expect(component.activateDedicatedDriversForm.controls.lastName.enabled).toEqual(true);
        });
        it('should enable the end of work week date field ', () => {
          component.selected = [
            ...activateDedicatedDriverMock.inactiveDrivers,
            ...activateDedicatedDriverMock.inactiveDrivers
          ];
          component.updateSelectedDriver();
          expect(component.activateDedicatedDriversForm.controls.workWeekEndDate.enabled).toEqual(
            true
          );
        });
        it('should enable the end of work week time field ', () => {
          component.selected = [
            ...activateDedicatedDriverMock.inactiveDrivers,
            ...activateDedicatedDriverMock.inactiveDrivers
          ];
          component.updateSelectedDriver();
          expect(component.activateDedicatedDriversForm.controls.workWeekEndTime.enabled).toEqual(
            true
          );
        });
        it('should set the first name', () => {
          component.selected = [...activateDedicatedDriverMock.inactiveDrivers];
          component.updateSelectedDriver();
          expect(component.activateDedicatedDriversForm.controls.firstName.value).toEqual('test');
        });
        it('should set the last name', () => {
          component.selected = [...activateDedicatedDriverMock.inactiveDrivers];
          component.updateSelectedDriver();
          expect(component.activateDedicatedDriversForm.controls.lastName.value).toEqual('test');
        });
        it('should not set the work week end time', () => {
          component.selected = [...activateDedicatedDriverMock.driversWithouteowwDateTime];
          component.updateSelectedDriver();
          expect(component.activateDedicatedDriversForm.controls.workWeekEndTime.value).toEqual(
            null
          );
        });
        it('should set value for work week end time if the end date is more than start date', () => {
          component.selected = [...activateDedicatedDriverMock.driversWithouteowwDateTime];
          component.activateDedicatedDriversForm.patchValue({
            workWeekEndDate: new Date('12/14/2018'),
            workWeekEndTime: '11:00'
          });
          component.updateSelectedDriver();
          expect(component.selected[0].eowwDateTime).toEqual('12/14/2018 11:00');
        });
        it('should not set value for work week end time if the end date is less than start date', () => {
          component.selected = [...activateDedicatedDriverMock.driversWithouteowwDateTime];
          component.activateDedicatedDriversForm.controls.workWeekEndDate.setErrors({
            invalidDate: true
          });
          component.activateDedicatedDriversForm.patchValue({
            workWeekEndDate: new Date('9/9/2018'),
            workWeekEndTime: '11:00'
          });
          component.updateSelectedDriver();
          expect(component.selected[0].eowwDateTime).toEqual('');
        });
        it('should set existing valid DateTime for work week in grid if the entered value is invalid', () => {
          component.selected = [...activateDedicatedDriverMock.inactiveValidDrivers];
          component.activateDedicatedDriversForm.controls.workWeekEndDate.setErrors({
            invalidDate: true
          });
          component.activateDedicatedDriversForm.patchValue({
            workWeekEndDate: new Date('178/89/2018')
          });
          component.updateSelectedDriver();
          expect(component.selected[0].eowwDateTime).toEqual('11/24/2018 12:00');
        });
        it('should set existing empty value for work week in grid if the entered value is invalid', () => {
          component.selected = [...activateDedicatedDriverMock.driversWithouteowwDateTime];
          component.activateDedicatedDriversForm.controls.workWeekEndDate.setErrors({
            invalidDate: true
          });
          component.activateDedicatedDriversForm.patchValue({
            workWeekEndDate: new Date('178/89/2018')
          });
          component.updateSelectedDriver();
          expect(component.selected[0].eowwDateTime).toEqual('');
        });
        it('should set value for first name if it is valid', () => {
          component.selected = [...activateDedicatedDriverMock.driversWithouteowwDateTime];
          component.updateSelectedDriver();
          component.activateDedicatedDriversForm.controls.firstName.setValue('test');
          expect(component.selected[0].firstName).toEqual('test');
        });
        it('should set empty value for first name if it is not alphaNumeric', () => {
          component.selected = [...activateDedicatedDriverMock.driversWithouteowwDateTime];
          component.updateSelectedDriver();
          component.activateDedicatedDriversForm.controls.firstName.setValue('@#$%ad');
          expect(component.selected[0].firstName).toEqual('');
        });
        it('should set value for last name if it is valid', () => {
          component.selected = [...activateDedicatedDriverMock.driversWithouteowwDateTime];
          component.updateSelectedDriver();
          component.activateDedicatedDriversForm.controls.lastName.setValue('test');
          expect(component.selected[0].lastName).toEqual('test');
        });
        it('should set empty value for last name if it is not alphaNumeric', () => {
          component.selected = [...activateDedicatedDriverMock.driversWithouteowwDateTime];
          component.updateSelectedDriver();
          component.activateDedicatedDriversForm.controls.lastName.setValue('@#$%ad');
          expect(component.selected[0].lastName).toEqual('');
        });
        it('should set empty value for first name if it is greater than max length', () => {
          component.selected = [...activateDedicatedDriverMock.driversWithouteowwDateTime];
          component.updateSelectedDriver();
          component.activateDedicatedDriversForm.controls.firstName.setValue('chris david peter');
          expect(component.selected[0].firstName).toEqual('');
        });
        it('should set empty value for last name if it is greater than max length', () => {
          component.selected = [...activateDedicatedDriverMock.driversWithouteowwDateTime];
          component.updateSelectedDriver();
          component.activateDedicatedDriversForm.controls.lastName.setValue(
            'chris david peter nixon'
          );
          expect(component.selected[0].lastName).toEqual('');
        });
        it('should set the existing valid date if the next entered date is invalid', () => {
          component.selected = [...activateDedicatedDriverMock.inactiveValidDrivers];
          component.activateDedicatedDriversForm.controls.workWeekEndDate.setErrors({
            required: true
          });
          component.activateDedicatedDriversForm.controls.workWeekEndDate.setValue('84/56/2018');
          component.updateSelectedDriver();
          expect(component.selected[0].eowwDateTime).toEqual('11/24/2018 12:00');
        });
        it('should remove all errors in end of work week time field if the end of work week time has no required error', () => {
          component.selected = [...activateDedicatedDriverMock.driversWithouteowwDateTime];
          component.activateDedicatedDriversForm.controls.workWeekEndDate.setErrors({
            required: true
          });
          component.activateDedicatedDriversForm.controls.workWeekEndDate.setValue(null);
          component.activateDedicatedDriversForm.controls.workWeekEndTime.setValue('10:00');
          component.activateDedicatedDriversForm.controls.workWeekEndTime.setErrors({
            invalidTime: true
          });
          component.updateSelectedDriver();
          expect(component.activateDedicatedDriversForm.controls.workWeekEndTime.errors).toEqual(
            null
          );
        });
        it('should set the first name if the rows have same value', () => {
          component.selected = [
            ...activateDedicatedDriverMock.inactiveDrivers,
            ...activateDedicatedDriverMock.inactiveDrivers
          ];
          component.updateSelectedDriver();
          expect(component.activateDedicatedDriversForm.controls.firstName.value).toEqual('test');
        });
        it('should not set the last name if the rows have different value', () => {
          component.selected = [
            ...activateDedicatedDriverMock.driversWithouteowwDateTime,
            ...activateDedicatedDriverMock.inactiveDrivers
          ];
          component.updateSelectedDriver();
          expect(component.activateDedicatedDriversForm.controls.lastName.value).toEqual('');
        });
      });
      describe('having driver status code as paypending and inactive', () => {
        it('should disable the first name field ', () => {
          component.selected = [
            ...activateDedicatedDriverMock.payPendingDrivers,
            ...activateDedicatedDriverMock.inactiveDrivers
          ];
          component.updateSelectedDriver();
          expect(component.activateDedicatedDriversForm.controls.firstName.disabled).toEqual(true);
        });
        it('should disable the last name field', () => {
          component.selected = [
            ...activateDedicatedDriverMock.payPendingDrivers,
            ...activateDedicatedDriverMock.inactiveDrivers
          ];
          component.updateSelectedDriver();
          expect(component.activateDedicatedDriversForm.controls.lastName.disabled).toEqual(true);
        });
        it('should enable the end of work week date field', () => {
          component.selected = [
            ...activateDedicatedDriverMock.payPendingDrivers,
            ...activateDedicatedDriverMock.inactiveDrivers
          ];
          component.updateSelectedDriver();
          expect(component.activateDedicatedDriversForm.controls.workWeekEndDate.enabled).toEqual(
            true
          );
        });
        it('should enable the end of work week time field', () => {
          component.selected = [
            ...activateDedicatedDriverMock.payPendingDrivers,
            ...activateDedicatedDriverMock.inactiveDrivers
          ];
          component.updateSelectedDriver();
          expect(component.activateDedicatedDriversForm.controls.workWeekEndTime.enabled).toEqual(
            true
          );
        });

        it('should not set the first name if the rows have different value', () => {
          component.selected = [
            ...activateDedicatedDriverMock.driversWithouteowwDateTime,
            ...activateDedicatedDriverMock.inactiveDrivers
          ];
          component.updateSelectedDriver();
          expect(component.activateDedicatedDriversForm.controls.firstName.value).toEqual('');
        });
        it('should not set the last name if the rows have different value', () => {
          component.selected = [
            ...activateDedicatedDriverMock.driversWithouteowwDateTime,
            ...activateDedicatedDriverMock.inactiveDrivers
          ];
          component.updateSelectedDriver();
          expect(component.activateDedicatedDriversForm.controls.lastName.value).toEqual('');
        });
      });
    });
  });

  describe('Clicking cancel button ', () => {
    it('should empty the rows in popup', () => {
      component.closeActivateDedicatedDriverPopup();
      expect(component.selectedRows.length).toEqual(0);
    });
  });
});