import { DatePipe } from '@angular/common';
import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { MatDialog } from '@angular/material/dialog';
import { TranslateService } from '@ngx-translate/core';
import { UserService } from '@transom/services';
import every = require('lodash/every');
import * as moment from 'moment-timezone';
import { forkJoin, Observable, Subscription } from 'rxjs';
import { ErrorDialogComponent } from './../ui/error-dialog/error-dialog.component';

import {
  ActivateDedicatedDriverLockResponse,
  ActivateDedicatedDriversResponse,
  DriverProfileDetailsResponse,
  DriverProfileQueryResponse,
  Lock,
  LockRequest
} from '../model';
import { LoadingDialogService } from './../../common/loading-dialog/loading-dialog.service';
import { activateDedicatedDriverConstants } from './../../constants/driver-management-constant';
import { DriverManagementLockService, DriverManagementService } from './../common-services';
import {
  ActivateDedicatedDriverColumnsService,
  ActivateDedicatedDriverService,
  ActivateDedicatedDriversFormService
} from './services';
import { DateTimeValidator } from './validator/date-time-validator';

@Component({
  selector: 'activate-dedicated-drivers',
  templateUrl: './activate-dedicated-drivers.component.html',
  styleUrls: ['./activate-dedicated-drivers.component.scss'],
  providers: [ActivateDedicatedDriverColumnsService, ActivateDedicatedDriversFormService]
})
export class ActivateDedicatedDriversComponent implements OnInit, OnDestroy {
  selected = [];
  selectedRows: ActivateDedicatedDriversResponse[];
  driverOperationProfileList: DriverProfileDetailsResponse[];
  activateDedicatedDriverGridColumn: any[];
  activateDedicatedDriversForm: FormGroup;
  workWeekStartDate: Date;
  lockRequest: LockRequest;
  endOfWorkWeekTime: String[];
  getDriversSubscription: Subscription;
  activateDriversSubscription: Subscription;
  lockDriversSubscription: Subscription;
  releaseSingleDriverSubscription: Subscription;
  releaseAllDriversSubscription: Subscription;

  constructor(
    public dialogRefActivateDedicatedDriver: MatDialogRef<ActivateDedicatedDriversComponent>,
    @Inject(MAT_DIALOG_DATA) public selectedDriverQueryData: DriverProfileQueryResponse[],
    private columnService: ActivateDedicatedDriverColumnsService,
    private activateDedicatedDriverService: ActivateDedicatedDriverService,
    private datePipe: DatePipe,
    private activateDedicatedDriverFormService: ActivateDedicatedDriversFormService,
    private lockService: DriverManagementLockService,
    private driverManagementService: DriverManagementService,
    private userService: UserService,
    private loadingDialogService: LoadingDialogService,
    private translateService: TranslateService,
    private dialog: MatDialog
  ) {}

  ngOnInit() {
    this.initializeGrid();
    this.endOfWorkWeekTime = this.driverManagementService.getEndTime(
      activateDedicatedDriverConstants.halfTime
    );
    this.selectedRows = new Array<ActivateDedicatedDriversResponse>();
    this.driverOperationProfileList = new Array<DriverProfileDetailsResponse>();
    this.workWeekStartDate = new Date();
    this.activateDedicatedDriversForm = this.activateDedicatedDriverFormService.initializeForm();
    this.getActivateDedicatedDrivers();
    this.updateGrid();
  }

  ngOnDestroy() {
    if (this.getDriversSubscription) this.getDriversSubscription.unsubscribe();
    if (this.activateDriversSubscription) this.activateDriversSubscription.unsubscribe();
    if (this.lockDriversSubscription) this.lockDriversSubscription.unsubscribe();
    if (this.releaseSingleDriverSubscription) this.releaseSingleDriverSubscription.unsubscribe();
    if (this.releaseAllDriversSubscription) this.releaseAllDriversSubscription.unsubscribe();
  }

  getActivateDedicatedDrivers(): void {
    const locks: Lock[] = [];
    this.activateDedicatedDriversList().subscribe(
      (activateDriver: DriverProfileDetailsResponse[]) => {
        activateDriver.map((profileDetail: DriverProfileDetailsResponse) => {
          if (profileDetail && profileDetail.driverProfileDetails) {
            this.driverOperationProfileList.push(profileDetail);
            this.getActivateDedicatedDriversResponse(profileDetail);
            if (this.selectedRows.length === 1)
              this.activateDedicatedDriversForm.setValidators(
                DateTimeValidator.dateTimeValidator(this.selectedRows[0].sowwTsField)
              );
            locks.push({
              userId: this.userService.userId ? this.userService.userId.trim() : null,
              lockType: activateDedicatedDriverConstants.driver,
              lockId: profileDetail.driverProfileDetails.operationalProfile.driverId.toString(),
              lockTimeStamp: moment(new Date()).format(),
              versionId: profileDetail.driverProfileDetails.operationalProfile.versionId
                ? profileDetail.driverProfileDetails.operationalProfile.versionId.toString()
                : null
            });
          }
        });
        this.lockRequest = { locks: locks };
        this.lockAllDrivers();
      }
    );
  }

  updateSelectedDriver(): void {
    if (this.selected.length > 0) {
      this.updateForm();
      this.checkDrivers(this.selected);
    } else {
      this.activateDedicatedDriversForm.reset();
      this.activateDedicatedDriversForm.disable({ onlySelf: true, emitEvent: false });
    }
  }

  onSelect({ selected }) {
    this.selected.splice(0, this.selected.length);
    this.selected.push(...selected);
  }

  isActivateButtonDisabled(): boolean {
    return (
      this.selectedRows.filter(
        driver => !driver.firstName || !driver.lastName || !driver.eowwDateTime
      ).length > 0
    );
  }

  closeActivateDedicatedDriverPopup(): void {
    this.releaseLockedDriver();
    this.closePopup(false);
  }

  activateDedicatedDrivers(): void {
    this.loadingDialogService.openLoaderDialog(this.translateService.instant('Processing'));
    this.activateDriversSubscription = this.activateDedicatedDriverService
      .activateDedicatedDrivers(this.driverOperationProfileList, this.selectedRows)
      .subscribe((activationResponse: DriverProfileDetailsResponse[]) => {
        let activatedDrivers: ActivateDedicatedDriversResponse[] = [...this.selectedRows];
        activationResponse
          .filter(driverResponse => driverResponse.driverProfileDetails)
          .forEach(removeElement => {
            activatedDrivers = activatedDrivers.filter(
              arrayElement =>
                removeElement.driverProfileDetails.operationalProfile.driverId !==
                arrayElement.driverId
            );
          });
        if (
          activationResponse.filter(errorResponse => !errorResponse.driverProfileDetails).length > 0
        )
          this.openErrorPopup(activatedDrivers.map(driver => String(driver.driverId)));
        this.releaseLockedDriver();
        this.loadingDialogService.closeLoader();
        this.closePopup(true);
      });
  }

  private openErrorPopup(errorDrivers: string[]): void {
    this.dialog.open(ErrorDialogComponent, {
      data: {
        errorTitle: '',
        errorList: errorDrivers
      },
      panelClass: 'transom-flush-dialog',
      disableClose: true
    });
  }

  private closePopup(successResult: boolean): void {
    this.selectedRows = [];
    this.dialogRefActivateDedicatedDriver.close(successResult);
  }

  private releaseLockedDriver(): void {
    if (this.selectedRows.length === 1)
      this.releaseSingleDriverSubscription = this.lockService
        .releaseLock(this.selectedRows[0].driverId, activateDedicatedDriverConstants.driver)
        .subscribe();
    else
      this.releaseAllDriversSubscription = this.lockService
        .releaseAllLock(this.lockRequest)
        .subscribe();
  }

  private getActivateDedicatedDriversResponse(profileDetail: DriverProfileDetailsResponse): void {
    this.selectedRows.push({
      driverId: profileDetail.driverProfileDetails.operationalProfile.driverId,
      firstName: profileDetail.driverProfileDetails.operationalProfile.firstName.trim(),
      lastName: profileDetail.driverProfileDetails.operationalProfile.lastName.trim(),
      sowwTsField: String(
        this.datePipe.transform(
          this.workWeekStartDate.getMinutes() >= 0 &&
            this.workWeekStartDate.getMinutes() < activateDedicatedDriverConstants.halfTime
            ? this.workWeekStartDate.setMinutes(0)
            : this.workWeekStartDate.setMinutes(activateDedicatedDriverConstants.halfTime),
          activateDedicatedDriverConstants.timeStampFormat
        )
      ),
      driverStatusCode: profileDetail.driverProfileDetails.operationalProfile.driverStatusCode
    });
  }

  private updateGrid(): void {
    this.activateDedicatedDriversForm.valueChanges.forEach(() => {
      this.selected.map(activateDrivers => {
        if (this.activateDedicatedDriversForm.controls.firstName.value)
          if (!this.activateDedicatedDriversForm.controls.firstName.errors)
            activateDrivers.firstName = this.activateDedicatedDriversForm.controls.firstName.value;
          else activateDrivers.firstName = '';
        if (this.activateDedicatedDriversForm.controls.lastName.value)
          if (!this.activateDedicatedDriversForm.controls.lastName.errors)
            activateDrivers.lastName = this.activateDedicatedDriversForm.controls.lastName.value;
          else activateDrivers.lastName = '';
        this.requiredDateErrorCheck(activateDrivers);
      });
    });
  }

  private requiredDateErrorCheck(activateDrivers): void {
    if (
      this.activateDedicatedDriversForm.controls.workWeekEndDate.value &&
      this.activateDedicatedDriversForm.controls.workWeekEndTime.value
    )
      if (
        !this.activateDedicatedDriversForm.controls.workWeekEndDate.hasError('invalidDate') &&
        !this.activateDedicatedDriversForm.controls.workWeekEndTime.hasError('invalidTime')
      )
        activateDrivers.eowwDateTime = String(
          this.datePipe.transform(
            this.activateDedicatedDriversForm.controls.workWeekEndDate.value,
            activateDedicatedDriverConstants.dateFormat
          ) +
            ' ' +
            moment(
              this.activateDedicatedDriversForm.controls.workWeekEndTime.value,
              activateDedicatedDriverConstants.twelveHourFormat
            ).format(activateDedicatedDriverConstants.momentTimeFormat)
        );
      else activateDrivers.eowwDateTime = '';
    if (this.activateDedicatedDriversForm.controls.workWeekEndDate.hasError('required')) {
      if (!this.activateDedicatedDriversForm.controls.workWeekEndTime.hasError('required'))
        this.activateDedicatedDriversForm.controls.workWeekEndTime.setErrors(null);
      if (
        activateDrivers.eowwDateTime &&
        activateDrivers.eowwDateTime !== '' &&
        every(this.selected, [
          activateDedicatedDriverConstants.eowwDateTime,
          this.selected[0].eowwDateTime
        ])
      ) {
        this.activateDedicatedDriversForm.controls.workWeekEndDate.setValue(
          new Date(activateDrivers.eowwDateTime.split(' ', 2)[0]),
          { onlySelf: true, emitEvent: false }
        );
        this.activateDedicatedDriversForm.controls.workWeekEndTime.setValue(
          moment(
            activateDrivers.eowwDateTime.split(' ', 2)[1],
            activateDedicatedDriverConstants.momentTimeFormat
          ).format(activateDedicatedDriverConstants.twelveHourFormat),
          { onlySelf: true, emitEvent: false }
        );
      }
    }
  }

  private updateForm(): void {
    if (
      every(this.selected, [activateDedicatedDriverConstants.lastName, this.selected[0].lastName])
    )
      this.activateDedicatedDriversForm.controls.lastName.setValue(this.selected[0].lastName, {
        onlySelf: true,
        emitEvent: false
      });
    else
      this.activateDedicatedDriversForm.controls.lastName.setValue('', {
        onlySelf: true,
        emitEvent: false
      });
    if (
      every(this.selected, [activateDedicatedDriverConstants.firstName, this.selected[0].firstName])
    )
      this.activateDedicatedDriversForm.controls.firstName.setValue(this.selected[0].firstName, {
        onlySelf: true,
        emitEvent: false
      });
    else
      this.activateDedicatedDriversForm.controls.firstName.setValue('', {
        onlySelf: true,
        emitEvent: false
      });
    if (
      every(this.selected, [
        activateDedicatedDriverConstants.eowwDateTime,
        this.selected[0].eowwDateTime
      ])
    ) {
      if (this.selected[0].eowwDateTime) {
        this.activateDedicatedDriversForm.controls.workWeekEndDate.setValue(
          new Date(this.selected[0].eowwDateTime.split(' ', 2)[0]),
          { onlySelf: true, emitEvent: false }
        );
        this.activateDedicatedDriversForm.controls.workWeekEndTime.setValue(
          moment(
            this.selected[0].eowwDateTime.split(' ', 2)[1],
            activateDedicatedDriverConstants.momentTimeFormat
          ).format(activateDedicatedDriverConstants.twelveHourFormat),
          { onlySelf: true, emitEvent: false }
        );
      }
    } else {
      this.activateDedicatedDriversForm.controls.workWeekEndDate.setValue('', {
        onlySelf: true,
        emitEvent: false
      });
      this.activateDedicatedDriversForm.controls.workWeekEndTime.setValue('', {
        onlySelf: true,
        emitEvent: false
      });
    }
  }

  private activateDedicatedDriversList(): Observable<DriverProfileDetailsResponse[]> {
    const driverList = [];
    this.selectedDriverQueryData.forEach(queryData => {
      driverList.push(
        this.activateDedicatedDriverService.fetchActivateDedicatedDriverDetails(queryData.driverId)
      );
    });
    return forkJoin(driverList);
  }

  private initializeGrid(): void {
    this.activateDedicatedDriverGridColumn = this.columnService.getColumn();
  }

  private checkDrivers(activateDriversList: ActivateDedicatedDriversResponse[]): void {
    if (
      activateDriversList.filter(
        driver => driver.driverStatusCode === activateDedicatedDriverConstants.payPendingDriver
      ).length > 0
    ) {
      this.activateDedicatedDriversForm.controls.firstName.disable({
        onlySelf: true,
        emitEvent: false
      });
      this.activateDedicatedDriversForm.controls.lastName.disable({
        onlySelf: true,
        emitEvent: false
      });
      this.activateDedicatedDriversForm.controls.workWeekEndDate.enable({
        onlySelf: true,
        emitEvent: false
      });
      this.activateDedicatedDriversForm.controls.workWeekEndTime.enable({
        onlySelf: true,
        emitEvent: false
      });
    } else {
      this.activateDedicatedDriversForm.enable({ onlySelf: true, emitEvent: false });
      this.activateDedicatedDriversForm.markAsUntouched();
    }
  }

  private lockAllDrivers(): void {
    this.lockDriversSubscription = this.lockService
      .allDriversLock(this.lockRequest)
      .subscribe((response: ActivateDedicatedDriverLockResponse) => {
        const lockDrivers: string[] = [];
        const lockErrorMessages: string[] = [];
        if (response && response.lock) {
          response.lock.map(driver => {
            if (driver.userId.trim() !== this.userService.userId.trim()) {
              lockDrivers.push(driver.lockId);
              lockErrorMessages.push(
                activateDedicatedDriverConstants.lockResource +
                  driver.lockId +
                  activateDedicatedDriverConstants.usedBy +
                  driver.userId.trim()
              );
            }
          });
          if (lockDrivers.length > 0) this.openErrorPopup(lockErrorMessages);
          this.filterLockedDrivers(lockDrivers);
          if (this.selectedRows.length < 1) this.closeActivateDedicatedDriverPopup();
          this.loadingDialogService.closeLoader();
        }
      });
  }

  private filterLockedDrivers(lockDrivers: string[]): void {
    lockDrivers.map(removeElement => {
      this.driverOperationProfileList = this.driverOperationProfileList.filter(
        arrayElement =>
          arrayElement.driverProfileDetails.operationalProfile.driverId !== +removeElement
      );
      this.selectedRows = this.selectedRows.filter(
        arrayElement => arrayElement.driverId !== +removeElement
      );
      this.lockRequest.locks = this.lockRequest.locks.filter(
        arrayElement => +arrayElement.lockId !== +removeElement
      );
    });
  }
}