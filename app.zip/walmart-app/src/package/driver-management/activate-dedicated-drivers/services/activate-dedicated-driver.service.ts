import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { EnvService, UserService } from '@transom/services';
import { ToastrService } from '@transom/ui';
import * as moment from 'moment-timezone';
import { forkJoin, Observable, of as observableOf } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';

import {
  ACTIVATE_DEDICATED_DRIVER_PROFILE_URL,
  ACTIVATE_DEDICATED_DRIVER_UPDATE_URL
} from '../../../common/urls';
import { errors } from '../../../constants/obc-constants';
import {
  ActivateDedicatedDriversResponse,
  DriverProfileDate,
  DriverProfileDetailsResponse,
  DriverWorkWeek
} from '../../model';
import { LoadingDialogService } from './../../../common/loading-dialog/loading-dialog.service';
import { activateDedicatedDriverConstants } from './../../../constants/driver-management-constant';

@Injectable()
export class ActivateDedicatedDriverService {
  constructor(
    private http: HttpClient,
    private envService: EnvService,
    private loadingDialogService: LoadingDialogService,
    private toastrService: ToastrService,
    private translateService: TranslateService,
    private userService: UserService
  ) {}

  fetchActivateDedicatedDriverDetails(driverId: number): Observable<DriverProfileDetailsResponse> {
    return this.http
      .get<DriverProfileDetailsResponse>(
        this.envService.marketPrefix.toLowerCase() +
          ACTIVATE_DEDICATED_DRIVER_PROFILE_URL +
          driverId +
          activateDedicatedDriverConstants.operationalProfile
      )
      .pipe(
        tap((response: DriverProfileDetailsResponse) => {
          if (response) return response;
        }),
        catchError(error => {
          return this.handleError(error);
        })
      );
  }

  activateDedicatedDrivers(
    driverOperationProfileList: DriverProfileDetailsResponse[],
    selectedRows: ActivateDedicatedDriversResponse[]
  ): Observable<DriverProfileDetailsResponse[]> {
    const driverList = [];
    driverOperationProfileList.forEach(driver => {
      driver.driverProfileDetails.operationalProfile.driverStatusCode = 1;
      driver.driverProfileDetails.operationalProfile.firstName = selectedRows.find(
        row => row.driverId === driver.driverProfileDetails.operationalProfile.driverId
      ).firstName;
      driver.driverProfileDetails.operationalProfile.lastName = selectedRows.find(
        row => row.driverId === driver.driverProfileDetails.operationalProfile.driverId
      ).lastName;
      driver.driverProfileDetails.driverWorkWeeks = [this.getWorkWeek(driver, selectedRows)];
      driverList.push(this.activateDrivers(driver));
    });
    return forkJoin(driverList);
  }

  private activateDrivers(
    driver: DriverProfileDetailsResponse
  ): Observable<DriverProfileDetailsResponse> {
    return this.http
      .put(
        this.envService.marketPrefix.toLowerCase() +
          ACTIVATE_DEDICATED_DRIVER_UPDATE_URL +
          driver.driverProfileDetails.operationalProfile.driverId,
        driver,
        {
          headers: new HttpHeaders({
            userId: this.userService.userId,
            userPrincipalName: this.userService.userPrincipalName,
            'skip-retry': 'true'
          })
        }
      )
      .pipe(
        tap((response: DriverProfileDetailsResponse) => {
          return response;
        }),
        catchError(error => {
          return observableOf(error);
        })
      );
  }

  private getWorkWeek(
    driver: DriverProfileDetailsResponse,
    selectedRows: ActivateDedicatedDriversResponse[]
  ): DriverWorkWeek {
    const sowwTsValue: DriverProfileDate = {
      timeStamp: moment(
        selectedRows.find(
          row => row.driverId === driver.driverProfileDetails.operationalProfile.driverId
        ).sowwTsField
      ).format(activateDedicatedDriverConstants.dbDateFormat)
    };
    const eowwTsValue: DriverProfileDate = {
      timeStamp: moment(
        selectedRows.find(
          row => row.driverId === driver.driverProfileDetails.operationalProfile.driverId
        ).eowwDateTime
      ).format(activateDedicatedDriverConstants.dbDateFormat)
    };
    const workWeek: DriverWorkWeek = {
      driverId: driver.driverProfileDetails.operationalProfile.driverId,
      versionId: driver.driverProfileDetails.operationalProfile.versionId,
      eowwTs: eowwTsValue,
      sowwTs: sowwTsValue
    };
    return workWeek;
  }

  private handleError(errorResponse: HttpErrorResponse): Observable<never> {
    this.loadingDialogService.closeLoader();
    const errorStatusCode = errorResponse.status;
    if (errorStatusCode === errors.internalServer)
      this.toastrService.error(this.translateService.instant('Internal Server Error'));
    else this.toastrService.error(errorResponse.statusText);
    return new Observable<never>();
  }
}