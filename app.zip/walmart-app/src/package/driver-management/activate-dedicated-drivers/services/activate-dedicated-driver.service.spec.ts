import { HttpHeaders } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { async, getTestBed, TestBed } from '@angular/core/testing';
import { TranslateService } from '@ngx-translate/core';
import { EnvService, UserService } from '@transom/services';
import { ToastrService } from '@transom/ui';
import { LoadingDialogService } from './../../../common/loading-dialog/loading-dialog.service';

import {
  LoadingDialogServiceMock,
  ToastrMessageServiceMock,
  TranslateServiceMock,
  UserServiceMock
} from '../../../mock';
import { ActivateDedicatedDriverService } from '../services';
declare var require: any;
const driverProfileDetailsMock = require('../../../mock/json-files/driver-profile-details.json');
const activateDedicatedDriverMock = require('../../../mock/json-files/activate-dedicated-driver.json');

describe('ActivateDedicatedDriverService', () => {
  let mockBackend: HttpTestingController;
  let translateServiceMock: TranslateServiceMock;
  let toastrServiceMock: ToastrMessageServiceMock;
  let loadingServiceMock: LoadingDialogServiceMock;
  let userServiceMock: UserServiceMock;
  let activateDedicatedDriverQueryService: ActivateDedicatedDriverService;
  const marketPrefixValue = '/us';
  const envServiceMock = {
    marketPrefix: marketPrefixValue
  };

  beforeEach(async(() => {
    translateServiceMock = new TranslateServiceMock();
    loadingServiceMock = new LoadingDialogServiceMock();
    toastrServiceMock = new ToastrMessageServiceMock();
    userServiceMock = new UserServiceMock();
    TestBed.configureTestingModule({
      providers: [
        ActivateDedicatedDriverService,
        { provide: ToastrService, useValue: toastrServiceMock },
        { provide: LoadingDialogService, useValue: loadingServiceMock },
        { provide: TranslateService, useValue: translateServiceMock },
        { provide: UserService, useValue: userServiceMock },
        { provide: EnvService, useValue: envServiceMock }
      ],
      imports: [HttpClientTestingModule]
    });
    mockBackend = getTestBed().get(HttpTestingController);
    activateDedicatedDriverQueryService = getTestBed().get(ActivateDedicatedDriverService);
  }));

  it('should fetch driver details for status 200', () => {
    activateDedicatedDriverQueryService
      .fetchActivateDedicatedDriverDetails(123456)
      .subscribe((successResult: any) => {
        expect(successResult).toEqual({ status: 200 });
      });
    mockBackend
      .expectOne({
        method: 'GET'
      })
      .flush({
        status: 200
      });
  });

  it('should return null response if empty', () => {
    activateDedicatedDriverQueryService
      .fetchActivateDedicatedDriverDetails(123456)
      .subscribe(successResult => {
        expect(successResult).toEqual(null);
      });
    mockBackend
      .expectOne({
        method: 'GET'
      })
      .flush(null);
  });

  it('should show custom error message if response status is 500', () => {
    spyOn(toastrServiceMock, 'error').and.callThrough();
    activateDedicatedDriverQueryService
      .fetchActivateDedicatedDriverDetails(123456)
      .subscribe(
        () => () => fail('ObservableOf should not reach failure path'),
        () => expect(toastrServiceMock.error).toHaveBeenCalledWith('A Fatal error occured')
      );
    mockBackend
      .expectOne({
        method: 'GET'
      })
      .flush({ message: 'Error' }, { status: 500, statusText: 'A Fatal error occured' });
  });

  it('should show custom error message if received failure response ', () => {
    spyOn(toastrServiceMock, 'error').and.callThrough();
    const customErrorMessage = 'test';
    activateDedicatedDriverQueryService
      .fetchActivateDedicatedDriverDetails(123456)
      .subscribe(() => expect(toastrServiceMock.error).toHaveBeenCalledWith(customErrorMessage));
    mockBackend
      .expectOne({
        method: 'GET'
      })
      .flush(
        { message: 'Error' },
        { headers: new HttpHeaders(), status: 505, statusText: customErrorMessage }
      );
  });

  it('should activate the driver if success', async(() => {
    const url = envServiceMock.marketPrefix.toLowerCase() + '/driverMgmt/v1/driverprofiles/1034';

    activateDedicatedDriverQueryService
      .activateDedicatedDrivers(
        [driverProfileDetailsMock],
        [...activateDedicatedDriverMock.inactiveValidDrivers]
      )
      .subscribe((response: any) => {
        expect(response[0]).toEqual({ status: 200 });
      });
    mockBackend
      .expectOne({
        url: url,
        method: 'PUT'
      })
      .flush({
        status: 200
      });
  }));

  it('should show error message if response status is conflict response 409', async(() => {
    activateDedicatedDriverQueryService
      .activateDedicatedDrivers(
        [driverProfileDetailsMock],
        [...activateDedicatedDriverMock.inactiveValidDrivers]
      )
      .subscribe((errorResponse: any) => {
        expect(errorResponse[0].status).toEqual(409);
      });
    mockBackend
      .expectOne({
        method: 'PUT'
      })
      .flush({ message: 'Error' }, { status: 409, statusText: 'Conflict' });
  }));

  it('should show error message if response status is Internal server error response 500', async(() => {
    activateDedicatedDriverQueryService
      .activateDedicatedDrivers(
        [driverProfileDetailsMock],
        [...activateDedicatedDriverMock.inactiveValidDrivers]
      )
      .subscribe((errorResponse: any) => {
        expect(errorResponse[0].status).toEqual(500);
      });
    mockBackend
      .expectOne({
        method: 'PUT'
      })
      .flush({ message: 'Error' }, { status: 500, statusText: 'Internal Server Error' });
  }));

  it('should show error message if response status is unknown', async(() => {
    activateDedicatedDriverQueryService
      .activateDedicatedDrivers(
        [driverProfileDetailsMock],
        [...activateDedicatedDriverMock.inactiveValidDrivers]
      )
      .subscribe(() => (errorResponse: any) => {
        expect(errorResponse[0].status).toEqual(505);
      });
    mockBackend
      .expectOne({
        method: 'PUT'
      })
      .flush({ message: 'Error' }, { status: 505, statusText: 'test' });
  }));
});