import { async, getTestBed, TestBed } from '@angular/core/testing';
import { TranslateService } from '@ngx-translate/core';
import { TranslateServiceMock } from '../../../mock';
import { ActivateDedicatedDriverColumnsService } from './activate-dedicated-drivers-columns.service';

describe('ActivateDedicatedDriverColumnService', () => {
  let translateServiceMock: TranslateServiceMock;
  beforeEach(async(() => {
    translateServiceMock = new TranslateServiceMock();
    TestBed.configureTestingModule({
      providers: [
        ActivateDedicatedDriverColumnsService,
        { provide: TranslateService, useValue: translateServiceMock }
      ]
    });
  }));
  it('should return grid column details and verified driver Id field in the columns list', () => {
    const activateDedicatedDriversColumnsService: ActivateDedicatedDriverColumnsService = getTestBed().get(
      ActivateDedicatedDriverColumnsService
    );
    expect(activateDedicatedDriversColumnsService.getColumn()[0].prop).toEqual('driverId');
  });
});