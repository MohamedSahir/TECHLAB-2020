import { Injectable } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { activateDedicatedDriverConstants } from '../../../constants/driver-management-constant';

@Injectable()
export class ActivateDedicatedDriversFormService {

  constructor(private formBuilder: FormBuilder) { }

  initializeForm(): FormGroup {
    let activateDedicatedDriverForm: FormGroup;
    activateDedicatedDriverForm = this.formBuilder.group({
      firstName: [{ value: null, disabled: true }, { validators: [Validators.maxLength(activateDedicatedDriverConstants.firstNameMaxLength), Validators.required, Validators.pattern(activateDedicatedDriverConstants.alphaNumericWithSpaces)], updateOn: activateDedicatedDriverConstants.blur }],
      lastName: [{ value: null, disabled: true }, { validators: [Validators.maxLength(activateDedicatedDriverConstants.lastNameMaxLength), Validators.required, Validators.pattern(activateDedicatedDriverConstants.alphaNumericWithSpaces)], updateOn: activateDedicatedDriverConstants.blur }],
      workWeekEndDate: [{ value: null, disabled: true }, { validators: Validators.required, updateOn: activateDedicatedDriverConstants.blur }],
      workWeekEndTime: [{ value: null, disabled: true }, { validators: Validators.required, updateOn: activateDedicatedDriverConstants.blur }]
    })
    return activateDedicatedDriverForm;
  }

}