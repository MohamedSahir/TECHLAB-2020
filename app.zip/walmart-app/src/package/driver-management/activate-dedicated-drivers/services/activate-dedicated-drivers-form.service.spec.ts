import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, getTestBed, TestBed } from '@angular/core/testing';
import { FormBuilder, FormGroup } from '@angular/forms';

import { ActivateDedicatedDriversFormService } from '../services';

describe('ActivateDedicatedDriversFormService', () => {
  let activateDedicatedDriversFormService: ActivateDedicatedDriversFormService;
  let activateDedicatedDriversForm: FormGroup;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      providers: [ActivateDedicatedDriversFormService, FormBuilder],
      imports: [HttpClientTestingModule]
    });
    activateDedicatedDriversFormService = getTestBed().get(ActivateDedicatedDriversFormService);
  }));

  beforeEach(() => {
    activateDedicatedDriversForm = activateDedicatedDriversFormService.initializeForm();
  });

  afterEach(() => {
    activateDedicatedDriversForm.reset();
  });

  describe('Activate Dedicated Driver form', () => {
    it('should be defined', () => {
      expect(activateDedicatedDriversForm).toBeDefined();
    });
    it('should set first name value to be empty.', () => {
      expect(activateDedicatedDriversForm.controls.firstName.value).toEqual(null);
    });
    it('should set last name value to be empty.', () => {
      expect(activateDedicatedDriversForm.controls.lastName.value).toEqual(null);
    });
    it('should set workWeekEndDate value to be empty.', () => {
      expect(activateDedicatedDriversForm.controls.workWeekEndDate.value).toEqual(null);
    });
    it('should set workWeekEndTime value to be empty.', () => {
      expect(activateDedicatedDriversForm.controls.workWeekEndTime.value).toEqual(null);
    });
  });
});