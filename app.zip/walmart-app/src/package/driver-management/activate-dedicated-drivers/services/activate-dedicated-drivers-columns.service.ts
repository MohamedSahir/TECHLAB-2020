import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Injectable({
  providedIn: 'root'
})
export class ActivateDedicatedDriverColumnsService {
  constructor(private translate: TranslateService) {}

  private activateDedicatedDriverGridColumns: any[] = [
    {
      name: this.translate.instant('Driver_Id_Full'),
      prop: 'driverId'
    },
    {
      name: this.translate.instant('First_Name'),
      prop: 'firstName'
    },
    {
      name: this.translate.instant('Last_Name'),
      prop: 'lastName'
    },
    {
      name: this.translate.instant('Start_Of_Work_Week'),
      prop: 'sowwTsField'
    },
    {
      name: this.translate.instant('End_Of_Work_Week'),
      prop: 'eowwDateTime'
    }
  ];

  getColumn(): any[] {
    return this.activateDedicatedDriverGridColumns;
  }
}