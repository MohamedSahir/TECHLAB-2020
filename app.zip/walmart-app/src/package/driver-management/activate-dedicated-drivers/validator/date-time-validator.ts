import { FormGroup, ValidatorFn } from '@angular/forms';
import * as moment from 'moment-timezone';
import { activateDedicatedDriverConstants } from './../../../constants/driver-management-constant';

export class DateTimeValidator {
  static dateTimeValidator(startDateCtrl: String): ValidatorFn {
    return (group: FormGroup): { [key: string]: any } | null => {
      let startDate;
      const endDate = moment(
        new Date(group.get(activateDedicatedDriverConstants.workWeekEndDate).value)
      ).format(activateDedicatedDriverConstants.momentDateFormat);
      startDate = moment(startDateCtrl).format(activateDedicatedDriverConstants.momentDateFormat);
      if (
        group.get(activateDedicatedDriverConstants.workWeekEndDate).value &&
        group.get(activateDedicatedDriverConstants.workWeekEndTime).value
      )
        if (
          moment
            .duration(
              moment(endDate, activateDedicatedDriverConstants.momentDateFormat).diff(
                moment(startDate, activateDedicatedDriverConstants.momentDateFormat)
              )
            )
            .days() === 1
        )
          DateTimeValidator.validateTime(group, startDateCtrl);
        else if (
          moment
            .duration(
              moment(endDate, activateDedicatedDriverConstants.momentDateFormat).diff(
                moment(startDate),
                activateDedicatedDriverConstants.momentDateFormat
              )
            )
            .days() <= 0
        ) {
          group
            .get(activateDedicatedDriverConstants.workWeekEndDate)
            .setErrors({ invalidDate: true });
          group
            .get(activateDedicatedDriverConstants.workWeekEndTime)
            .setErrors({ invalidTime: true });
        } else {
          group.get(activateDedicatedDriverConstants.workWeekEndDate).setErrors(null);
          group.get(activateDedicatedDriverConstants.workWeekEndTime).setErrors(null);
        }
      return null;
    };
  }

  private static validateTime(group: FormGroup, startDateCtrl: String): void {
    const startTime = String(
      moment(startDateCtrl).format(activateDedicatedDriverConstants.momentFormat)
    ).split(' ', 2)[1];
    if (
      moment
        .duration(
          moment(
            group.get(activateDedicatedDriverConstants.workWeekEndTime).value,
            activateDedicatedDriverConstants.timeFormatValidationFormat
          ).diff(moment(startTime, activateDedicatedDriverConstants.momentTimeFormat))
        )
        .asHours() < 0
    ) {
      group.get(activateDedicatedDriverConstants.workWeekEndDate).setErrors({ invalidDate: true });
      group.get(activateDedicatedDriverConstants.workWeekEndTime).setErrors({ invalidTime: true });
    } else {
      group.get(activateDedicatedDriverConstants.workWeekEndDate).setErrors(null);
      group.get(activateDedicatedDriverConstants.workWeekEndTime).setErrors(null);
    }
  }
}