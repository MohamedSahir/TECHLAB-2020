import { FormBuilder, FormGroup } from '@angular/forms';
import { DateTimeValidator } from "./date-time-validator";

describe('DateTimeValidator', () => {
    const validatorFn = DateTimeValidator.dateTimeValidator('12/12/2018 11:00');

    it('should set invalid date error if the end of work week date is less than the start of work week', () => {
        const formBuilder: FormBuilder = new FormBuilder();
        const form = formBuilder.group({
            firstName: ['test'],
            lastName: ['test'],
            workWeekEndDate: ['11/11/2018'],
            workWeekEndTime: ['12:00']
        });
        validatorFn(form as FormGroup)
        expect(form.valid).toBeFalsy();
    });
    it('should set invalid date and time error if the end of work week date is valid but end of work week time is not valid', () => {
        const formBuilder: FormBuilder = new FormBuilder();
        const form = formBuilder.group({
            firstName: ['test'],
            lastName: ['test'],
            workWeekEndDate: ['12/13/2018'],
            workWeekEndTime: ['10:00']
        });
        validatorFn(form as FormGroup)
        expect(form.valid).toBeFalsy();
    });
    it('should not set error if the end of work week date is one day greater than the start of work week', () => {
        const formBuilder: FormBuilder = new FormBuilder();
        const form = formBuilder.group({
            firstName: ['test'],
            lastName: ['test'],
            workWeekEndDate: ['12/13/2018'],
            workWeekEndTime: ['14:00']
        });
        validatorFn(form as FormGroup)
        expect(form.valid).toBeTruthy();
    });

    it('should not set error if the end of work week date is greater than the start of work week', () => {
        const formBuilder: FormBuilder = new FormBuilder();
        const form = formBuilder.group({
            firstName: ['test'],
            lastName: ['test'],
            workWeekEndDate: ['12/16/2018'],
            workWeekEndTime: ['11:00']
        });
        validatorFn(form as FormGroup)
        expect(form.valid).toBeTruthy();
    });
});