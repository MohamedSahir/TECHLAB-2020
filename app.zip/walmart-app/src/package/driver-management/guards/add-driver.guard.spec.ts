import { async, getTestBed, TestBed } from '@angular/core/testing';
import { AuthZService } from '@transom/services';
import { of as observableOf } from 'rxjs';

import { AddDriverGuard } from './add-driver.guard';

describe('Add Driver Read Guard', () => {
  let isCapable = true;
  const mockAuth = {
    hasCapability() {
      if (isCapable) return observableOf(true);
      else return observableOf(false);
    }
  };
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      providers: [AddDriverGuard, { provide: AuthZService, useValue: mockAuth }]
    });
  }));
  it('should show Add Driver button in the menu if user has capability', async(() => {
    isCapable = true;
    const addDriverService: AddDriverGuard = getTestBed().get(AddDriverGuard);
    spyOn(mockAuth, 'hasCapability');
    addDriverService.canActivate(null, null).subscribe(response => {
      expect(response).toEqual(true);
    });
  }));
  it('should not  show Add Driver button in the menu if user has capability', async(() => {
    isCapable = false;
    const addDriverService: AddDriverGuard = getTestBed().get(AddDriverGuard);
    spyOn(mockAuth, 'hasCapability');
    addDriverService.canActivate(null, null).subscribe(response => {
      expect(response).toEqual(false);
    });
  }));
});