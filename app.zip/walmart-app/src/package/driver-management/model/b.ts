export interface AssignmentFormData {
    isInitialLoading: boolean;
    selectedDriverId: string;
    selectedDriverCompany: string;
    selectedDriverDomicile: number;
    isEditable: boolean;
  }