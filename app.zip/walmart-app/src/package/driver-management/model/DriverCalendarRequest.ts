export class DriverCalendarRequest {
  constructor(public fromdate: string, public todate: string) {}
}