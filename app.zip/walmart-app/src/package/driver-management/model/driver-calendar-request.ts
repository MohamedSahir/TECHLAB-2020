import {
    DriverCalendarEventRequest,
    DriverProfileBenefit,
    DriverWorkSchedule,
    DriverWorkWeek
  } from './';
  export interface DriverCalendarResponse {
    driverId: string;
    firstName: string;
    middleName?: string;
    lastName?: string;
    domicileId?: string;
    serviceCoCode: string;
    dcId: string;
    calendarEvents: DriverCalendarEventRequest[];
    driverBenefitProfile: DriverProfileBenefit;
    driverWorkSchedules: DriverWorkSchedule[];
    driverWorkWeeks: DriverWorkWeek[];
    departDayCode?: number;
    departTime?: string;
    scheduleTypes?: string[];
    driverTypes?: string[];
    driverIds?: string[];
    domiciles?: string[];
    driverStatusDesc: string;
    isDriverTerminated?: boolean;
    isWalmartDriver?: boolean;
    isEvent?: boolean;
  }