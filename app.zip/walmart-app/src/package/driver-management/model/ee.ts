import { LockErrorResponse } from './lock-error-response.model';
import { Lock } from './lock.model';

export class ActivateDedicatedDriverLockResponse {
    constructor(
        public lock: Lock[],
        public error?: LockErrorResponse[]
    ) { }
}
