export interface ActivateDedicatedDriversResponse {
    driverId: number;
    firstName: string;
    lastName: string;
    driverStatusCode?: number;
    sowwTsField: string;
    eowwTsField?: string;
    eowwDateField?: Date;
    eowwDateTime?: string;
}