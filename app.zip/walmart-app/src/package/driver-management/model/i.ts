export class CalendarEventDetail {
    selectedDate: Date;
    payPeriodStartDate: Date;
    payPeriodEndDate: Date;
  }