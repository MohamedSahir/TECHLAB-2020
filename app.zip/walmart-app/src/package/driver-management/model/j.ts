import { CalendarTS } from './';

export interface CalendarDateRange {
    currentTime: CalendarTS;
    fromDate: CalendarTS;
    toDate: CalendarTS;
}import { CalendarTS } from './';

export interface CalendarDateRange {
    currentTime: CalendarTS;
    fromDate: CalendarTS;
    toDate: CalendarTS;
}