export interface CalendarBindingEvent {
    id: string;
    title: string;
    start: string;
    end: string;
    color: string;
  }