export interface DriverWorkSchedule {
  driverWorkSchdlId: string;
  driverId: string;
  drivingScheduleCode: string;
  departTimeGrpId: string;
  drivingScheduleDesc: string;
  effectiveDate: Date;
  expirationDate: string;
  lastChangeUserId: string;
  lastChangeTs: string;
  driverWorkSchdlStatus: string;
}