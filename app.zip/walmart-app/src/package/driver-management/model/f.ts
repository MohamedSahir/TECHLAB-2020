export interface BaseLocationDetails {
    id: string;
    name: number;
}