export interface CalendarEventTypes {
    fullDayEvent: boolean;
    eventCategoryCode: number;
    eventCategoryDesc: string;
    code: string;
    abbreviation: string;
    alternateCode: null;
    description: string;
}