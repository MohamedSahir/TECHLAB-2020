import { SimpleChange, ViewEncapsulation } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { AuthZService, Capability, UserService } from '@transom/services';
import * as moment from 'moment-timezone';
import { of as ObservableOf } from 'rxjs';

import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from '@transom/ui';
import {
  driverCalendarAdminCapability,
  driverCalendarWriteCapability
} from '../../../constants/driver-management-constant';
import {
  AuthzServiceMock,
  DriverCalendarCommentsServiceMock,
  DriverManagementLockServiceMock,
  DriverManagementServiceMock,
  DriverProfileCommentsServiceMock,
  DriverQueryStaticServiceMock,
  MatDialogMock,
  ToastrMessageServiceMock,
  TranslateServiceMock,
  UserServiceMock
} from '../../../mock';
import { DriverUtils } from '../../../utils/driver-utils';
import {
  DriverManagementLockService,
  DriverManagementService,
  DriverQueryStaticService
} from '../../common-services';
import { DriverProfileCommentService } from '../../driver-profile/services/driver-profile-comments.service';
import { DriverCalendarViewDetailsService } from '../driver-calendar-view-details/services/driver-calendar-view-details.service';
import { DriverCalendarEventComponent } from './driver-calendar-event.component';
import { DriverCalendarEventFormService, DriverCalendarEventService } from './services';
declare var require: any;
const driverCalendarCommentsMockData = JSON.parse(
  JSON.stringify(require('../../../mock/json-files/driver-calendar-comment.json'))
);
const baseTerminalMockData = JSON.parse(
  JSON.stringify(require('../../../mock/json-files/baseTerminal.json'))
);
const calendarEventMockData = JSON.parse(
  JSON.stringify(require('../../../mock/json-files/calendar-events.json'))
);
const businessLocationMockData = JSON.parse(
  JSON.stringify(require('../../../mock/json-files/driver-query-profile.json'))
);
const driverCalendar = JSON.parse(
  JSON.stringify(require('../../../mock/json-files/driver-calendar.json'))
);
const eventDetails = JSON.parse(
  JSON.stringify(require('../../../mock/json-files/driverCalendarEventDetails.json'))
);
describe('DriverCalendarEventComponent', () => {
  let component: DriverCalendarEventComponent;
  let fixture: ComponentFixture<DriverCalendarEventComponent>;
  let driverQueryStaticServiceMock: DriverQueryStaticServiceMock;
  let driverCalendarCommentsServiceMock: DriverCalendarCommentsServiceMock;
  let matDialogRefMock: MatDialogMock;
  let driverProfileCommentsServiceMock: DriverProfileCommentsServiceMock;
  let userServiceMock: UserServiceMock;
  let driverManagementServiceMock: DriverManagementServiceMock;
  let driverManagementLockServiceMock: DriverManagementLockServiceMock;
  let authzServiceMock: AuthzServiceMock;
  let translateServiceMock: TranslateServiceMock;
  let toastrServiceMock: ToastrMessageServiceMock;
  beforeEach(async(() => {
    driverQueryStaticServiceMock = new DriverQueryStaticServiceMock();
    driverCalendarCommentsServiceMock = new DriverCalendarCommentsServiceMock();
    driverProfileCommentsServiceMock = new DriverProfileCommentsServiceMock();
    matDialogRefMock = new MatDialogMock();
    translateServiceMock = new TranslateServiceMock();
    toastrServiceMock = new ToastrMessageServiceMock();
    userServiceMock = new UserServiceMock();
    driverManagementServiceMock = new DriverManagementServiceMock();
    driverManagementLockServiceMock = new DriverManagementLockServiceMock();
    authzServiceMock = new AuthzServiceMock();
    TestBed.configureTestingModule({
      declarations: [DriverCalendarEventComponent]
    }).overrideComponent(DriverCalendarEventComponent, {
      set: {
        template: '<div></div>',
        encapsulation: ViewEncapsulation.Emulated,
        providers: [
          { provide: AuthZService, useValue: authzServiceMock },
          { provide: DriverQueryStaticService, useValue: driverQueryStaticServiceMock },
          { provide: DriverCalendarEventService, useValue: driverCalendarCommentsServiceMock },
          { provide: MatDialog, useValue: matDialogRefMock },
          { provide: DriverProfileCommentService, useValue: driverProfileCommentsServiceMock },
          { provide: UserService, useValue: userServiceMock },
          { provide: TranslateService, useValue: translateServiceMock },
          { provide: DriverManagementLockService, useValue: driverManagementLockServiceMock },
          { provide: DriverManagementService, useValue: driverManagementServiceMock },
          { provide: ToastrService, useValue: toastrServiceMock },
          FormBuilder,
          DriverCalendarEventFormService,
          DriverCalendarViewDetailsService,
          DriverUtils
        ]
      }
    });
  }));

  beforeEach(async(() => {
    fixture = TestBed.createComponent(DriverCalendarEventComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    const locks = [];
    locks.push({
      lockId: '1034',
      lockTimeStamp: moment(new Date()).format(),
      lockType: 'Driver',
      userId: 'test1',
      versionId: null
    });
    spyOn(driverManagementLockServiceMock, 'allDriversLock').and.returnValue(
      ObservableOf({
        error: [],
        lock: locks
      })
    );
  }));
  afterAll(() => {
    component = null;
    fixture.destroy();
  });
  it('should create', async(() => {
    expect(component).toBeTruthy();
  }));
  it('should initialize driver calendar event form', async(() => {
    expect(component.calendarEventForm.controls.eventTypeCode.value).toEqual(null);
  }));
  describe('static data binding', () => {
    it('should get and initialize calendar event list', async(() => {
      component.calendarEvents$.subscribe(response => {
        expect(response.length).toEqual(calendarEventMockData.length - 1);
      });
    }));
    it('should get and initialize location types data', async(() => {
      component.locationTypes$.subscribe(response => {
        expect(response).toEqual(baseTerminalMockData);
      });
    }));
    it('should get and initialize location types data', async(() => {
      component.locationTypes$.subscribe(response => {
        expect(response).toEqual(baseTerminalMockData);
      });
    }));
    
  });
  // it('should fetch comment details', async(() => {
  //   component.ngOnChanges({
  //     calendarEventDetails: new SimpleChange(undefined, eventDetails, false),
  //     driverDetails: new SimpleChange(undefined, driverCalendar, false),
  //     eventId: new SimpleChange(undefined, 1123, false)
  //   });
  //   expect(component.commentLists).toEqual(driverCalendarCommentsMockData.commentList.comments);
  // }));
  it('should open the comment popup on comment button click', async(() => {
    spyOn(matDialogRefMock, 'open').and.callThrough();
    component.eventId = null;
    component.openAddCommentDialog();
    expect(matDialogRefMock.open).toHaveBeenCalled();
  }));
  it('should set comment type to CE  on comment button click', async(() => {
    component.selectedDate = moment('2019-01-03 12:00 AM');
    component.driverDetails = driverCalendar;
    spyOn(component as any, 'setCommentRequestOption').and.callThrough();
    component.openAddCommentDialog();
    expect((component as any).commentRequestOption.commentType).toEqual('CE');
  }));

  it('should create an event on calling createCalendar Event', async(() => {
    const spy = spyOn(driverCalendarCommentsServiceMock, 'createCalendarEvent').and.returnValue(
      ObservableOf({ status: 200 })
    );
    component.ngOnChanges({
      calendarEventDetails: new SimpleChange(undefined, eventDetails, false),
      driverDetails: new SimpleChange(undefined, driverCalendar, false)
    });
    component.calendarEventForm.get('eventTypeCode').setValue('30');
    component.calendarEventForm.get('beginDate').reset({ value: new Date(), disabled: false });
    component.calendarEventForm.get('endDate').reset({ value: new Date(), disabled: false });
    component.calendarEventForm.get('beginTime').reset({ value: '08:00', disabled: false });
    component.calendarEventForm.get('endTime').reset({ value: '08:00', disabled: false });
    component.driverDetails = driverCalendar;
    component.calendarEventDetails = eventDetails;
    component.saveCalendarEvent(false);
    expect(spy).toHaveBeenCalled();
  }));

  it('should set end time for a full day event when change the end date to work week end date ', async(() => {
    const dateVal = { target: null, targetElement: null, value: moment('2019-01-03 12:00 AM') };
    (component as any).workWeek = driverCalendar.driverWorkWeeks;
    (component as any).reason = [{ fullDayEvent: true }];
    component.endDateChanges('s', dateVal);
    expect(component.calendarEventForm.controls.endTime.value).toEqual('05:30 PM');
  }));

  it('should set the driverDetails on ngOnChanges', async(() => {
    component.driverDetails = driverCalendar;
    component.ngOnChanges({
      driverDetails: new SimpleChange(undefined, component.driverDetails, false)
    });
    fixture.detectChanges();
    expect(component.driverDetails.driverWorkWeeks.length).toEqual(2);
  }));
  it('should enable save to be true when  edit event details', async(() => {
    (component as any).initializeEventForm();
    component.calendarEventForm.get('beginDate').setValue({ value: new Date(), disabled: false });
    component.calendarEventForm.get('endDate').setValue({ value: new Date(), disabled: false });
    (component as any).eventDetails = driverCalendarCommentsMockData.eventDetails;
    (component as any).workWeek = driverCalendar.driverWorkWeeks;
    component.calendarEventDetails = eventDetails;
    component.driverDetails = driverCalendar;
    (component as any).calendarEvents = calendarEventMockData;
    component.calendarEventForm.controls.eventTypeCode.setValue('30', { emitEvent: false });
    component.editEventDetails();
    expect(component.enableSave).toEqual(true);
  }));
  it('should not set the driverDetails on ngOnChanges', async(() => {
    component.ngOnChanges({
      driverDetails: new SimpleChange(undefined, undefined, false)
    });
    fixture.detectChanges();
    expect(component.driverDetails).not.toBeDefined();
  }));
  it('should set max end date to end date control', async(() => {
    component.driverDetails = driverCalendar;
    component.selectedDate = moment('2018-12-31T12:00:00.000Z').format('YYYY-MM-DD hh:mm A');
    (component as any).calendarEvents = calendarEventMockData;
    (component as any).workWeek = driverCalendar.driverWorkWeeks;
    component.reasonCodeChange('30');
    expect((component as any).maxEndDate).toEqual(moment('2019-01-03 17:30').toDate());
  }));

  it('should set end date for a partial day event when change the end date to work week end date ', async(() => {
    const dateVal = { target: null, targetElement: null, value: moment('2019-01-03 12:00 AM') };
    (component as any).workWeek = driverCalendar.driverWorkWeeks;
    (component as any).reason = [{ fullDayEvent: false }];
    component.endDateChanges('s', dateVal);
    expect(component.calendarEventForm.controls.endDate.value).toEqual(
      moment('2019-01-03 12:00 AM').toDate()
    );
  }));

  it('should set end time for a partial day event when change the end date', async(() => {
    const dateVal = { target: null, targetElement: null, value: moment('2018-12-31') };
    (component as any).workWeek = driverCalendar.driverWorkWeeks;
    (component as any).reason = [{ fullDayEvent: false }];
    component.endDateChanges('s', dateVal);
    expect(component.calendarEventForm.controls.endTime.value).toEqual(null);
  }));
  it('should set error to null in end time when change the begin date ', async(() => {
    const dateVal = {
      target: null,
      targetElement: null,
      value: moment('2018-12-12 12:00 AM').toDate()
    };
    (component as any).reason = [{ fullDayEvent: false }];
    (component as any).workWeek = driverCalendar.driverWorkWeeks;
    component.calendarEventForm.controls.endDate.setValue(moment('2018-12-13 12:00 AM').toDate());
    component.calendarEventForm.controls.beginTime.setValue('04:00');
    component.calendarEventForm.controls.endTime.setValue('04:15');
    component.beginDateChanges('s', dateVal);
    expect(component.calendarEventForm.controls.endTime.errors).toEqual(null);
  }));

  it('should not set the driverDetails on ngOnChanges', async(() => {
    component.ngOnChanges({
      driverDetails: new SimpleChange(undefined, undefined, false)
    });
    fixture.detectChanges();
    expect(component.driverDetails).not.toBeDefined();
  }));

  // it('should set  selected date if changes has calenderEvent details on ngOnChanges', async(() => {
  //   component.ngOnChanges({
  //     calendarEventDetails: new SimpleChange(undefined, eventDetails, false),
  //     driverDetails: new SimpleChange(undefined, driverCalendar, false)
  //   });
  //   fixture.detectChanges();
  //   expect(component.selectedDate).toEqual('2018-12-05');
  // }));
  it('should not set selected date if changes has calenderEvent but current value undefined on ngOnChanges', async(() => {
    component.ngOnChanges({
      calendarEventDetails: new SimpleChange(undefined, undefined, false)
    });
    fixture.detectChanges();
    expect(component.selectedDate).toEqual(undefined);
  }));
  it('should not set event id if current value undefined on ngOnChanges', async(() => {
    component.ngOnChanges({
      eventId: new SimpleChange(undefined, undefined, false)
    });
    fixture.detectChanges();
    expect(component.eventId).toEqual(undefined);
  }));

  it('should set begin date value in form if calender event details and driver details is present', async(() => {
    component.calendarEventDetails = eventDetails;
    component.ngOnChanges({
      calendarEventDetails: new SimpleChange(undefined, component.calendarEventDetails, false),
      driverDetails: new SimpleChange(undefined, driverCalendar, false)
    });
    expect(component.calendarEventForm.controls.beginDate.value).toEqual(
      moment('2018-12-05 00:00 AM').toDate()
    );
  }));
  it('should set form state to enable  when enable save is true', async(() => {
    component.calendarEventDetails = eventDetails;
    component.enableSave = true;

    expect(component.calendarEventForm.enabled).toEqual(true);
  }));

  it('should not set work week if driver details is undefined', async(() => {
    component.ngOnChanges({
      calendarEventDetails: new SimpleChange(undefined, undefined, false),
      driverDetails: new SimpleChange(undefined, undefined, false),
      eventId: new SimpleChange(undefined, undefined, false)
    });
    expect((component as any).workWeek).toEqual([]);
  }));
  it('should set form state to disabled  when enable save is false', async(() => {
    spyOn(driverManagementServiceMock, 'hasAnyOneCapabilityOf').and.returnValue(false);
    component.ngOnChanges({
      calendarEventDetails: new SimpleChange(undefined, eventDetails, false),
      driverDetails: new SimpleChange(undefined, driverCalendar, false)
    });
    fixture.detectChanges();
    component.enableSave = false;
    expect(component.calendarEventForm.disabled).toEqual(true);
  }));
  it('should set event id  on ngOnChanges', async(() => {
    component.calendarEventDetails = eventDetails;
    component.driverDetails = driverCalendar;
    component.ngOnChanges({
      eventId: new SimpleChange(undefined, 11680, false)
    });
    fixture.detectChanges();
    expect(component.eventId).toEqual(11680);
  }));

  it('should  set eventTypeCode to enabled if driver details is present but event id is not there', async(() => {
    component.ngOnChanges({
      calendarEventDetails: new SimpleChange(undefined, eventDetails, false),
      driverDetails: new SimpleChange(undefined, driverCalendar, false)
    });
    fixture.detectChanges();
    (component as any).eventClosed = false;
    expect(component.calendarEventForm.controls.eventTypeCode.enabled).toEqual(true);
  }));

  it('should set  save enable to true when user is admin and previous pay period', async(() => {
    (component as any).payPeriodStartDate = moment('2018-12-15 00:00 AM');
    (component as any).isAdminUser = true;
    (component as any).isWriteCapable = true;
    eventDetails.selectedDate = '2018-12-05';
    component.ngOnChanges({
      calendarEventDetails: new SimpleChange(undefined, eventDetails, false),
      driverDetails: new SimpleChange(undefined, driverCalendar, false)
    });
    fixture.detectChanges();
    expect(component.enableSave).toEqual(true);
  }));
  it('should set  save enable to true when user is write and not previous pay period', async(() => {
    (component as any).isAdminUser = false;
    (component as any).isWriteCapable = true;
    eventDetails.selectedDate = '2018-12-16';
    component.ngOnChanges({
      calendarEventDetails: new SimpleChange(undefined, eventDetails, false),
      driverDetails: new SimpleChange(undefined, driverCalendar, false)
    });
    fixture.detectChanges();
    expect(component.enableSave).toEqual(true);
  }));
  it('should set  save enable to false when user is write and in previous pay period', async(() => {
    spyOn(driverManagementServiceMock, 'hasAnyOneCapabilityOf').and.callFake(capability => {
      if (capability[0] === driverCalendarAdminCapability) return false;
      else if (capability[0] === driverCalendarWriteCapability) return true;
    });
    eventDetails.selectedDate = '2018-12-05';
    component.ngOnChanges({
      calendarEventDetails: new SimpleChange(undefined, eventDetails, false),
      driverDetails: new SimpleChange(undefined, driverCalendar, false)
    });

    expect(component.enableSave).toEqual(false);
  }));

  it('should reset begin date value to null on calling reset form', async(() => {
    component.resetEventForm();
    expect(component.calendarEventForm.controls.beginDate.value).toEqual(null);
  }));
  it('should reset location id value to initial value on calling reset form  if event id is there', async(() => {
    (component as any).eventDetails = driverCalendarCommentsMockData.eventDetails;
    component.eventId = 11345;
    component.driverDetails = driverCalendar;
    component.resetEventForm();
    expect(component.calendarEventForm.controls.locationId.value).toEqual(6833);
  }));

  it('should release lock on an event ', async(() => {
    const spy = spyOn(driverManagementLockServiceMock, 'releaseLock').and.returnValue(
      ObservableOf({ status: 200 })
    );
    component.isInitialState = true;
    component.closeSidePanel();
    expect(spy).toHaveBeenCalled();
  }));

  it('should return true if event id is present and form is touched and valid', async(() => {
    component.calendarEventForm.setValue(
      {
        locationId: 4036,
        locationType: 'DC',
        beginDate: new Date(),
        beginTime: '00:15 AM',
        endDate: new Date(),
        endTime: '00:30 AM',
        eventTypeCode: '3',
        officeType: 'tt'
      },
      { emitEvent: false }
    );
    component.eventId = 1123;
    component.enableSave = true;
    component.calendarEventForm.setErrors(null);
    component.calendarEventForm.markAsDirty();

    expect(component.disableSaveButton()).toEqual(true);
  }));
  it('should return false if event id is present and form is untouched and invalid', async(() => {
    component.calendarEventForm.setValue(
      {
        locationId: 4036,
        locationType: 'DC',
        beginDate: new Date(),
        beginTime: '00:15 AM',
        endDate: new Date(),
        endTime: '',
        eventTypeCode: '3',
        officeType: 'tt'
      },
      { emitEvent: false }
    );
    component.eventId = 1123;
    component.enableSave = false;
    component.calendarEventForm.markAsUntouched();

    component.disableSaveButton();
    expect(component.disableSaveButton()).toEqual(false);
  }));

  it('should return true if event id is not present and form is valid and enable is true', async(() => {
    component.calendarEventForm.setValue(
      {
        locationId: 4036,
        locationType: 'DC',
        beginDate: new Date(),
        beginTime: '00:15 AM',
        endDate: new Date(),
        endTime: '00:30 AM',
        eventTypeCode: '3',
        officeType: 'tt'
      },
      { emitEvent: false }
    );
    component.enableSave = true;
    component.calendarEventForm.setErrors(null);
    expect(component.disableSaveButton()).toEqual(true);
  }));
  it('should return false if event id is not present and form is invalid', async(() => {
    component.enableSave = false;
    component.calendarEventForm.setErrors({ invalid: true });
    expect(component.disableSaveButton()).toEqual(false);
  }));
  it('should  set end time to enabled if end date is work week end date', async(() => {
    component.driverDetails = driverCalendar;
    driverCalendarCommentsMockData.eventDetails.CalendarEvent[0].endTs.timeStamp = '2019-01-03';
    spyOn(driverCalendarCommentsServiceMock, 'fetchCalendarEvent').and.returnValue(
      ObservableOf(driverCalendarCommentsMockData.eventDetails)
    );

    expect(component.calendarEventForm.controls.endTime.enabled).toEqual(true);
  }));

  it('should set begin date disabled when selected date is previous payPeriod', async(() => {
    driverCalendarCommentsMockData.eventDetails.CalendarEvent[0].beginTs.timeStamp =
      '2018-12-12 00:00 AM';
    spyOn(driverCalendarCommentsServiceMock, 'fetchCalendarEvent').and.returnValue(
      ObservableOf(driverCalendarCommentsMockData.eventDetails)
    );
    component.ngOnChanges({
      calendarEventDetails: new SimpleChange(undefined, eventDetails, false),
      driverDetails: new SimpleChange(undefined, driverCalendar, false)
    });
    fixture.detectChanges();
    expect(component.calendarEventForm.controls.beginDate.disabled).toEqual(true);
  }));
  it('should  set endDate to enabled if driver details is present but event id is not there', async(() => {
    (component as any).eventClosed = true;
    expect(component.calendarEventForm.controls.endDate.enabled).toEqual(true);
  }));
  it('should  set form to disabled if end date is work week end date', async(() => {
    spyOn(driverManagementServiceMock, 'hasAnyOneCapabilityOf').and.callFake(capability => {
      if (capability[0] === driverCalendarAdminCapability) return false;
      else if (capability[0] === driverCalendarWriteCapability) return true;
    });
    driverCalendar.driverBenefitProfile.status = '5';
    eventDetails.selectedDate = '2018-12-05';

    component.ngOnChanges({
      driverDetails: new SimpleChange(undefined, driverCalendar, false),
      calendarEventDetails: new SimpleChange(undefined, eventDetails, false)
    });
    fixture.detectChanges();
    expect(component.calendarEventForm.disabled).toEqual(true);
  }));
});
