import {
    ChangeDetectorRef,
    Component,
    DoCheck,
    EventEmitter,
    Input,
    OnChanges,
    OnDestroy,
    OnInit,
    Output,
    SimpleChanges,
    ViewChild
  } from '@angular/core';
  import { FormGroup } from '@angular/forms';
  import { MatDatepickerInputEvent, MatDialog, MatDialogRef } from '@angular/material';
  import { MatSidenav } from '@angular/material';
  import { UserService } from '@transom/services';
  import * as moment from 'moment-timezone';
  import { Observable, Subscription } from 'rxjs';
  import { map, switchMap } from 'rxjs/operators';
  
  import { TranslateService } from '@ngx-translate/core';
  import { ConfirmDialogComponent, ToastrService } from '@transom/ui';
  import {
    driverCalendarAdminCapability,
    driverCalendarConstants,
    driverCalendarEventConstants,
    driverCalendarViewCapability,
    driverCalendarWriteCapability,
    driverProfileQueryConstants,
    locationTypeCode
  } from '../../../constants/driver-management-constant';
  import {
    DriverManagementLockService,
    DriverManagementService,
    DriverQueryStaticService
  } from '../../common-services';
  import { DriverCalendarViewDetailsService } from '../../driver-calendar-view/driver-calendar-view-details/services/driver-calendar-view-details.service';
  import { DriverProfileCommentWindowComponent } from '../../driver-profile/driver-profile-details/driver-profile-comment-window/driver-profile-comment-window.component';
  import { DriverProfileCommentService } from '../../driver-profile/services/driver-profile-comments.service';
  import {
    BaseTerminals,
    CalendarEventTypes,
    DriverCalendarEventDetails,
    DriverCalendarEventRequest,
    DriverCalendarResponse,
    DriverProfileCommentDetailsResponse,
    DriverProfileCommentMetaDataResponse,
    DriverWorkWeek,
    KeyValueModel,
    Lock,
    LockRequest
  } from '../../model';
  import { DriverCalendarEventFormService, DriverCalendarEventService } from './services';
  
  @Component({
    selector: 'driver-calendar-event',
    templateUrl: './driver-calendar-event.component.html',
    styleUrls: ['./driver-calendar-event.component.scss']
  })
  export class DriverCalendarEventComponent implements OnInit, OnChanges, OnDestroy {
    @ViewChild('sidenav') sidenav: MatSidenav;
    calendarEventForm: FormGroup;
    locationTypes$: Observable<BaseTerminals[]>;
    calendarEvents$: Observable<CalendarEventTypes[]>;
    locationIds$: Observable<KeyValueModel[]>;
    commentLists: DriverProfileCommentDetailsResponse[];
    showMore = false;
    isInitialState = true;
    selectedDate: Date;
    timeValues: String[];
    enableSave: boolean;
    hasReadCapability: boolean;
    payPeriodEndDate: Date;
    @Output() closeEvent = new EventEmitter();
    private commentsMetaData: DriverProfileCommentMetaDataResponse;
    private commentRequestOption: DriverProfileCommentDetailsResponse;
    private calendarEvents: CalendarEventTypes[];
    private eventDetails: DriverCalendarEventDetails;
    private reason: CalendarEventTypes[] = new Array<CalendarEventTypes>();
    private workWeek: DriverWorkWeek[] = [];
    private isAdminUser: boolean;
    private isWriteCapable: boolean;
    private payPeriodStartDate: Date;
    private beginTimeDataSubscription: Subscription;
    private endTimeDataSubscription: Subscription;
    private eventDataSubscription: Subscription;
    @Input() driverDetails: DriverCalendarResponse;
    @Input() eventId: number;
    @Input() calendarEventDetails;
    dialogRef;
    lockRequest: LockRequest;
  
    maxEndDate: string;
    minEndDate: string;
    maxBeginDate: string;
    minBeginDate: string;
    private eventClosed = false;
    abbreviation: string;
    displaydate: any;
    locationData: any;
  
    constructor(
      private cdr: ChangeDetectorRef,
      private calendarEventService: DriverCalendarEventFormService,
      private driverManagementService: DriverManagementService,
      private calendarViewDetailService: DriverCalendarViewDetailsService,
      private driverCalendarStaticService: DriverQueryStaticService,
      private driverCommentService: DriverProfileCommentService,
      private driverCalendarEventService: DriverCalendarEventService,
      private driverManagementLockService: DriverManagementLockService,
      private userService: UserService,
      private dialog: MatDialog,
      private translateService: TranslateService,
      private toastrService: ToastrService
    ) {}
    ngOnInit() {
      this.initializeComponent();
      this.driverCalendarStaticService.fetchBusinessLocation().subscribe((response: any) => {
        this.locationData = response;
      });
    }
  
    ngOnDestroy() {
      if (this.eventDataSubscription) this.eventDataSubscription.unsubscribe();
      if (this.endTimeDataSubscription) this.endTimeDataSubscription.unsubscribe();
      if (this.beginTimeDataSubscription) this.beginTimeDataSubscription.unsubscribe();
    }
  
    endDateChanges(type: string, event: MatDatepickerInputEvent<Date>): void {
      if (
        moment(event.value).format(driverCalendarEventConstants.dashedDate) ===
        moment(this.workWeek[0].eowwTs.timeStamp).format(driverCalendarEventConstants.dashedDate)
      ) {
        if (this.reason[0].fullDayEvent) {
          this.calendarEventForm.controls['endTime'].setValue(
            moment(this.workWeek[0].eowwTs.timeStamp).format(driverCalendarEventConstants.hourMinutes)
          );
          this.calendarEventForm.controls['endDate'].setValue(moment(event.value).toDate());
          this.calendarEventForm.controls['endTime'].enable({ onlySelf: true, emitEvent: false });
          this.calendarEventForm.controls['endDate'].enable({ onlySelf: true, emitEvent: false });
        } else {
          this.calendarEventForm.controls['endDate'].setValue(moment(event.value).toDate());
          this.calendarEventForm.controls['endDate'].enable({ onlySelf: true, emitEvent: false });
        }
      } else if (this.reason[0].fullDayEvent)
        this.calendarEventForm.controls['endTime'].disable({ onlySelf: true, emitEvent: false });
  
      this.calendarEventService.partialDayTotalHours(
        this.calendarEventForm,
        this.workWeek,
        this.reason[0].fullDayEvent
      );
    }
    reasonCodeChange(reasonCode): void {
      this.setDataOnReasonCodeChange(reasonCode);
    }
    beginDateChanges(type: string, event: MatDatepickerInputEvent<Date>): void {
      if (this.reason.length !== 0)
        this.calendarEventService.partialDayTotalHours(
          this.calendarEventForm,
          this.workWeek,
          this.reason[0].fullDayEvent
        );
    }
  
    ngOnChanges(changes: SimpleChanges): void {
      this.timeValues = this.calendarEventService.getEndTime(
        driverCalendarEventConstants.timeInterval
      );
      this.getUserCapabilities();
  
      if (
        changes.hasOwnProperty('calendarEventDetails') &&
        changes.calendarEventDetails.currentValue !== undefined &&
        changes.hasOwnProperty('driverDetails') &&
        changes.driverDetails.currentValue !== undefined &&
        changes.driverDetails.currentValue !== null
      ) {
        this.selectedDate = moment(changes.calendarEventDetails.currentValue.selectedDate).format(
          'YYYY-MM-DD'
        );
  
        this.displaydate = moment(changes.calendarEventDetails.currentValue.selectedDate).format(
          'MM/DD/YYYY'
        );
        this.payPeriodStartDate = moment(
          changes.calendarEventDetails.currentValue.payPeriodStartDate
        );
        this.payPeriodEndDate = moment(changes.calendarEventDetails.currentValue.payPeriodEndDate);
        this.driverDetails = changes.driverDetails.currentValue;
        this.workWeek = this.calendarEventService.getSelectedWorkWeek(
          this.driverDetails,
          this.selectedDate
        );
  
        this.setButtonAndControlState();
        this.setFormValuesBasedOnConditions();
      }
  
      if (
        changes.hasOwnProperty('eventId') &&
        changes.eventId.currentValue !== undefined &&
        changes.eventId.currentValue !== null
      ) {
        this.eventId = changes.eventId.currentValue;
        this.workWeek = this.calendarEventService.getSelectedWorkWeek(
          this.driverDetails,
          this.selectedDate
        );
        this.getEventDetails();
        this.fetchEventComments();
        this.setFormValuesBasedOnConditions();
      }
    }
    openAddCommentDialog(): void {
      this.setCommentRequestOption();
      this.dialogRef = this.dialog.open(DriverProfileCommentWindowComponent, {
        data: this.commentRequestOption,
        panelClass: 'transom-flush-dialog'
      });
  
      this.dialogRef.afterClosed().subscribe(result => {
        if (result) this.fetchEventComments();
      });
    }
    toggleCommetView(): boolean {
      return !this.showMore;
    }
  
    editEventDetails(): void {
      this.driverCalendarEventService
        .updateDriverCalendarEvent(this.createEventRequest(), this.eventId)
        .subscribe(response => {
          this.toastrService.persistentSuccess(
            this.translateService.instant('Event_Updated_Successfully')
          );
          this.closeSidePanel();
        });
    }
  
    saveCalendarEvent(eventId): void {
      if (!eventId)
        this.driverCalendarEventService
          .createCalendarEvent(this.createEventRequest())
          .subscribe(response => {
            this.toastrService.persistentSuccess(
              this.translateService.instant('Event_Saved_Successfully')
            );
  
            this.closeSidePanel();
          });
      else this.editEventDetails();
    }
    deleteEvent(): void {
      this.dialogRef = this.dialog.open(ConfirmDialogComponent, {
        data: {
          confirmText: this.translateService.instant('Delete_Confirmation'),
          title: this.translateService.instant('Confirmation')
        },
        disableClose: true
      });
      this.dialogRef.afterClosed().subscribe((confirm: boolean) => {
        if (confirm)
          if (this.validateBegindate(this.calendarEventForm))
            this.driverCalendarEventService
              .deleteCalendarEvent(this.eventId, this.eventDetails.CalendarEvent[0].versionId)
              .subscribe(response => {
                this.toastrService.persistentSuccess(
                  this.translateService.instant('Event_Deleted_Successfully')
                );
                this.closeSidePanel();
              });
      });
    }
  
    resetEventForm(): void {
      this.calendarEventForm.reset({ emitEvent: false });
      this.calendarEventForm.disable();
      this.calendarEventForm.controls.eventTypeCode.enable({ onlySelf: true, emitEvent: false });
      if (this.eventId)
        this.calendarEventForm = this.calendarEventService.bindFormValues(
          this.calendarEventForm,
          this.eventDetails,
          this.workWeek
        );
    }
    disableSaveButton(): boolean {
      if (this.eventId) return this.existingEventButtonControlState();
      else if (
        !this.enableSave &&
        this.calendarEventForm.status === driverCalendarEventConstants.invalid
      )
        return false;
      else if (
        this.enableSave &&
        this.calendarEventForm.status === driverCalendarEventConstants.valid
      )
        return true;
    }
  
    closeSidePanel(): void {
      if (this.isInitialState)
        this.driverManagementLockService
          .releaseLock(this.eventId, driverCalendarEventConstants.lockType)
          .subscribe();
      this.eventId = null;
  
      this.isInitialState = true;
  
      this.resetErrorsForControls();
      //
      this.eventDetails = null;
      this.enableSave = true;
      this.selectedDate = null;
      this.workWeek = [];
      this.commentLists = [];
      this.showMore = false;
      this.closeEvent.emit('closed');
    }
    checkEventType(typeCode): boolean {
      let isDriver = false;
      this.calendarEvents.filter(event => {
        if (typeCode === +event.code)
          if (event.eventCategoryCode === 1 || event.eventCategoryCode === 3)
            return (isDriver = true);
      });
      return isDriver;
    }
    getOfficeType(typeCode): void {
      this.calendarEvents.filter(event => {
        if (typeCode === +event.code) {
          this.calendarEventForm.controls.officeType.setValue(event.abbreviation, {
            emitEvent: false
          });
          return this.calendarEventForm;
        }
      });
    }
  
    private resetErrorsForControls(): void {
      this.calendarEventForm.setErrors(null, { emitEvent: false });
      this.calendarEventForm.enable({ onlySelf: true, emitEvent: false });
      this.calendarEventForm.reset({ onlySelf: true, emitEvent: false });
      this.calendarEventForm.updateValueAndValidity({ onlySelf: true, emitEvent: false });
      this.calendarEventForm.controls.locationId.setErrors(null, { emitEvent: false });
      this.calendarEventForm.controls.locationType.setErrors(null, { emitEvent: false });
      this.calendarEventForm.controls.beginDate.setErrors(null, { emitEvent: false });
      this.calendarEventForm.controls.endDate.setErrors(null, { emitEvent: false });
      this.calendarEventForm.controls.beginTime.setErrors(null, { emitEvent: false });
      this.calendarEventForm.controls.endTime.setErrors(null, { emitEvent: false });
      // this.calendarEventForm.controls.eventTypeCode.setErrors(null, { emitEvent: false });
      this.calendarEventForm.markAsUntouched();
    }
  
    private initializeComponent(): void {
      this.initializeEventForm();
      this.controlValueChanges();
      this.fetchStaticData();
    }
    private controlValueChanges() {
      console.log('form touched', this.calendarEventForm);
      this.calendarEventForm.get('eventTypeCode').valueChanges.subscribe(form => {
        console.log('reasoncode touched', this.calendarEventForm);
        if (this.eventDetails || form) {
          const code = form ? form : this.eventDetails.CalendarEvent[0].eventTypeCode.toString();
          this.setDataOnReasonCodeChange(code);
        }
      });
      this.calendarEventForm.get('locationType').valueChanges.subscribe(value => {
        if (value === locationTypeCode.distributionCenter && !this.driverDetails.isEvent)
          this.calendarEventForm.controls.locationId.setValue(
            this.driverDetails.dcId ? this.driverDetails.dcId : '',
            { emitEvent: false }
          );
        else if (
          this.driverDetails.isEvent &&
          value === this.driverDetails.calendarEvents[0].physicalLocation.locationType.trim()
        )
          this.calendarEventForm.controls.locationId.setValue(
            this.calendarEventForm.controls.locationId.value,
            { emitEvent: false }
          );
        else this.calendarEventForm.controls.locationId.setValue('', { emitEvent: false });
      });
      this.calendarEventForm.get('locationId').valueChanges.forEach(form => {
        this.calendarEventService.checkLocationIdIsValid(this.calendarEventForm, this.locationData);
      });
      this.beginTimeDataSubscription = this.calendarEventForm
        .get('beginTime')
        .valueChanges.subscribe(form => {
          if (this.reason.length !== 0 && this.workWeek.length !== 0)
            this.calendarEventService.partialDayTotalHours(
              this.calendarEventForm,
              this.workWeek,
              this.reason[0].fullDayEvent
            );
        });
  
      this.endTimeDataSubscription = this.calendarEventForm
        .get('endTime')
        .valueChanges.subscribe(form => {
          if (this.reason.length !== 0 && this.workWeek.length !== 0)
            this.calendarEventService.partialDayTotalHours(
              this.calendarEventForm,
              this.workWeek,
              this.reason[0].fullDayEvent
            );
        });
    }
    private getSortedCommentList(
      comments: DriverProfileCommentDetailsResponse[]
    ): DriverProfileCommentDetailsResponse[] {
      return comments.sort(function(a, b) {
        return new Date(b.lastChangeTs) > new Date(a.lastChangeTs) ? 1 : -1;
      });
    }
    private existingEventButtonControlState(): boolean {
      console.log(this.enableSave, this.calendarEventForm.valid, this.calendarEventForm.dirty);
      if (!this.enableSave && !this.calendarEventForm.valid && !this.calendarEventForm.dirty)
        return false;
      else if (this.enableSave && this.calendarEventForm.valid && this.calendarEventForm.dirty)
        return true;
    }
    private fetchStaticData(): void {
      this.locationTypes$ = this.calendarEventService.fetchBaseTerminalValues();
      this.calendarEvents$ = this.calendarEventService.fetchCalendarEventTypes().pipe(
        map(response => {
          return response.filter(event => {
            if (event.eventCategoryCode === +driverProfileQueryConstants.one) return event;
          });
        })
      );
      this.calendarEventService
        .fetchCalendarEventTypes()
        .subscribe(response => (this.calendarEvents = response));
      this.eventDataSubscription = this.calendarEventForm.controls[
        'locationType'
      ].valueChanges.subscribe(value => {
        // if (value === locationTypeCode.distributionCenter)
        //   this.calendarEventForm.controls.locationId.setValue(
        //     this.driverDetails.dcId
        //       ? this.driverDetails.dcId
        //       : this.calendarEventForm.controls.locationId.value,
        //     { emitEvent: false }
        //   );
        // else
        //   this.calendarEventForm.controls.locationId.setValue(
        //     this.calendarEventForm.controls.locationId.value
        //       ? this.calendarEventForm.controls.locationId.value
        //       : '',
        //     { emitEvent: false }
        //   );
        this.locationIds$ = this.driverCalendarStaticService.fetchBusinessLocation().pipe(
          map((response: KeyValueModel[]) => {
            return response != null
              ? response.filter(
                  domicile =>
                    domicile !== undefined && domicile !== null && domicile.id.trim() === value
                )
              : [];
          })
        );
      });
    }
    private setFormValuesBasedOnConditions(): void {
      if (this.selectedDate !== undefined && this.driverDetails !== undefined) {
        if (this.calendarEventForm && !this.eventId && !this.eventClosed) {
          console.log('setFormValueBasedOnCondition', this.calendarEventForm);
          this.calendarEventForm = this.calendarEventService.setFormValues(
            this.driverDetails,
            this.calendarEventForm,
            this.selectedDate
          );
          this.calendarEventForm.controls.eventTypeCode.updateValueAndValidity({ emitEvent: false });
          this.calendarEventForm.controls.eventTypeCode.setErrors(null, { emitEvent: false });
          this.calendarEventForm.setErrors({ invalid: true });
        }
  
        if (this.checkForReadOnlyUser()) this.calendarEventForm.disable();
        if (!this.enableSave) this.calendarEventForm.disable();
      }
    }
  
    checkTest() {
      this.calendarEventForm.controls.eventTypeCode.updateValueAndValidity({ emitEvent: false });
      this.calendarEventForm.controls.eventTypeCode.setErrors(null, { emitEvent: false });
    }
    checkForReadOnlyUser() {
      if (this.hasReadCapability && !this.isAdminUser && !this.isWriteCapable) return true;
    }
    private fetchEventComments() {
      this.driverCommentService
        .fetchDriverCommentMetaDataDetails(this.eventId, driverCalendarEventConstants.calendarComment)
        .pipe(
          switchMap(commentMetaDataResult => {
            this.commentsMetaData = commentMetaDataResult;
            if (commentMetaDataResult !== null)
              return this.driverCalendarEventService.fetchDriverCalendarComments(
                commentMetaDataResult.commentId
              );
            else return [];
          })
        )
        .subscribe(response => {
          if (response) this.commentLists = this.getSortedCommentList(response.comments);
        });
    }
  
    private initializeEventForm(): void {
      this.calendarEventForm = this.calendarEventService.intializeCalendarEventForm();
    }
    private getUserCapabilities(): void {
      this.isAdminUser = this.driverManagementService.hasAnyOneCapabilityOf([
        driverCalendarAdminCapability
      ]);
      this.isWriteCapable = this.driverManagementService.hasAnyOneCapabilityOf([
        driverCalendarWriteCapability
      ]);
      this.hasReadCapability = this.driverManagementService.hasAnyOneCapabilityOf([
        driverCalendarViewCapability
      ]);
    }
    private validateBegindate(calendarEventForm: FormGroup): boolean {
      if (
        this.isAdminUser ||
        (!this.calendarViewDetailService.isSelectedDateInPreviousPayperiod(
          moment(this.calendarEventForm.controls.beginDate.value).format(
            driverCalendarEventConstants.dashedDate
          ),
          this.payPeriodStartDate
        ) &&
          this.isWriteCapable)
      )
        return true;
      else {
        this.toastrService.info(
          'An event cannot be deleted if the begin date is in a previous pay period.'
        );
        return false;
      }
    }
    private setCommentRequestOption(): void {
      this.commentRequestOption = {
        commentId: this.commentsMetaData ? this.commentsMetaData.commentId : null,
        lastChangeUserId: this.userService.userId.trim(),
        commentType: driverCalendarEventConstants.commentType,
        objectId: this.eventId
      };
    }
    private setDataOnReasonCodeChange(reasonCode): void {
      this.reason = this.calendarEventService.filteredEvents(this.calendarEvents, reasonCode);
      if (this.reason.length > 0)
        this.calendarEventService.setValuesOnReasonChange(
          this.driverDetails,
          this.calendarEventForm,
          this.selectedDate,
          this.reason[0].fullDayEvent
        );
  
      this.minEndDate = this.calendarEventForm.controls.beginDate.value;
      if (this.workWeek.length !== 0)
        this.maxEndDate = moment(
          this.workWeek[0].driverWorkDays[this.workWeek[0].driverWorkDays.length - 1].endOfShift
            .timeStamp
        ).toDate();
      if (this.eventId)
        this.calendarEventForm.controls.beginDate.enable({ onlySelf: true, emitEvent: false });
    }
    private getEventDetails(): void {
      this.driverCalendarEventService
        .fetchCalendarEvent(this.eventId)
        .subscribe((result: DriverCalendarEventDetails) => {
          this.eventDetails = result;
          //this.selectedDate = this.calendarEventForm.controls.beginDate.value;
  
          console.log('Check');
          console.log(this.driverDetails);
          console.log(this.selectedDate);
          console.log(this.workWeek);
  
          this.calendarEventService.bindFormValues(
            this.calendarEventForm,
            this.eventDetails,
            this.workWeek
          );
          if (this.workWeek.length > 0) {
            this.maxEndDate = moment(this.workWeek[0].eowwTs.timeStamp).toDate();
            this.minEndDate = moment(this.workWeek[0].sowwTs.timeStamp).toDate();
            this.maxBeginDate = this.maxEndDate;
            this.minBeginDate = this.minEndDate;
          }
  
          if (
            this.calendarViewDetailService.isSelectedDateInPreviousPayperiod(
              moment(this.calendarEventForm.controls.beginDate.value).format(
                driverCalendarEventConstants.dashedDate
              ),
              this.payPeriodStartDate
            ) &&
            !this.isAdminUser
          )
            this.calendarEventForm.controls.beginDate.disable();
  
          this.lockEvent();
          this.setButtonAndControlState();
          this.checkDriverAndEventType();
          this.getOfficeType(this.eventDetails.CalendarEvent[0].eventTypeCode);
          if (!this.enableSave || this.checkForReadOnlyUser()) this.calendarEventForm.disable();
        });
    }
    private checkDriverAndEventType(): any {
      if (
        this.driverDetails.driverBenefitProfile.status === '5' ||
        (this.driverDetails.driverBenefitProfile.status === '6' && !this.isAdminUser)
      ) {
        this.enableSave = false;
        this.calendarEventForm.disable();
      }
      if (!this.checkEventType(this.eventDetails.CalendarEvent[0].eventTypeCode)) {
        this.enableSave = false;
        this.calendarEventForm.disable();
      }
    }
    private lockEvent(): void {
      const compRef = this;
      compRef.driverDetails.isEvent = true;
      compRef.swapEvents();
      const locks: Lock[] = [];
      locks.push({
        userId: compRef.userService.userId ? compRef.userService.userId.trim() : null,
        lockType: driverCalendarEventConstants.lockType,
        lockId: compRef.eventId.toString(),
        lockTimeStamp: moment(new Date()).format(),
        versionId: compRef.driverDetails.calendarEvents
          ? compRef.driverDetails.calendarEvents[0].versionId.toString()
          : null
      });
  
      compRef.driverManagementLockService.allDriversLock({ locks: locks }).subscribe(response => {
        // this.calendarEventForm.markAsUntouched();
        if (response)
          if (response.lock[0].userId.trim() !== compRef.userService.userId.trim()) {
            compRef.enableSave = false;
            compRef.isInitialState = false;
            compRef.calendarEventForm.disable();
  
            const confirmMsg =
              this.translateService.instant('lock_Event') +
              response.lock[0].lockId +
              this.translateService.instant('locked_User') +
              response.lock[0].userId;
            compRef.toastrService.error(confirmMsg);
          }
      });
    }
    private swapEvents() {
      console.log(this.eventId, 'gggg');
      const a = this.driverDetails.calendarEvents.filter(event => {
        if (event.eventId === this.eventId) {
          const eventIndex = this.driverDetails.calendarEvents.indexOf(event);
  
          [this.driverDetails.calendarEvents[0], this.driverDetails.calendarEvents[eventIndex]] = [
            this.driverDetails.calendarEvents[eventIndex],
            this.driverDetails.calendarEvents[0]
          ];
        }
      });
      console.log(a, 'hoyyyy', this.driverDetails);
    }
    private createEventRequest(): DriverCalendarEventRequest {
      return this.calendarEventService.mapFormValues(
        this.calendarEventForm,
        this.calendarEvents,
        this.driverDetails
      );
    }
    private setButtonAndControlState(): void {
      this.selectedDate = moment(this.selectedDate).format(driverCalendarConstants.dateDefaultFormat);
      this.payPeriodStartDate = moment(this.payPeriodStartDate).format(
        driverCalendarConstants.dateDefaultFormat
      );
  
      if (
        this.isWriteCapable &&
        this.calendarViewDetailService.isSelectedDateInPreviousPayperiod(
          this.selectedDate,
          this.payPeriodStartDate
        ) &&
        !this.isAdminUser
      ) {
        this.enableSave = false;
        this.calendarEventForm.disable();
      }
      if (
        this.calendarViewDetailService.isSelectedDateInPreviousPayperiod(
          this.selectedDate,
          this.payPeriodStartDate
        ) &&
        this.isAdminUser
      )
        this.enableSave = true;
  
      if (
        this.isWriteCapable &&
        !this.calendarViewDetailService.isSelectedDateInPreviousPayperiod(
          this.selectedDate,
          this.payPeriodStartDate
        )
      )
        this.enableSave = true;
  
      if (
        this.calendarViewDetailService.hasEventsWithinSelectedDate(
          this.selectedDate,
          this.driverDetails
        ) &&
        !this.calendarViewDetailService.hasWorkWeekWithinSelectedDate(
          this.selectedDate,
          this.driverDetails
        )
      )
        this.enableSave = false;
    }
  }
  