import { Injectable } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import * as moment from 'moment-timezone';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import remove = require('lodash/remove');
import {
  activateDedicatedDriverConstants,
  driverCalendarEventConstants,
  driverProfileQueryConstants,
  locationTypeCode
} from '../../../../constants/driver-management-constant';
import { DriverQueryStaticService } from '../../../common-services';
import {
  BaseTerminals,
  CalendarEventTypes,
  DriverCalendarEventDetails,
  DriverCalendarEventRequest,
  DriverCalendarResponse,
  DriverProfileDate,
  DriverWorkWeek
} from '../../../model';

import { UserService } from '@transom/services';
import { driverConstants } from '../../../../common/driver-constants';
import { driverQueryConstants } from '../../../../constants/driver-management-constant';
@Injectable()
export class DriverCalendarEventFormService {
  constructor(
    private formBuilder: FormBuilder,
    private driverCalendarStaticService: DriverQueryStaticService,
    private userService: UserService
  ) {}
  locations;
  intializeCalendarEventForm(): FormGroup {
    let driverCalendarForm: FormGroup;
    driverCalendarForm = this.formBuilder.group(
      {
        eventTypeCode: [null],
        locationId: [null],
        locationType: [null],
        beginDate: [null],
        beginTime: [null, [Validators.required]],
        endDate: [null],
        endTime: [null, [Validators.required]],
        officeType: null
      },
      { emitEvent: false }
    );
    console.log('Onit form');
    return driverCalendarForm;
  }
  setFormValues(
    driverDetails: DriverCalendarResponse,
    calendarForm: FormGroup,
    selectedDate
  ): FormGroup {
    calendarForm.patchValue(
      {
        locationId: driverDetails ? driverDetails.dcId : null,
        locationType: locationTypeCode.distributionCenter,
        beginDate: moment(selectedDate).toDate(),
        beginTime: null,
        endDate: moment(selectedDate).toDate(),
        endTime: null,
        officeType: null
      },
      { emitEvent: false }
    );
    calendarForm.disable({ onlySelf: true, emitEvent: false });
    calendarForm.controls.eventTypeCode.enable({ onlySelf: true, emitEvent: false });

    console.log(calendarForm, 'form');
    return calendarForm;
  }
  setValuesOnReasonChange(
    driverDetails: DriverCalendarResponse,
    calendarForm: FormGroup,
    selectedDate,
    isFullday?: boolean
  ): FormGroup {
    let selectedWorkWeek = [];
    selectedWorkWeek = this.getSelectedWorkWeek(driverDetails, selectedDate);
    calendarForm.patchValue({
      beginDate: moment(selectedDate).toDate(),

      locationId: calendarForm.controls.locationId ? calendarForm.controls.locationId.value : '',
      locationType: calendarForm.controls.locationType.value
        ? calendarForm.controls.locationType.value
        : locationTypeCode.distributionCenter
    });
    // if (driverDetails.isEvent) {
    //   calendarForm.controls.locationId.setValue(calendarForm.controls.locationId.value, {
    //     emitEvent: false
    //   });
    // }
    if (isFullday && selectedWorkWeek.length !== 0)
      this.setValuesForFullDay(calendarForm, selectedWorkWeek, selectedDate);
    else if (!isFullday && selectedWorkWeek.length !== 0)
      this.setValuesForPartialDay(calendarForm, selectedWorkWeek, selectedDate, driverDetails);

    return calendarForm;
  }

  fetchBaseTerminalValues(): Observable<BaseTerminals[]> {
    return this.driverCalendarStaticService
      .fetchBaseTerminals()
      .pipe(map(item => this.baseTerminalResponse(item)));
  }

  fetchCalendarEventTypes(): Observable<CalendarEventTypes[]> {
    return this.driverCalendarStaticService
      .fetchCalendarEventTypes()
      .pipe(map(item => this.calendarEventResponse(item)));
  }

  mapFormValues(
    driverCalendarForm: FormGroup,
    calendarEvents: CalendarEventTypes[],
    driverDetails: DriverCalendarResponse
  ): DriverCalendarEventRequest {
    const calendarEventType = this.filteredEvents(
      calendarEvents,
      driverCalendarForm.value.eventTypeCode
    );
    let eventDetails: DriverCalendarEventRequest;
    eventDetails = {
      eventId: driverDetails.isEvent ? driverDetails.calendarEvents[0].eventId : 0,
      eventTypeCode: driverCalendarForm.value.eventTypeCode,
      commentId: driverDetails.calendarEvents ? driverDetails.calendarEvents[0].commentId : null,
      beginTs: this.createBeginTimeStamp(
        driverCalendarForm.controls.beginDate.value,
        driverCalendarForm.controls.beginTime.value
      ),
      endTs: this.createBeginTimeStamp(
        driverCalendarForm.controls.endDate.value,
        driverCalendarForm.controls.endTime.value
      ),
      lastChangeUserId: this.userService.userId ? this.userService.userId.trim() : null,
      versionId: driverDetails.calendarEvents ? driverDetails.calendarEvents[0].versionId : 0,
      owningLocation: {
        locationId: +driverDetails.domicileId,
        locationType: driverProfileQueryConstants.locationTypeCode_DISP
      },
      physicalLocation: {
        locationId: driverCalendarForm.value.locationId,
        locationType: driverCalendarForm.value.locationType
      },
      fullDayEvent: calendarEventType[0].fullDayEvent,
      associatedDrivers: [+driverDetails.driverId]
    };
    eventDetails.endTs.timeStamp = moment(eventDetails.endTs.timeStamp).format(
      activateDedicatedDriverConstants.dbDateFormat
    );
    eventDetails.beginTs.timeStamp = moment(eventDetails.beginTs.timeStamp).format(
      activateDedicatedDriverConstants.dbDateFormat
    );
    return eventDetails;
  }
  checkLocationIdIsValid(form: FormGroup, locationData): FormGroup {
    if (
      form.controls.locationId.value !== null &&
      form.controls.locationId.value &&
      form.controls.locationId.value !== ''
    )
      if (
        !form.controls.locationId.value.toString().match(driverConstants.regExpressions.numeric)
      ) {
        form.controls.locationId.setErrors({ numeric: true });
      } else if (form.controls.locationId.value.length > driverQueryConstants.driverIdLength)
        form.controls.locationId.setErrors({ maxLength: true });
      else {
        // this.driverCalendarStaticService.fetchBusinessLocation().subscribe((response: any) => {
        this.locations = locationData.filter(value => {
          return (
            value.id.trim() === form.value.locationType &&
            value.name === +form.controls.locationId.value
          );
        });
        console.log(this.locations);
        if (this.locations.length === 0) {
          form.controls.locationId.markAsTouched();
          form.controls.locationId.setErrors({ invalidId: true });
        } else {
          form.controls.locationId.markAsUntouched();
          form.controls.locationId.setErrors(null);
          console.log('herer');
        }
        // });
      }
    return form;
  }
  getSelectedWorkWeek(driverDetails: DriverCalendarResponse, selectedDate: Date): DriverWorkWeek[] {
    if (driverDetails && driverDetails.driverWorkWeeks !== null)
      return driverDetails.driverWorkWeeks;
    else return [];
  }
  bindFormValues(
    driverCalendarForm: FormGroup,
    eventDetails: DriverCalendarEventDetails,
    workWeek: DriverWorkWeek[]
  ): FormGroup {
    driverCalendarForm.enable({ onlySelf: true, emitEvent: false });
    const beginDate = moment(eventDetails.CalendarEvent[0].beginTs.timeStamp).format(
      driverCalendarEventConstants.dashedDate
    );
    const endDate = moment(eventDetails.CalendarEvent[0].endTs.timeStamp).format(
      driverCalendarEventConstants.dashedDate
    );
    let endTime = moment(eventDetails.CalendarEvent[0].endTs.timeStamp).format(
      driverCalendarEventConstants.hourMinutes
    );
    let beginTime = moment(eventDetails.CalendarEvent[0].beginTs.timeStamp).format(
      driverCalendarEventConstants.hourMinutes
    );

    if (beginTime.substring(0, 2) === '12') {
      beginTime = beginTime.replace('12', '00');
    }
    if (endTime.substring(0, 2) === '12') endTime = endTime.replace('12', '00');

    driverCalendarForm.setValue(
      {
        eventTypeCode: eventDetails.CalendarEvent[0].eventTypeCode.toString(),
        locationId: eventDetails.CalendarEvent[0].physicalLocation.locationId,
        locationType: eventDetails.CalendarEvent[0].physicalLocation.locationType.trim(),
        beginDate: moment(beginDate).toDate(),
        beginTime: beginTime,
        endDate: moment(endDate).toDate(),
        endTime: endTime,
        officeType: null
      }
      
    );
    if (eventDetails.CalendarEvent[0].fullDayEvent) {
      driverCalendarForm.controls.endTime.disable({ onlySelf: true, emitEvent: false });
      driverCalendarForm.controls.beginTime.disable({ onlySelf: true, emitEvent: false });
    }
    // added newly
    if (
      workWeek.length > 0 &&
      moment(driverCalendarForm.controls.endDate.value).format(
        driverCalendarEventConstants.dashedDate
      ) === moment(workWeek[0].eowwTs.timeStamp).format(driverCalendarEventConstants.dashedDate)
    )
      driverCalendarForm.controls.endTime.enable({ onlySelf: true, emitEvent: false });
    return driverCalendarForm;
  }
  filteredEvents(calendarEvents, typeCode): CalendarEventTypes[] {
    return calendarEvents.filter(item => {
      return item.code === typeCode;
    });
  }

  partialDayTotalHours(form: FormGroup, workWeek: DriverWorkWeek[], isFullDay: boolean): FormGroup {
    const errors = [];
    if (
      form.controls.beginDate.value &&
      form.controls.beginTime.value &&
      form.controls.endDate.value &&
      form.controls.endTime.value
    ) {
      const beginTimeStamp = this.createBeginTimeStamp(
        form.controls.beginDate.value,
        form.controls.beginTime.value
      );
      const endTimeStamp = this.createBeginTimeStamp(
        form.controls.endDate.value,
        form.controls.endTime.value
      );
      const duration = moment.duration(
        moment(endTimeStamp.timeStamp).diff(moment(beginTimeStamp.timeStamp))
      );
      const hours = duration.asHours();
      const requiredValues = {
        form: form,
        workWeek: workWeek[0],
        fullDayEvent: isFullDay,
        errors: errors
      };
      this.checkBeginTime(requiredValues);

      if (workWeek.length !== 0)
        this.beginAndEndDateWithinWorkWeek(
          workWeek[0],
          beginTimeStamp.timeStamp,
          endTimeStamp.timeStamp,
          form
        );
      this.validateMonthDuration(form);
      if (!isFullDay) {
        if (form.controls.beginDate.value.getTime() === form.controls.endDate.value.getTime())
          if (form.controls.beginTime.value >= form.controls.endTime.value) {
            errors.push({ timeGreater: true });
            form.controls.endTime.markAsTouched();
            form.controls.endTime.setErrors([Object.assign.apply(null, errors)]);
            this.setErrorForTotalTime(hours, form, errors, isFullDay);
          } else {
            const index = errors.indexOf({ timeGreater: true });
            if (index > -1) errors.splice(index, 1);
            this.setErrorForTotalTime(hours, form, errors, isFullDay);
          }
        else this.setErrorForTotalTime(hours, form, errors, isFullDay);
      }
      return form;
    }
  }
  private checkBeginTime(values: {
    form: FormGroup;
    workWeek: DriverWorkWeek;
    fullDayEvent: boolean;
    errors: any[];
  }): FormGroup {
    if (values.fullDayEvent) {
      const endDateErr = values.form.controls.endDate.errors;
      if (
        moment(values.form.controls.endDate.value).format(
          driverCalendarEventConstants.dashedDate
        ) ===
        moment(
          values.workWeek.driverWorkDays[values.workWeek.driverWorkDays.length - 1].endOfShift
            .timeStamp
        ).format(driverCalendarEventConstants.dashedDate)
      )
        if (
          values.form.controls.endTime.value !==
            moment(values.workWeek.eowwTs.timeStamp).format('hh:mm A') &&
          values.form.controls.endTime.value !==
            moment(values.workWeek.sowwTs.timeStamp).format('hh:mm A')
        ) {
          values.errors.push({ wwkEndTimeErr: true });
          values.form.controls.endTime.markAsTouched();
          values.form.controls.endTime.setErrors([Object.assign.apply(null, values.errors)]);
        } else this.deleteErrorObject(values.errors, 'wwkEndTimeErr', values.form.controls.endTime);
      else if (
        moment(values.form.controls.endDate.value).isSame(values.form.controls.beginDate.value)
      )
        this.setErrorsForControls(endDateErr, values.form.controls.endDate, { endDateLess: true });
      else this.deleteErrorObject(values.errors, 'endDateLess', values.form.controls.endDate);
      return values.form;
    }
  }
  getEndTime(minute: number): String[] {
    const increment = minute;
    const times = [];
    let startTime = 0;
    const ap = ['AM', 'PM'];

    for (let i = 0; startTime < 24 * 60; i++) {
      const hh = Math.floor(startTime / 60);
      const mm = startTime % 60;
      times[i] =
        ('0' + (hh % 12)).slice(-2) + ':' + ('0' + mm).slice(-2) + ' ' + ap[Math.floor(hh / 12)];
      startTime = startTime + increment;
    }
    return times;
  }
  private calendarEventResponse = (response: CalendarEventTypes[]): CalendarEventTypes[] => {
    return response;
  };
  private baseTerminalResponse = (response: BaseTerminals[]): BaseTerminals[] => {
    return response.filter(locationType => {
      if (
        locationType.code === locationTypeCode.centerPoint ||
        locationType.code === locationTypeCode.distributionCenter ||
        locationType.code === locationTypeCode.vendor ||
        locationType.code === locationTypeCode.store
      )
        return locationType;
    });
  };
  private createBeginTimeStamp(formDate, formTime): DriverProfileDate {
    let timeStamp = moment(formDate).toDate();
    timeStamp = moment(timeStamp).format(driverCalendarEventConstants.dashedDate);
    timeStamp = timeStamp + ' ' + formTime;
    return {
      timeStamp: timeStamp,
      isDirty: false,
      timeZone: null
    };
  }
  private setValuesForFullDay(
    calendarForm: FormGroup,
    selectedWorkWeek: DriverWorkWeek[],
    selectedDate
  ): FormGroup {
    selectedDate = moment(selectedDate);
    calendarForm.controls['beginTime'].setValue(
      moment(selectedWorkWeek[0].sowwTs.timeStamp).format(driverCalendarEventConstants.hourMinutes),
      { emitEvent: false }
    );
    let endValue = Object.assign({}, selectedDate);
    endValue = moment(endValue).add(1, 'days');
    calendarForm.controls.locationId.enable({ onlySelf: true, emitEvent: false });
    calendarForm.controls.locationType.enable({ onlySelf: true, emitEvent: false });
    calendarForm.controls.beginTime.disable({ onlySelf: true, emitEvent: false });
    calendarForm.controls.beginDate.disable({ onlySelf: true, emitEvent: false });
    calendarForm.controls.endTime.disable({ onlySelf: true, emitEvent: false });
    if (
      moment(selectedDate).format(driverCalendarEventConstants.dashedDate) ===
        moment(selectedWorkWeek[0].eowwTs.timeStamp).format(
          driverCalendarEventConstants.dashedDate
        ) ||
      moment(endValue).format(driverCalendarEventConstants.dashedDate) ===
        moment(selectedWorkWeek[0].eowwTs.timeStamp).format(driverCalendarEventConstants.dashedDate)
    ) {
      if (
        moment(endValue).format(driverCalendarEventConstants.dashedDate) ===
        moment(selectedWorkWeek[0].eowwTs.timeStamp).format(driverCalendarEventConstants.dashedDate)
      ) {
        calendarForm.controls['endTime'].setValue(
          moment(selectedWorkWeek[0].sowwTs.timeStamp).format(
            driverCalendarEventConstants.hourMinutes
          ),
          { emitEvent: false }
        );
        calendarForm.controls['endDate'].setValue(endValue.toDate(), { emitEvent: false });
      } else {
        calendarForm.controls['endDate'].setValue(selectedDate.toDate(), { emitEvent: false });
        calendarForm.controls['endTime'].setValue(
          moment(selectedWorkWeek[0].eowwTs.timeStamp).format(
            driverCalendarEventConstants.hourMinutes
          ),
          { emitEvent: false }
        );
      }
      calendarForm.controls.endDate.enable({ onlySelf: true, emitEvent: false });
      calendarForm.controls.endTime.enable({ onlySelf: true, emitEvent: false });
    } else if (
      moment(selectedDate).format(driverCalendarEventConstants.dashedDate) !==
      moment(selectedWorkWeek[0].eowwTs.timeStamp).format(driverCalendarEventConstants.dashedDate)
    ) {
      calendarForm.controls['endTime'].setValue(
        moment(selectedWorkWeek[0].sowwTs.timeStamp).format(
          driverCalendarEventConstants.hourMinutes
        ),
        { emitEvent: false }
      );
      calendarForm.controls['endDate'].setValue(endValue.toDate(), {
        emitEvent: false
      });
      calendarForm.controls.endDate.enable({ onlySelf: true, emitEvent: false });
    }
    return calendarForm;
  }
  private setValuesForPartialDay(
    calendarForm: FormGroup,
    selectedWorkWeek: DriverWorkWeek[],
    selectedDate,
    driverDetails
  ): FormGroup {
    selectedDate = moment(selectedDate);
    let endValue = Object.assign({}, selectedDate);
    endValue = moment(endValue).add(1, 'days');
    calendarForm.controls.beginTime.enable({ onlySelf: true, emitEvent: false });
    calendarForm.controls.locationId.enable({ onlySelf: true, emitEvent: false });
    calendarForm.controls.locationType.enable({ onlySelf: true, emitEvent: false });
    calendarForm.controls.endTime.enable({ onlySelf: true, emitEvent: false });
    calendarForm.controls.endDate.enable({ onlySelf: true, emitEvent: false });
    // calendarForm.controls['endDate'].setValue(null, { onlySelf: true, emitEvent: false });
    calendarForm.controls['beginDate'].setValue(selectedDate.toDate(), { emitEvent: false });
    if (driverDetails.isEvent) {
      calendarForm.controls.beginTime.setValue(
        calendarForm.controls.beginTime.value ? calendarForm.controls.beginTime.value : null,
        { onlySelf: true, emitEvent: false }
      );
      if (
        moment(endValue).format(driverCalendarEventConstants.dashedDate) ===
        moment(selectedWorkWeek[0].eowwTs.timeStamp).format(driverCalendarEventConstants.dashedDate)
      ) {
        calendarForm.controls['endTime'].setValue(
          moment(selectedWorkWeek[0].sowwTs.timeStamp).format(
            driverCalendarEventConstants.hourMinutes
          ),
          { emitEvent: false }
        );
      } else {
        calendarForm.controls.endTime.setValue(
          calendarForm.controls.endTime.value ? calendarForm.controls.endTime.value : null,

          { emitEvent: false }
        );
        // calendarForm.controls['endDate'].setValue(selectedDate.toDate(), { emitEvent: false });
      }
    } else if (
      moment(selectedDate).format(driverCalendarEventConstants.dashedDate) !==
      moment(
        selectedWorkWeek[0].driverWorkDays[selectedWorkWeek[0].driverWorkDays.length - 1].endOfShift
          .timeStamp
      ).format(driverCalendarEventConstants.dashedDate)
    ) {
      calendarForm.controls['endDate'].setValue(selectedDate.add(1, 'days').toDate(), {
        emitEvent: false
      });
    } else {
      calendarForm.controls.beginTime.setValue(null, { emitEvent: false });
      calendarForm.controls.endTime.setValue(null, { emitEvent: false });
      calendarForm.controls['endDate'].setValue(selectedDate.toDate(), { emitEvent: false });
    }
    return calendarForm;
  }

  private setErrorForTotalTime(hours, form: FormGroup, errors, isfullDay): FormGroup {
    if (hours > driverCalendarEventConstants.totalHours && !isfullDay) {
      errors.push({ totalTimeError: true });
      form.controls.endTime.setErrors([Object.assign.apply(null, errors)]);
      form.controls.endTime.markAsTouched();
    } else this.deleteErrorObject(errors, 'totalTimeError', form.controls.endTime);

    return form;
  }
  private beginAndEndDateWithinWorkWeek(
    selectedWorkWeek: DriverWorkWeek,
    eventStartDate,
    eventEndDate,
    form: FormGroup
  ): FormGroup {
    eventStartDate = moment(eventStartDate).format(driverCalendarEventConstants.dateWithHourMin);
    eventEndDate = moment(eventEndDate).format(driverCalendarEventConstants.dateWithHourMin);
    const endDateErrors: any =
      form.controls.endDate.errors !== null ? form.controls.endDate.errors : [];
    if (
      eventStartDate >=
        moment(selectedWorkWeek.originalWorkWeekStartTs.timeStamp).format(
          driverCalendarEventConstants.dateWithHourMin
        ) &&
      moment(selectedWorkWeek.originalWorkWeekEndTs.timeStamp).format(
        driverCalendarEventConstants.dateWithHourMin
      ) >= eventStartDate &&
      (eventEndDate >=
        moment(selectedWorkWeek.originalWorkWeekStartTs.timeStamp).format(
          driverCalendarEventConstants.dateWithHourMin
        ) &&
        moment(selectedWorkWeek.originalWorkWeekEndTs.timeStamp).format(
          driverCalendarEventConstants.dateWithHourMin
        ) >= eventEndDate)
    ) {
      remove(endDateErrors, {
        notInWorkWeek: true
      });
      if (endDateErrors === null || endDateErrors.length === 0) {
        form.controls.endDate.setErrors(null);
        form.controls.endDate.markAsUntouched();
      }
    } else {
      endDateErrors.push({ notInWorkWeek: true });
      form.controls.endDate.markAsTouched();
      form.controls.endDate.setErrors([Object.assign.apply(null, endDateErrors)]);
    }
    if (
      moment(eventStartDate).format(driverCalendarEventConstants.dashedDate) >
      moment(eventEndDate).format(driverCalendarEventConstants.dashedDate)
    ) {
      endDateErrors.push({ endTimeLess: true });
      const a = Object.assign.apply(null, endDateErrors);
      form.controls.endDate.markAsTouched();
      form.controls.endDate.setErrors([a]);
    } else this.deleteErrorObject(endDateErrors, 'endTimeLess', form.controls.endDate);
    return form;
  }
  private deleteErrorObject(errors, errorType: string, control): void {
    remove(errors, {
      errorType: true
    });
    if (errors === null || errors.length === 0) {
      control.setErrors(null);
      control.markAsUntouched();
    }
  }
  private validateMonthDuration(form: FormGroup): FormGroup {
    const startDate = moment(form.controls.beginDate.value).format(
      driverCalendarEventConstants.dateWithAMPM
    );

    const endDate = moment(form.controls.endDate.value).format(
      driverCalendarEventConstants.dateWithAMPM
    );
    const now = moment();
    const beginDateDiff = now.diff(startDate, 'months', true);
    const endDateDiff = now.diff(endDate, 'months', true);
    const errors = form.controls.endDate.errors;
    if (beginDateDiff > driverCalendarEventConstants.monthsInYear)
      form.controls.beginDate.setErrors({ monthsAhead: true });
    else form.controls.beginDate.setErrors(null);
    if (-endDateDiff > driverCalendarEventConstants.monthsInYear) {
      this.setErrorsForControls(errors, form.controls.endDate, { monthsBehind: true });
    } else this.deleteErrorObject(errors, 'monthsBehind', form.controls.endDate);

    return form;
  }
  private setErrorsForControls(errors, controls, errObj) {
    if (errors === null) errors = [];
    errors.push(errObj);
    controls.markAsTouched();
    controls.setErrors([Object.assign.apply(null, errors)]);
  }
}
