import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { async, getTestBed, TestBed } from '@angular/core/testing';
import { TranslateService } from '@ngx-translate/core';
import { EnvService, UserService } from '@transom/services';
import { ToastrService } from '@transom/ui';
import { LoadingDialogService } from '../../../../common/loading-dialog/loading-dialog.service';
import {
  DRIVER_CALENDAR_COMMENT_LIST_URL,
  DRIVER_CALENDAR_EVENT_COMMENT_URL,
  DRIVER_CALENDAR_EVENT_SAVE_URL,
  DRIVER_PROFILE_COMMENTS_DETAILS_END_URL
} from '../../../../common/urls';
import {
  LoadingDialogServiceMock,
  ToastrMessageServiceMock,
  TranslateServiceMock,
  UserServiceMock
} from '../../../../mock';
import { DriverUtils } from '../../../../utils/driver-utils';
import { DriverCalendarEventService } from './driver-calendar-event.service';
declare var require: any;
const driverCalendarCommentsMockData = require('../../../../mock/json-files/driver-calendar-comment.json');

describe('DriverCalendarEventService', () => {
  let mockBackend: HttpTestingController;
  let translateServiceMock: TranslateServiceMock;
  let toastrServiceMock: ToastrMessageServiceMock;
  let driverCalendarEventService: DriverCalendarEventService;
  let loadingServiceMock: LoadingDialogServiceMock;
  let userServiceMock: UserServiceMock;
  const marketPrefixValue = '/us';
  const envServiceMock = {
    marketPrefix: marketPrefixValue,
    headerDefaults: { acceptLanguage: 'en-US' },
    market: 'us'
  };
  const dialogLoaderRef = {
    close: jasmine.createSpy('close')
  };
  beforeEach(async(() => {
    translateServiceMock = new TranslateServiceMock();
    toastrServiceMock = new ToastrMessageServiceMock();
    loadingServiceMock = new LoadingDialogServiceMock();
    userServiceMock = new UserServiceMock();
    TestBed.configureTestingModule({
      providers: [
        DriverCalendarEventService,
        DriverUtils,
        { provide: ToastrService, useValue: toastrServiceMock },
        { provide: TranslateService, useValue: translateServiceMock },
        { provide: LoadingDialogService, useValue: loadingServiceMock },
        { provide: EnvService, useValue: envServiceMock },
        { provide: UserService, useValue: userServiceMock }
      ],
      imports: [HttpClientTestingModule]
    });
    mockBackend = getTestBed().get(HttpTestingController);
    driverCalendarEventService = getTestBed().get(DriverCalendarEventService);
    (driverCalendarEventService as any)['dialogLoader'] = dialogLoaderRef;
  }));
  describe('Comment details service', () => {
    it('should give calendar event comment details if service is success', async(() => {
      const url =
        envServiceMock.marketPrefix.toLowerCase() +
        DRIVER_CALENDAR_COMMENT_LIST_URL +
        '?commentId=896502650';
      driverCalendarEventService
        .fetchDriverCalendarComments(896502650)
        .subscribe((successResult: any) => {
          expect(successResult.driverCommentDetails.comments.length).toEqual(
            driverCalendarCommentsMockData.commentList.comments.length
          );
        });
      mockBackend
        .expectOne({
          url: url,
          method: 'GET'
        })
        .flush({
          status: 200,
          driverCommentDetails: driverCalendarCommentsMockData.commentList
        });
    }));
    it('it should show no record info message when no comment details', async(() => {
      const url =
        envServiceMock.marketPrefix.toLowerCase() +
        DRIVER_CALENDAR_COMMENT_LIST_URL +
        '?commentId=896502650';
      const previewResponse = { status: 304 };
      driverCalendarEventService
        .fetchDriverCalendarComments(896502650)
        .subscribe((successResult: any) => {
          expect(successResult).toEqual({ status: 304 });
        });
      mockBackend
        .expectOne({
          url: url,
          method: 'GET'
        })
        .flush(previewResponse);
    }));
    it('should show custom error message if comment details service response status is 404', async(() => {
      spyOn(toastrServiceMock, 'info').and.callThrough();
      const customErrorMessage = 'test';
      const url =
        envServiceMock.marketPrefix.toLowerCase() +
        DRIVER_CALENDAR_COMMENT_LIST_URL +
        '?commentId=896502650';
      driverCalendarEventService
        .fetchDriverCalendarComments(896502650)
        .subscribe(() => expect(toastrServiceMock.info).toHaveBeenCalledWith(customErrorMessage));
      mockBackend
        .expectOne({
          url: url,
          method: 'GET'
        })
        .flush({ message: 'Error' }, { status: 404, statusText: 'No record found' });
    }));
    it('should show error message if comment details service response status is 500', async(() => {
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const customErrorMessage = 'test';
      const url =
        envServiceMock.marketPrefix.toLowerCase() +
        DRIVER_CALENDAR_COMMENT_LIST_URL +
        '?commentId=896502650';
      driverCalendarEventService
        .fetchDriverCalendarComments(896502650)
        .subscribe(() => expect(toastrServiceMock.error).toHaveBeenCalledWith(customErrorMessage));
      mockBackend
        .expectOne({
          url: url,
          method: 'GET'
        })
        .flush({ message: 'Error' }, { status: 500, statusText: 'Server Error' });
    }));

    it('should show toastr info message if comment details service response status is 409', async(() => {
      spyOn(toastrServiceMock, 'info').and.callThrough();
      const customErrorMessage = 'Event must begin and end in the same work week.';
      const error = {
        Errors: [
          {
            id: 409,
            message: 'Event must begin and end in the same work week.',
            status: 'CONFLICT'
          }
        ]
      };
      const url =
        envServiceMock.marketPrefix.toLowerCase() +
        DRIVER_CALENDAR_COMMENT_LIST_URL +
        '?commentId=896502650';
      driverCalendarEventService
        .fetchDriverCalendarComments(896502650)
        .subscribe(() => expect(toastrServiceMock.info).toHaveBeenCalledWith(customErrorMessage));
      mockBackend
        .expectOne({
          url: url,
          method: 'GET'
        })
        .flush(error, { status: 409, statusText: 'No record found' });
    }));
  });

  describe('Comment save service', () => {
    it('should save calendar event comments, if success', async(() => {
      const url =
        envServiceMock.marketPrefix.toLowerCase() +
        DRIVER_CALENDAR_EVENT_COMMENT_URL +
        1164304 +
        DRIVER_PROFILE_COMMENTS_DETAILS_END_URL;
      driverCalendarEventService
        .saveDriverCalendarComments(driverCalendarCommentsMockData.commentReq)
        .subscribe(successResult => expect(successResult).toEqual({ status: 201 }));
      mockBackend
        .expectOne({
          url: url,
          method: 'POST'
        })
        .flush({
          status: 201
        });
    }));
    it('should show custom error message, if create calendar event comment service response status is 404', async(() => {
      spyOn(toastrServiceMock, 'info').and.callThrough();
      const customErrorMessage = 'test';
      const url =
        envServiceMock.marketPrefix.toLowerCase() +
        DRIVER_CALENDAR_EVENT_COMMENT_URL +
        1164304 +
        DRIVER_PROFILE_COMMENTS_DETAILS_END_URL;
      driverCalendarEventService
        .saveDriverCalendarComments(driverCalendarCommentsMockData.commentReq)
        .subscribe(() => expect(toastrServiceMock.info).toHaveBeenCalledWith(customErrorMessage));
      mockBackend
        .expectOne({
          url: url,
          method: 'POST'
        })
        .flush({ message: 'Error' }, { status: 404, statusText: 'No record found' });
    }));
    it('should show error message if, comment details save service response status is 500', async(() => {
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const customErrorMessage = 'test';
      const url =
        envServiceMock.marketPrefix.toLowerCase() +
        DRIVER_CALENDAR_EVENT_COMMENT_URL +
        1164304 +
        DRIVER_PROFILE_COMMENTS_DETAILS_END_URL;
      driverCalendarEventService
        .saveDriverCalendarComments(driverCalendarCommentsMockData.commentReq)
        .subscribe(() => expect(toastrServiceMock.error).toHaveBeenCalledWith(customErrorMessage));
      mockBackend
        .expectOne({
          url: url,
          method: 'POST'
        })
        .flush({ message: 'Error' }, { status: 500, statusText: 'Server Error' });
    }));

    it('should show toastr info message, if comment details save service response status is 409', async(() => {
      spyOn(toastrServiceMock, 'info').and.callThrough();
      const customErrorMessage = 'Event must begin and end in the same work week.';
      const error = {
        Errors: [
          {
            id: 409,
            message: 'Event must begin and end in the same work week.',
            status: 'CONFLICT'
          }
        ]
      };
      const url =
        envServiceMock.marketPrefix.toLowerCase() +
        DRIVER_CALENDAR_EVENT_COMMENT_URL +
        1164304 +
        DRIVER_PROFILE_COMMENTS_DETAILS_END_URL;
      driverCalendarEventService
        .saveDriverCalendarComments(driverCalendarCommentsMockData.commentReq)
        .subscribe(() => expect(toastrServiceMock.info).toHaveBeenCalledWith(customErrorMessage));
      mockBackend
        .expectOne({
          url: url,
          method: 'POST'
        })
        .flush(error, { status: 409, statusText: 'No record found' });
    }));
  });
  describe('Create driver calendar event service', () => {
    it('should create calendar event , if success', async(() => {
      const url = envServiceMock.marketPrefix.toLowerCase() + DRIVER_CALENDAR_EVENT_SAVE_URL;
      driverCalendarEventService
        .createCalendarEvent(driverCalendarCommentsMockData.eventReq)
        .subscribe(successResult => expect(successResult).toEqual({ status: 201 }));
      mockBackend
        .expectOne({
          url: url,
          method: 'POST'
        })
        .flush({
          status: 201
        });
    }));
    it('should show custom error message, if create calendar event service response status is 404', async(() => {
      spyOn(toastrServiceMock, 'info').and.callThrough();
      const customErrorMessage = 'test';
      const url = envServiceMock.marketPrefix.toLowerCase() + DRIVER_CALENDAR_EVENT_SAVE_URL;
      driverCalendarEventService
        .createCalendarEvent(driverCalendarCommentsMockData.eventReq)
        .subscribe(() => expect(toastrServiceMock.info).toHaveBeenCalledWith(customErrorMessage));
      mockBackend
        .expectOne({
          url: url,
          method: 'POST'
        })
        .flush({ message: 'Error' }, { status: 404, statusText: 'No record found' });
    }));
    it('should show error message if, create calendar event service response status is 500', async(() => {
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const customErrorMessage = 'test';
      const url = envServiceMock.marketPrefix.toLowerCase() + DRIVER_CALENDAR_EVENT_SAVE_URL;
      driverCalendarEventService
        .createCalendarEvent(driverCalendarCommentsMockData.eventReq)
        .subscribe(() => expect(toastrServiceMock.error).toHaveBeenCalledWith(customErrorMessage));
      mockBackend
        .expectOne({
          url: url,
          method: 'POST'
        })
        .flush({ message: 'Error' }, { status: 500, statusText: 'Server Error' });
    }));

    it('should show toastr error message, if create calendar event service response status is 409', async(() => {
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const customErrorMessage = 'Event must begin and end in the same work week.';
      const error = {
        Errors: [
          {
            id: 409,
            message: 'Event must begin and end in the same work week.',
            status: 'CONFLICT'
          }
        ]
      };
      const url = envServiceMock.marketPrefix.toLowerCase() + DRIVER_CALENDAR_EVENT_SAVE_URL;
      driverCalendarEventService
        .createCalendarEvent(driverCalendarCommentsMockData.eventReq)
        .subscribe(() => expect(toastrServiceMock.error).toHaveBeenCalledWith(customErrorMessage));
      mockBackend
        .expectOne({
          url: url,
          method: 'POST'
        })
        .flush(error, { status: 409, statusText: 'No record found' });
    }));
  });
  describe('fetch calendar event', () => {
    it('should give calendar event comment details if service is success', async(() => {
      const url =
        envServiceMock.marketPrefix.toLowerCase() + DRIVER_CALENDAR_EVENT_SAVE_URL + '?id=1167970';
      driverCalendarEventService.fetchCalendarEvent(1167970).subscribe((successResult: any) => {
        expect(successResult.calendarEvents.CalendarEvent[0].lastChangeApplicationId).toEqual(
          11004
        );
      });
      mockBackend
        .expectOne({
          url: url,
          method: 'GET'
        })
        .flush({
          status: 200,
          calendarEvents: driverCalendarCommentsMockData.eventDetails
        });
    }));
    it('it should show no record info message when there is no event details', async(() => {
      const tostMsgSpy = spyOn(toastrServiceMock, 'info').and.callThrough();
      const previewResponse = '';
      const customInfoMessage = 'test';
      const url =
        envServiceMock.marketPrefix.toLowerCase() + DRIVER_CALENDAR_EVENT_SAVE_URL + '?id=1167970';
      driverCalendarEventService.fetchCalendarEvent(1167970).subscribe((successResult: any) => {
        expect(tostMsgSpy).toHaveBeenCalledWith(customInfoMessage);
      });
      mockBackend
        .expectOne({
          url: url,
          method: 'GET'
        })
        .flush(previewResponse);
    }));
    it('should show custom error message if event details service response status is 404', async(() => {
      spyOn(toastrServiceMock, 'info').and.callThrough();
      const customErrorMessage = 'failed due to server error';
      const url =
        envServiceMock.marketPrefix.toLowerCase() + DRIVER_CALENDAR_EVENT_SAVE_URL + '?id=1167970';
      driverCalendarEventService
        .fetchCalendarEvent(1167970)
        .subscribe(() => expect(toastrServiceMock.info).toHaveBeenCalledWith(customErrorMessage));
      mockBackend
        .expectOne({
          url: url,
          method: 'GET'
        })
        .flush({ message: 'Error' }, { status: 404, statusText: 'Server Error' });
    }));
    it('should show error message  if event details service response status is 500', async(() => {
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const customErrorMessage = 'failed due to server error';
      const url =
        envServiceMock.marketPrefix.toLowerCase() + DRIVER_CALENDAR_EVENT_SAVE_URL + '?id=1167970';
      driverCalendarEventService
        .fetchCalendarEvent(1167970)
        .subscribe(() => expect(toastrServiceMock.error).toHaveBeenCalledWith(customErrorMessage));
      mockBackend
        .expectOne({
          url: url,
          method: 'GET'
        })
        .flush({ message: 'Error' }, { status: 500, statusText: 'Server Error' });
    }));
  });
  describe('update calendar event details', () => {
    it('should create calendar event , if success', async(() => {
      const reqBody = driverCalendarCommentsMockData.eventReq;
      reqBody.versionId = 1;
      reqBody.eventId = 1167970;
      const url =
        envServiceMock.marketPrefix.toLowerCase() + DRIVER_CALENDAR_EVENT_COMMENT_URL + 1167970;
      driverCalendarEventService
        .updateDriverCalendarEvent(reqBody, 1167970)
        .subscribe(successResult => expect(successResult.versionId).toEqual(2));
      mockBackend
        .expectOne({
          url: url,
          method: 'PUT'
        })
        .flush(driverCalendarCommentsMockData.eventDetails.CalendarEvent[0]);
    }));
    it('should show custom error message, if create calendar event service response status is 404', async(() => {
      spyOn(toastrServiceMock, 'info').and.callThrough();
      const reqBody = driverCalendarCommentsMockData.eventReq;
      reqBody.versionId = 1;
      reqBody.eventId = 1167970;
      const url =
        envServiceMock.marketPrefix.toLowerCase() + DRIVER_CALENDAR_EVENT_COMMENT_URL + 1167970;
      driverCalendarEventService
        .updateDriverCalendarEvent(reqBody, 1167970)
        .subscribe(successResult => expect(successResult.versionId).toEqual(2));
      mockBackend
        .expectOne({
          url: url,
          method: 'PUT'
        })
        .flush({ message: 'Error' }, { status: 404, statusText: 'No record found' });
    }));
    it('should show error message if, create calendar event service response status is 500', async(() => {
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const reqBody = driverCalendarCommentsMockData.eventReq;
      reqBody.versionId = 1;
      reqBody.eventId = 1167970;
      const url =
        envServiceMock.marketPrefix.toLowerCase() + DRIVER_CALENDAR_EVENT_COMMENT_URL + 1167970;
      driverCalendarEventService
        .updateDriverCalendarEvent(reqBody, 1167970)
        .subscribe(successResult => expect(successResult.versionId).toEqual(2));
      mockBackend
        .expectOne({
          url: url,
          method: 'PUT'
        })
        .flush({ message: 'Error' }, { status: 500, statusText: 'Server Error' });
    }));
    it('should show toastr error message, if create calendar event service response status is 409', async(() => {
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const errorConflict = {
        Errors: [
          {
            message: 'ServerError'
          }
        ]
      };
      const reqBody = driverCalendarCommentsMockData.eventReq;
      reqBody.versionId = 1;
      reqBody.eventId = 1167970;
      const url =
        envServiceMock.marketPrefix.toLowerCase() + DRIVER_CALENDAR_EVENT_COMMENT_URL + 1167970;
      driverCalendarEventService
        .updateDriverCalendarEvent(reqBody, 1167970)
        .subscribe(successResult => expect(successResult.versionId).toEqual(2));
      mockBackend
        .expectOne({
          url: url,
          method: 'PUT'
        })
        .flush(errorConflict, { status: 409, statusText: 'Unable to fetch search results' });
    }));
  });
  describe('delete driver calendar event ', () => {
    it('should delete calendar event , if success', async(() => {
      const url =
        envServiceMock.marketPrefix.toLowerCase() + DRIVER_CALENDAR_EVENT_COMMENT_URL + 1168022;
      driverCalendarEventService
        .deleteCalendarEvent(1168022, 1)
        .subscribe(successResult => expect(successResult).toEqual({ status: 200 }));
      mockBackend
        .expectOne({
          url: url,
          method: 'DELETE'
        })
        .flush({
          status: 200
        });
    }));
    it('should show custom error message, if delete calendar event service response status is 404', async(() => {
      spyOn(toastrServiceMock, 'info').and.callThrough();
      const customErrorMessage = 'test';
      const url =
        envServiceMock.marketPrefix.toLowerCase() + DRIVER_CALENDAR_EVENT_COMMENT_URL + 1168022;
      driverCalendarEventService
        .deleteCalendarEvent(1168022, 1)
        .subscribe(() => expect(toastrServiceMock.info).toHaveBeenCalledWith(customErrorMessage));
      mockBackend
        .expectOne({
          url: url,
          method: 'DELETE'
        })
        .flush({ message: 'Error' }, { status: 404, statusText: 'No record found' });
    }));
    it('should show error message if, delete calendar event service response status is 500', async(() => {
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const customErrorMessage = 'test';
      const url =
        envServiceMock.marketPrefix.toLowerCase() + DRIVER_CALENDAR_EVENT_COMMENT_URL + 1168022;
      driverCalendarEventService
        .deleteCalendarEvent(1168022, 1)
        .subscribe(() => expect(toastrServiceMock.error).toHaveBeenCalledWith(customErrorMessage));
      mockBackend
        .expectOne({
          url: url,
          method: 'DELETE'
        })
        .flush({ message: 'Error' }, { status: 500, statusText: 'Server Error' });
    }));

    it('should show toastr info message, if delete calendar event service response status is 409', async(() => {
      spyOn(toastrServiceMock, 'info').and.callThrough();
      const customErrorMessage = 'Event must begin and end in the same work week.';
      const error = {
        Errors: [
          {
            id: 409,
            message: 'Event must begin and end in the same work week.',
            status: 'CONFLICT'
          }
        ]
      };
      const url =
        envServiceMock.marketPrefix.toLowerCase() + DRIVER_CALENDAR_EVENT_COMMENT_URL + 1168022;
      driverCalendarEventService
        .deleteCalendarEvent(1168022, 1)
        .subscribe(() => expect(toastrServiceMock.info).toHaveBeenCalledWith(customErrorMessage));
      mockBackend
        .expectOne({
          url: url,
          method: 'DELETE'
        })
        .flush(error, { status: 409, statusText: 'This failed due to server issue.' });
    }));
  });
});
