import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { EnvService, UserService } from '@transom/services';
import { ToastrService } from '@transom/ui';
import { Observable } from 'rxjs';
import { catchError, finalize, tap } from 'rxjs/operators';

import { LoadingDialogService } from '../../../../common/loading-dialog/loading-dialog.service';
import {
  DRIVER_CALENDAR_COMMENT_LIST_URL,
  DRIVER_CALENDAR_EVENT_COMMENT_URL,
  DRIVER_CALENDAR_EVENT_SAVE_URL,
  DRIVER_PROFILE_COMMENTS_DETAILS_END_URL
} from '../../../../common/urls';
import { DriverUtils } from '../../../../utils/driver-utils';
import {
  DriverCalendarCommentLists,
  DriverCalendarEventDetails,
  DriverCalendarEventRequest,
  DriverProfileCommentDetailsResponse
} from '../../../model';
@Injectable()
export class DriverCalendarEventService {
  constructor(
    private http: HttpClient,
    private envService: EnvService,
    private loadingDialogService: LoadingDialogService,
    private toastrService: ToastrService,
    private translateService: TranslateService,
    private userService: UserService,
    private driverUtils: DriverUtils
  ) {}
  fetchDriverCalendarComments(commentId: number): Observable<DriverCalendarCommentLists> {
    const url =
      this.envService.marketPrefix.toLowerCase() +
      DRIVER_CALENDAR_COMMENT_LIST_URL +
      '?commentId=' +
      commentId;
    this.loadingDialogService.openLoaderDialog(this.translateService.instant('Processing'));
    return this.http.get<DriverCalendarCommentLists>(url).pipe(
      tap((response: DriverCalendarCommentLists) => {
        return response;
      }),
      catchError((error: HttpErrorResponse) => this.handleError(error)),
      finalize(() => this.loadingDialogService.closeLoader())
    );
  }
  saveDriverCalendarComments<T>(
    commentDetails: DriverProfileCommentDetailsResponse
  ): Observable<T> {
    const url =
      this.envService.marketPrefix.toLowerCase() +
      DRIVER_CALENDAR_EVENT_COMMENT_URL +
      commentDetails.objectId +
      DRIVER_PROFILE_COMMENTS_DETAILS_END_URL;
    this.loadingDialogService.openLoaderDialog(this.translateService.instant('Processing'));
    return this.http.post<T>(url, commentDetails).pipe(
      tap((response: any) => {
        return true;
      }),
      catchError((error: HttpErrorResponse) => this.handleError(error)),
      finalize(() => this.loadingDialogService.closeLoader())
    );
  }
  createCalendarEvent<T>(eventRequest: DriverCalendarEventRequest): Observable<T> {
    const requestOptions = {
      headers: this.driverUtils.getJsonHeaders(this.envService, this.userService)
    };
    const url = this.envService.marketPrefix.toLowerCase() + DRIVER_CALENDAR_EVENT_SAVE_URL;
    this.loadingDialogService.openLoaderDialog(this.translateService.instant('Processing'));
    return this.http.post<T>(url, eventRequest, requestOptions).pipe(
      tap(response => {
        return true;
      }),
      catchError((error: HttpErrorResponse) => this.handleError(error)),
      finalize(() => this.loadingDialogService.closeLoader())
    );
  }

  updateDriverCalendarEvent(
    eventRequest: DriverCalendarEventRequest,
    eventId: number
  ): Observable<DriverCalendarEventRequest> {
    const requestOptions = {
      headers: this.driverUtils.getJsonHeaders(this.envService, this.userService)
    };
    const url =
      this.envService.marketPrefix.toLowerCase() + DRIVER_CALENDAR_EVENT_COMMENT_URL + eventId;
    this.loadingDialogService.openLoaderDialog(this.translateService.instant('Processing'));
    return this.http.put<DriverCalendarEventRequest>(url, eventRequest, requestOptions).pipe(
      tap((response: DriverCalendarEventRequest) => {
        return response;
      }),
      catchError((error: HttpErrorResponse) => this.handleError(error)),
      finalize(() => this.loadingDialogService.closeLoader())
    );
  }
  fetchCalendarEvent(eventId: number): Observable<DriverCalendarEventDetails> {
    const url =
      this.envService.marketPrefix.toLowerCase() +
      DRIVER_CALENDAR_EVENT_SAVE_URL +
      '?id=' +
      eventId;
    this.loadingDialogService.openLoaderDialog(this.translateService.instant('Processing'), true);
    return this.http.get<DriverCalendarEventDetails>(url).pipe(
      tap((response: DriverCalendarEventDetails) => {
        if (!response)
          this.toastrService.info(this.translateService.instant('Message_No_Records_Found'));
        return response;
      }),
      catchError((error: HttpErrorResponse) => this.handleError(error)),
      finalize(() => this.loadingDialogService.closeLoader(true))
    );
  }
  deleteCalendarEvent<T>(eventId: number, versionId: number): Observable<T> {
    const requestOptions = {
      headers: {
        ...this.driverUtils.getJsonHeaders(this.envService, this.userService),
        'If-Match': versionId.toString()
      }
    };
    const url =
      this.envService.marketPrefix.toLowerCase() + DRIVER_CALENDAR_EVENT_COMMENT_URL + eventId;
    this.loadingDialogService.openLoaderDialog(this.translateService.instant('Processing'));
    return this.http.delete<T>(url, requestOptions).pipe(
      tap((response: T) => {
        return true;
      }),
      catchError((error: HttpErrorResponse) => this.handleError(error)),
      finalize(() => this.loadingDialogService.closeLoader())
    );
  }
  private handleError(error): Observable<never> {
    this.loadingDialogService.closeLoader();
    let errMsg;
    if (error instanceof HttpErrorResponse && error.status === 500)
      this.toastrService.info(this.translateService.instant('Internal_Server_Error'));
    else if (error instanceof HttpErrorResponse && error.status === 409)
      if (error.error.errors)
        error.error.errors.map(err => {
          this.toastrService.error(err.message);
        });
      else
        error.error.Errors.map(err => {
          this.toastrService.error(err.message);
        });
    else {
      errMsg = this.translateService.instant('Server_Error');
      this.toastrService.error(errMsg);
    }

    return new Observable<never>();
  }
}
