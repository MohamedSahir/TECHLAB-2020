import { SimpleChange, ViewEncapsulation } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AuthZService } from '@transom/services';
import * as moment from 'moment-timezone';
import { of as observableOf } from 'rxjs';

import { FakeMatSideNavComponent, FakeSearchPanelComponent } from '../../../mock';
import {
  DriverCalendarServiceMock,
  DriverQueryStaticServiceMock,
  OfficeCalendarServiceMock
} from '../../../mock';
import { DriverQueryStaticService } from '../../common-services';
import { OfficeCalendarService } from '../../office-calendar/services';
import { DriverCalendarService } from '../services';
import { DriverCalendarViewDetailsComponent } from './driver-calendar-view-details.component';
import { DriverCalendarViewDetailsService } from './services';

declare var require: any;
const driverCalendarMockData = require('../../../mock/json-files/driver-calendar.json');

describe('DriverCalendarViewDetailComponent', () => {
  let component: DriverCalendarViewDetailsComponent;
  let fixture: ComponentFixture<DriverCalendarViewDetailsComponent>;
  let driverQueryStaticServiceMock: DriverQueryStaticServiceMock;
  let driverCalendarServiceMock: DriverCalendarServiceMock;
  let officeCalendarServiceMock: OfficeCalendarServiceMock;
  const mockAuth = {
    hasOneCapabilityOf() {
      return observableOf(true);
    }
  };
  beforeEach(async(() => {
    driverCalendarServiceMock = new DriverCalendarServiceMock();
    driverQueryStaticServiceMock = new DriverQueryStaticServiceMock();
    officeCalendarServiceMock = new OfficeCalendarServiceMock();
    TestBed.configureTestingModule({
      declarations: [
        DriverCalendarViewDetailsComponent,
        FakeMatSideNavComponent,
        FakeSearchPanelComponent
      ]
    }).overrideComponent(DriverCalendarViewDetailsComponent, {
      set: {
        template: ' <div><fake-matside-nav #sidenav></fake-matside-nav></div>',
        encapsulation: ViewEncapsulation.Emulated,
        providers: [
          DriverCalendarViewDetailsService,
          { provide: DriverCalendarService, useValue: driverCalendarServiceMock },
          { provide: DriverQueryStaticService, useValue: driverQueryStaticServiceMock },
          { provide: AuthZService, useValue: mockAuth },
          { provide: OfficeCalendarService, useValue: officeCalendarServiceMock }
        ]
      }
    });
  }));
  beforeEach(() => {
    fixture = TestBed.createComponent(DriverCalendarViewDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  afterAll(() => {
    fixture.destroy();
    component = null;
  });

  it('should create a driver calander  view details component', () => {
    expect(component).toBeDefined();
  });
  it('should set calendar details based on drived id search', () => {
    component.calendarResponse = driverCalendarMockData;
    component.ngOnChanges({
      calendarResponse: new SimpleChange(undefined, component.calendarResponse, false)
    });
    fixture.detectChanges();
    expect(component.calendarResponse).toEqual(driverCalendarMockData);
  });
  it('should  not set calendar full day event events details based on driver id search', () => {
    const calendarDetails = driverCalendarMockData;
    calendarDetails.calendarEvents[0].fullDayEvent = false;
    component.calendarResponse = calendarDetails;
    component.ngOnChanges({
      calendarResponse: new SimpleChange(undefined, component.calendarResponse, false)
    });
    fixture.detectChanges();
    expect(component.calendarResponse.calendarEvents[0].fullDayEvent).toEqual(
      calendarDetails.calendarEvents[0].fullDayEvent
    );
  });
  it('should set calendar full day event events details based on driver id search', () => {
    const calendarDetails = driverCalendarMockData;
    component.calendarResponse = calendarDetails;
    component.ngOnChanges({
      calendarResponse: new SimpleChange(undefined, component.calendarResponse, false)
    });
    fixture.detectChanges();
    expect(component.calendarResponse.calendarEvents[0].fullDayEvent).toEqual(
      calendarDetails.calendarEvents[0].fullDayEvent
    );
  });
  it('should not set the calendar details if calendar details have no response', () => {
    component.calendarResponse = undefined;
    component.ngOnChanges({
      calendarRespose: new SimpleChange(undefined, component.calendarResponse, false)
    });
    fixture.detectChanges();
    expect(component.calendarResponse).toEqual(undefined);
  });
  it('should not set the calendar details if calendar details have null response', () => {
    component.calendarResponse = null;
    component.ngOnChanges({
      calendarResponse: new SimpleChange(undefined, component.calendarResponse, false)
    });
    fixture.detectChanges();
    expect(component.calendarResponse).toEqual(null);
  });
  it('should not enable add event if not have an event and workweek', () => {
    component.calendarResponse = null;
    const event = '2018-12-05 12:00:00 am';
    component.dayClickEvent(event);
    fixture.detectChanges();
    expect(component.isEventEnabled).toEqual(false);
  });
  it('should enable edit workweek if have a workweek ', () => {
    const calendarDetails = driverCalendarMockData;
    component.calendarResponse = calendarDetails;
    component.ngOnChanges({
      calendarResponse: new SimpleChange(undefined, component.calendarResponse, false)
    });
    const event = {
      allDay: false,
      color: 'green',
      end: '2018-12-04 00:00 PM',
      id: 'W4934994',
      start: '2018-11-30 00:00 AM',
      title: 'workweek'
    };
    component.eventClick(event);
    fixture.detectChanges();
    expect(component.isEditWorkWeeks).toEqual(true);
  });
  it('should replace E from eventID if have an event', () => {
    component.calendarResponse = null;
    const event = {
      allDay: false,
      color: 'orange',
      end: '2018-12-03 00:00 AM',
      id: 'E1168101',
      start: '2018-12-02 00:00 AM',
      title: 'HOLIDAY'
    };
    component.eventClick(event);
    fixture.detectChanges();
    expect(component.eventId.toString()).toEqual(event.id.replace('E', ''));
  });
  it('should get week view start and end time by default', () => {
    component.calendarResponse = null;
    const event = { start: '2018-12-22 00:00 AM', end: '2018-12-29 00:00 AM' };
    component.viewChanges(event);
    expect(component.startDate).toEqual(moment(event.start).format('YYYY-MM-DD'));
  });
  it('should disable edit event if not have an event', () => {
    component.calendarResponse = driverCalendarMockData;
    const event = '2018-12-05 12:00:00 am';
    component.dayClickEvent(event);
    fixture.detectChanges();
    expect(component.isEventEnabled).toEqual(false);
  });
  it('should return true  if have driver calendar write capability', () => {
    component.calendarResponse = driverCalendarMockData;
    (component as any).hasDriverWriteCalendarCapability();
    fixture.detectChanges();
    expect((component as any).hasDriverWriteCalendarCapability()).toEqual(true);
  });
  it('should return driver terminated as true  if driver have terminated date', () => {
    const calendarDetails = driverCalendarMockData;
    calendarDetails.driverBenefitProfile.terminationDate.timeStamp = '08/27/2018';
    calendarDetails.driverBenefitProfile.status = '6';
    calendarDetails.isDriverTerminated = true;
    component.calendarResponse = calendarDetails;
    component.ngOnChanges({
      calendarResponse: new SimpleChange(undefined, component.calendarResponse, false)
    });
    fixture.detectChanges();
    expect(component.calendarResponse.isDriverTerminated).toEqual(true);
  });
  it('should show terminated color as red  if driver is terminated', () => {
    const calendarDetails = driverCalendarMockData;
    calendarDetails.driverBenefitProfile.terminationDate.timeStamp = '08/27/2018';
    calendarDetails.driverBenefitProfile.status = '6';
    calendarDetails.isDriverTerminated = true;
    calendarDetails.isWalmartDriver = true;
    component.calendarResponse = calendarDetails;
    component.ngOnChanges({
      calendarResponse: new SimpleChange(undefined, component.calendarResponse, false)
    });
    fixture.detectChanges();
    expect(component.calendarEvents[0].color).toEqual('red');
  });
  it('should show quit color as red  if driver is quit', () => {
    const calendarDetails = driverCalendarMockData;
    calendarDetails.driverBenefitProfile.terminationDate.timeStamp = '08/27/2018';
    calendarDetails.driverBenefitProfile.status = '5';
    calendarDetails.isDriverTerminated = true;
    calendarDetails.isWalmartDriver = true;
    component.calendarResponse = calendarDetails;
    component.ngOnChanges({
      calendarResponse: new SimpleChange(undefined, component.calendarResponse, false)
    });
    fixture.detectChanges();
    expect(component.calendarEvents[0].color).toEqual('red');
  });
  it('should not enable add event if not have an event and in current payperiod with terminated driver', () => {
    const calendarDetails = driverCalendarMockData;
    calendarDetails.isDriverTerminated = true;
    calendarDetails.isWalmartDriver = true;
    component.calendarResponse = calendarDetails;
    component.ngOnChanges({
      calendarResponse: new SimpleChange(undefined, component.calendarResponse, false)
    });
    const event = '2019-01-03 12:00:00 am';
    component.dayClickEvent(event);
    fixture.detectChanges();
    expect(component.isEventEnabled).toEqual(false);
  });
  it('should not enable add workweek if workweek exists', () => {
    const calendarDetails = driverCalendarMockData;
    calendarDetails.isDriverTerminated = true;
    calendarDetails.isWalmartDriver = true;
    component.calendarResponse = calendarDetails;
    component.ngOnChanges({
      calendarResponse: new SimpleChange(undefined, component.calendarResponse, false)
    });
    const selectedDay = '2018-12-03 12:00:00 am';
    component.dayClickEvent(selectedDay);
    fixture.detectChanges();
    expect(component.isAddWorkWeek).toEqual(false);
  });
  it('should not enable add event  if not have workweek and event', () => {
    const calendarDetails = driverCalendarMockData;
    calendarDetails.isDriverTerminated = true;
    calendarDetails.isWalmartDriver = true;
    component.calendarResponse = calendarDetails;
    component.ngOnChanges({
      calendarResponse: new SimpleChange(undefined, component.calendarResponse, false)
    });
    const event = '2019-01-05 12:00:00 am';
    component.dayClickEvent(event);
    fixture.detectChanges();
    expect(component.isEventEnabled).toEqual(false);
  });
  it('should not enable add workweek if not have workweek and event', () => {
    const calendarDetails = driverCalendarMockData;
    calendarDetails.isDriverTerminated = true;
    calendarDetails.isWalmartDriver = true;
    component.calendarResponse = calendarDetails;
    component.ngOnChanges({
      calendarResponse: new SimpleChange(undefined, component.calendarResponse, false)
    });
    const selectedDay = '2019-01-06 12:00:00 am';
    component.dayClickEvent(selectedDay);
    fixture.detectChanges();
    expect(component.isAddWorkWeek).toEqual(false);
  });
  it('should disable add workweek on clear', () => {
    const calendarDetails = driverCalendarMockData;
    calendarDetails.isDriverTerminated = true;
    calendarDetails.isWalmartDriver = true;
    component.calendarResponse = calendarDetails;
    component.calendarClear = 'clear';
    (component as any).isSideNavOpen = true;
    component.ngOnChanges({
      calendarResponse: new SimpleChange(undefined, component.calendarResponse, false)
    });
    component.ngOnChanges({
      calendarClear: new SimpleChange(undefined, component.calendarClear, false)
    });
    const selectedDay = '2019-01-06 12:00:00 am';
    component.dayClickEvent(selectedDay);
    fixture.detectChanges();
    expect(component.isAddWorkWeek).toEqual(false);
  });

  it('should disable the add events while reset', () => {
    const calendarDetails = driverCalendarMockData;
    calendarDetails.isDriverTerminated = true;
    calendarDetails.isWalmartDriver = true;
    component.calendarResponse = calendarDetails;
    component.calendarClear = 'clear';
    (component as any).isSideNavOpen = true;
    component.ngOnChanges({
      calendarResponse: new SimpleChange(undefined, component.calendarResponse, false)
    });
    component.ngOnChanges({
      calendarClear: new SimpleChange(undefined, component.calendarClear, false)
    });
    component.refreshCalendar('close');
    expect(component.isEventEnabled).toEqual(false);
  });
});
