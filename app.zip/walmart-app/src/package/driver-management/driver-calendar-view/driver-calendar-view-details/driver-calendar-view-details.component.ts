import {
    ChangeDetectorRef,
    Component,
    EventEmitter,
    Input,
    OnChanges,
    OnDestroy,
    OnInit,
    Output,
    SimpleChanges,
    ViewChild
  } from '@angular/core';
  import { MatSidenav } from '@angular/material';
  import { AuthZService } from '@transom/services';
  import * as moment from 'moment-timezone';
  import { BehaviorSubject, Observable, Subscription } from 'rxjs';
  
  import { driverConstants } from '../../../common/driver-constants';
  import {
    driverCalendarAdminCapability,
    driverCalendarConstants,
    driverCalendarWriteCapability
  } from '../../../constants/driver-management-constant';
  import { DriverQueryStaticService } from '../../../driver-management/common-services';
  import {
    CalendarBindingEvent,
    CalendarDateRange,
    CalendarEventDetail,
    CalendarEventTypes,
    CalendarRange,
    DriverCalendarAllEvents,
    DriverCalendarRequest,
    DriverCalendarResponse,
    DriverWorkWeek,
    OfficeEvent,
    PayPeriodModel,
    PayrollDatesResponse
  } from '../../model';
  import { OfficeCalendarService } from '../../office-calendar/services';
  import { DriverCalendarService } from '../services';
  import { DriverCalendarViewDetailsService } from './services';
  
  @Component({
    selector: 'driver-calendar-view-details',
    templateUrl: './driver-calendar-view-details.component.html',
    styleUrls: ['./driver-calendar-view-details.component.scss']
  })
  export class DriverCalendarViewDetailsComponent implements OnInit, OnChanges, OnDestroy, OnInit {
    @Input() calendarResponse: DriverCalendarResponse;
    @Input() calendarClear: string;
    @Output() calendarEvent = new EventEmitter<OfficeEvent>();
    @Output() calendarParent = new EventEmitter();
    @Output() rebindCalendar = new EventEmitter();
    @ViewChild('sidenav') sidenav: MatSidenav;
    calendarEvents: CalendarBindingEvent[];
    event: CalendarBindingEvent[];
    eventId: number;
    driverDetails: DriverCalendarResponse;
    isWalmartDriver: boolean;
    isAddWorkWeek: boolean;
    isEditWorkWeeks: boolean;
    isEventEnabled: boolean;
    driverWorkWeek: DriverWorkWeek;
    selectedCalendarDate: Date;
    startDate: Date;
    endDate: Date;
    validRange: CalendarRange;
    resetEvents$: BehaviorSubject<DriverCalendarAllEvents> = new BehaviorSubject({});
    private payPeriodStartDate: Date;
    private payPeriodEndDate: Date;
    private isSideNavOpen: boolean;
    driverId: string;
    private calendarEventTypesSubscription$: Subscription;
    private driverCalendarEventTypes: CalendarEventTypes[];
    private officeCalendarDateRangeSubscription: Subscription;
    eventDetails: CalendarEventDetail;
    constructor(
      public cdr: ChangeDetectorRef,
      private driverQueryStaticService: DriverQueryStaticService,
      private driverCalendarsService: DriverCalendarService,
      private authZService: AuthZService,
      private driverCalendarViewDetailsService: DriverCalendarViewDetailsService,
      private officeCalendarService: OfficeCalendarService
    ) {}
    ngOnChanges(changes: SimpleChanges) {
      if (
        changes.hasOwnProperty('calendarResponse') &&
        changes.calendarResponse.currentValue !== undefined &&
        changes.calendarResponse.currentValue !== null
      ) {
        this.calendarResponse = changes.calendarResponse.currentValue;
        this.driverId = this.calendarResponse.driverId;
        this.sidenav.close();
        this.calendarEventStaticData();
        this.calendarBinding(this.calendarResponse);
      }
      if (
        changes.hasOwnProperty('calendarClear') &&
        changes.calendarClear.currentValue !== undefined &&
        changes.calendarClear.currentValue !== null
      ) {
        if (changes.calendarClear.currentValue === driverCalendarConstants.clear)
          if (this.isSideNavOpen === true) this.sidenav.close();
        this.isEventEnabled = false;
        this.isAddWorkWeek = false;
        this.resetEvents$.next({});
      }
    }
    refreshCalendar(event): void {
      if (this.isSideNavOpen === true) this.sidenav.close();
      this.isEventEnabled = false;
      this.isAddWorkWeek = false;
      this.resetEvents$.next({});
      this.rebindCalendar.emit('close');
      this.eventId = null;
    }
    ngOnDestroy() {
      if (this.calendarEventTypesSubscription$) this.calendarEventTypesSubscription$.unsubscribe();
      if (this.officeCalendarDateRangeSubscription)
        this.officeCalendarDateRangeSubscription.unsubscribe();
    }
    driverCalendarEventView(eventId): void {
      this.isSideNavOpen = true;
      this.isEventEnabled = false;
      this.isAddWorkWeek = false;
      this.sidenav.toggle();
      let calendarRequest: DriverCalendarRequest;
      calendarRequest = {
        fromdate: moment(this.selectedCalendarDate).format(driverCalendarConstants.dateFormat),
        todate: moment(this.selectedCalendarDate).format(driverCalendarConstants.toDate)
      };
      this.driverCalendarsService
        .fetchDriverCalendar(+this.driverId, calendarRequest)
        .subscribe(response => {
          this.calendarResponse = response;  
          this.eventDetails = {
            selectedDate: this.selectedCalendarDate,
            payPeriodStartDate: this.payPeriodStartDate,
            payPeriodEndDate: this.payPeriodEndDate
          };
          if (eventId)
            this.eventId = parseInt(
              eventId.toString().replace(driverCalendarConstants.eventIdFormat, ''),
              0
            );
        });
    }
    ngOnInit() {
      this.calendarRangeStaticData();
  
      this.calendarEvents = [];
      this.isSideNavOpen = false;
    }
    dayClickEvent($event: CalendarBindingEvent): void {
      this.selectedCalendarDate = moment($event).format(driverCalendarConstants.dateDefaultFormat);
      this.isEventEnabled =
        this.hasCapabilityForDayView() &&
        this.hasEnableAddEvent() &&
        this.hasTimetoAccomodateNewEvent() &&
        !this.calendarResponse.isDriverTerminated;
      this.isAddWorkWeek = this.hasCapabilityForAddWorkWeek();
      this.cdr.detectChanges();
    }
    eventClick($event: CalendarBindingEvent): void {
      const startDates = moment($event.start).format(driverCalendarConstants.dateDefaultFormat);
      this.selectedCalendarDate = startDates;
      const endDates = moment($event.end).format(driverCalendarConstants.dateDefaultFormat);
      if ($event.id.toString().indexOf(driverCalendarConstants.eventIdFormat) === 0) 
        this.driverCalendarEventView($event.id);
       else this.isEditWorkWeeks = this.hasCapabilityForEditWorkWeek(startDates, endDates);
      this.cdr.detectChanges();
    }
    viewChanges(event: OfficeEvent): void {
      this.startDate = moment(event.start).format(driverCalendarConstants.dateDefaultFormat);
      this.endDate = moment(event.end).format(driverCalendarConstants.dateDefaultFormat);
      this.calendarEvent.emit(event);
      this.isEventEnabled = false;
      this.isAddWorkWeek = false;
      this.isSideNavOpen = false;
      this.eventId = null;
    }
  
    private bindAllEvents(): void {
      const allEvents: DriverCalendarAllEvents = { blue: [], orange: [], red: [], green: [] };
      if (this.calendarEvents.length > 0)
        this.calendarEvents.map(event => {
          if (event.color === driverCalendarConstants.fullDayEventColor)
            allEvents.orange.push({ ...event });
          if (event.color === driverCalendarConstants.partialDayEventColor)
            allEvents.blue.push({ ...event });
          if (event.color === driverCalendarConstants.terminatedQuit)
            allEvents.red.push({ ...event });
          if (event.color === driverCalendarConstants.calendarWorkWeek)
            allEvents.green.push({ ...event });
        });
      if (allEvents) this.resetEvents$.next({ ...allEvents });
      this.cdr.detectChanges();
    }
    private calendarRangeStaticData(): void {
      this.officeCalendarDateRangeSubscription = this.officeCalendarService
        .fetchCalendarRange()
        .subscribe(this.calendarRange);
    }
    private calendarRange = (dateRange: CalendarDateRange): void => {
      this.validRange = {
        start: moment(dateRange.fromDate.timeStamp).format(
          driverConstants.officeCalendarConstants.dateRangeFormat
        ),
        end: moment(dateRange.toDate.timeStamp).format(
          driverConstants.officeCalendarConstants.dateRangeFormat
        )
      };
      this.fetchPayrollDate();
    };
    private calendarEventBinding(calendarResponse: DriverCalendarResponse): void {
      if (calendarResponse.calendarEvents != null)
        calendarResponse.calendarEvents.map(events => {
          this.calendarEvents.push({
            id: driverCalendarConstants.eventIdFormat + events.eventId.toString(),
            title: this.calendarEventType(events.eventTypeCode),
            start: moment(events.beginTs.timeStamp).format(driverCalendarConstants.dateTimeFormat),
            end: moment(events.endTs.timeStamp).format(driverCalendarConstants.dateTimeFormat),
            color: events.fullDayEvent
              ? driverCalendarConstants.fullDayEventColor
              : driverCalendarConstants.partialDayEventColor
          });
        });
    }
    private calendarBinding(calendarResponse: DriverCalendarResponse): void {
      if (calendarResponse) {
        this.calendarEvents = [];
        this.isEventEnabled = false;
        this.isAddWorkWeek = false;
        this.calendarTerminated(calendarResponse);
        this.calendarEventBinding(calendarResponse);
        this.calendarWorkWeekBinding(calendarResponse);
      }
    }
    private calendarTerminated(calendarResponse: DriverCalendarResponse): void {
      if (calendarResponse.isWalmartDriver)
        if (
          calendarResponse.driverBenefitProfile.terminationDate.timeStamp !== null &&
          calendarResponse.isDriverTerminated
        )
          if (
            calendarResponse.driverBenefitProfile.status === driverCalendarConstants.hostStatusQTCode
          )
            this.terminatedQuitBar(calendarResponse, driverCalendarConstants.quitStatus);
          else this.terminatedQuitBar(calendarResponse, driverCalendarConstants.terminatedStatus);
    }
    private calendarWorkWeekBinding(calendarResponse: DriverCalendarResponse): void {
      if (calendarResponse.driverWorkWeeks != null)
        calendarResponse.driverWorkWeeks.map(workWeeks => {
          this.calendarEvents.push({
            id: '' + workWeeks.driverWorkWeekId.toString(),
            title: '',
            start: moment(workWeeks.sowwTs.timeStamp).format(driverCalendarConstants.dateTimeFormat),
            end: moment(workWeeks.eowwTs.timeStamp).format(driverCalendarConstants.dateTimeFormat),
            color: driverCalendarConstants.calendarWorkWeek
          });
        });
      this.bindAllEvents();
    }
  
    private hasCapabilityForAddWorkWeek(): boolean {
      if (this.calendarResponse != null)
        if (
          !this.hasCapabilityForAddWorkWeeks() &&
          this.calendarResponse.isWalmartDriver &&
          !this.calendarResponse.isDriverTerminated
        ) {
          if (this.hasDriverAdminCalendarCapability()) return true;
          else if (this.hasDriverWriteCalendarCapability())
            return this.driverCalendarViewDetailsService.isSelectedDateInCurrentPayPeriod(
              this.selectedCalendarDate,
              this.payPeriodStartDate,
              this.payPeriodEndDate
            );
          return false;
        }
      return false;
    }
    private hasCapabilityOf([capabilityName]): Observable<Boolean> {
      return this.authZService.hasOneCapabilityOf([capabilityName]);
    }
    private hasDriverAdminCalendarCapability(): boolean {
      let hasAdmin = false;
      this.hasCapabilityOf([driverCalendarAdminCapability]).subscribe((hasCapability: boolean) => {
        hasAdmin = hasCapability;
      });
      return hasAdmin;
    }
    private hasDriverWriteCalendarCapability(): boolean {
      let hasWrite = false;
      this.hasCapabilityOf([driverCalendarWriteCapability]).subscribe((hasCapability: boolean) => {
        hasWrite = hasCapability;
      });
      return hasWrite;
    }
    private hasCapabilityForDayView(): boolean {
      return (
        this.driverCalendarViewDetailsService.hasEventsWithinSelectedDate(
          this.selectedCalendarDate,
          this.calendarResponse
        ) ||
        this.driverCalendarViewDetailsService.hasWorkWeekWithinSelectedDate(
          this.selectedCalendarDate,
          this.calendarResponse
        )
      );
    }
    private hasCapabilityForAddWorkWeeks(): boolean {
      return (
        this.driverCalendarViewDetailsService.hasEventsWithinSelectedDate(
          this.selectedCalendarDate,
          this.calendarResponse
        ) ||
        this.driverCalendarViewDetailsService.hasWorkWeekWithinSelectedDate(
          this.selectedCalendarDate,
          this.calendarResponse
        )
      );
    }
    private hasCapabilityForEditWorkWeek(startDates, endDates): boolean {
      if (this.calendarResponse && !this.calendarResponse.isDriverTerminated)
        if (this.payPeriodStartDate !== moment(new Date()).format())
          if (this.hasDriverAdminCalendarCapability()) return true;
          else if (this.hasDriverWriteCalendarCapability())
            return this.driverCalendarViewDetailsService.isWorkWeekInCurrentPayperiod(
              startDates,
              endDates,
              this.payPeriodStartDate
            );
    }
    private calendarEventStaticData(): void {
      this.calendarEventTypesSubscription$ = this.driverQueryStaticService
        .fetchCalendarEventTypes()
        .subscribe(calendarEventsTypes => (this.driverCalendarEventTypes = calendarEventsTypes));
    }
    private calendarEventType(eventTypeCode: number): string {
      if (this.driverCalendarEventTypes != null) {
        const type = this.driverCalendarEventTypes.find(
          eventType => eventType.code.trim() === eventTypeCode.toString()
        );
        return type ? type.abbreviation : '';
      }
    }
    private handlePayrollSuccess = (payRollResponse: PayrollDatesResponse): void => {
      const data: PayPeriodModel = this.driverCalendarViewDetailsService.getCurrentPayPeriod(
        payRollResponse
      );
      this.payPeriodStartDate = data.payPeriodStartDate;
      this.payPeriodEndDate = data.payPeriodEndDate;
      this.cdr.detectChanges();
    };
    private fetchPayrollDate(): void {
      const calendarPayRollRequest = {
        fromdate: moment(new Date())
          .add(-driverCalendarConstants.payrollDate, 'month')
          .format(driverCalendarConstants.dateFormat),
        todate: moment(new Date())
          .add(driverCalendarConstants.payrollDate, 'month')
          .format(driverCalendarConstants.toDate)
      };
      this.driverCalendarsService
        .fetchPayRoll(calendarPayRollRequest)
        .subscribe(this.handlePayrollSuccess);
    }
    private hasEnableAddEvent(): boolean {
      if (
        (this.hasDriverAdminCalendarCapability() ||
          (this.hasDriverWriteCalendarCapability() &&
            !this.driverCalendarViewDetailsService.isSelectedDateInPreviousPayperiod(
              this.selectedCalendarDate,
              this.payPeriodStartDate
            ))) &&
        this.driverCalendarViewDetailsService.hasWorkWeekWithinSelectedDate(
          this.selectedCalendarDate,
          this.calendarResponse
        )
      )
        return true;
      else return false;
    }
    private hasTimetoAccomodateNewEvent(): boolean {
      return this.driverCalendarViewDetailsService.hasTimetoAccomodateNewEvent(
        this.selectedCalendarDate,
        this.calendarResponse
      );
    }
    private terminatedQuitBar(calendarResponse: DriverCalendarResponse, status: string): void {
      this.calendarEvents.push({
        id: '',
        title: status,
        start: moment(calendarResponse.driverBenefitProfile.terminationDate.timeStamp).format(
          driverCalendarConstants.dateTimeFormat
        ),
        end: moment(calendarResponse.driverBenefitProfile.terminationDate.timeStamp).format(
          driverCalendarConstants.dateTimeFormat
        ),
        color: driverCalendarConstants.terminatedQuit
      });
    }
  }
  