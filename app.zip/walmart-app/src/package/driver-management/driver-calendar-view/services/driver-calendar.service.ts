import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { EnvService } from '@transom/services';
import { ToastrService } from '@transom/ui';
import { Observable } from 'rxjs';
import { catchError, finalize, tap } from 'rxjs/operators';

import { LoadingDialogService } from '../../../common/loading-dialog/loading-dialog.service';
import {
  DRIVER_CALENDAR_END_URL,
  DRIVER_CALENDAR_PAYROLL_URL,
  DRIVER_PROFILE_URL
} from '../../../common/urls';

import { DriverCalendarRequest, DriverCalendarResponse, PayrollDatesResponse } from '../../model';
@Injectable()
export class DriverCalendarService {
  constructor(
    private http: HttpClient,
    private toastrService: ToastrService,
    private translateService: TranslateService,
    private envService: EnvService,
    private loadingDialogService: LoadingDialogService
  ) {}
  fetchDriverCalendar(
    driverID: number,
    calendarRequest: DriverCalendarRequest
  ): Observable<DriverCalendarResponse> {
    this.loadingDialogService.openLoaderDialog(this.translateService.instant('Processing'), true);
    const params: HttpParams = this.getHttpParams(calendarRequest);
    return this.http
      .get<DriverCalendarResponse>(
        this.envService.marketPrefix.toLowerCase() +
          DRIVER_PROFILE_URL +
          driverID +
          DRIVER_CALENDAR_END_URL,
        { params }
      )
      .pipe(
        tap((response: DriverCalendarResponse) => {
          return this.handleResponse(response);
        }),
        catchError((error: HttpErrorResponse) => this.handleError(error)),
        finalize(() => this.loadingDialogService.closeLoader(true))
      );
  }
  fetchPayRoll(calendarRequest: DriverCalendarRequest): Observable<PayrollDatesResponse> {
    const params: HttpParams = this.getHttpParams(calendarRequest);
    return this.http
      .get<PayrollDatesResponse>(
        this.envService.marketPrefix.toLowerCase() + DRIVER_CALENDAR_PAYROLL_URL,
        {
          params
        }
      )
      .pipe(
        tap((response: any) => {
          return this.handleResponse(response);
        }),
        catchError((error: HttpErrorResponse) => this.handleError(error)),
        finalize(() => this.loadingDialogService.closeLoader())
      );
  }
  private handleResponse(result: DriverCalendarResponse): DriverCalendarResponse {
    if (!result) this.toastrService.info(this.translateService.instant('Message_No_Records_Found'));
    return result;
  }
  private handleError(error: HttpErrorResponse): Observable<never> {
    this.loadingDialogService.closeLoader();
    if (error instanceof HttpErrorResponse && error.status === 409)
      this.toastrService.info(this.translateService.instant('Message_No_Records_Found'));
    else this.toastrService.error(this.translateService.instant(error.statusText));
    return new Observable<never>();
  }
  private getHttpParams(driverCalendarParam: DriverCalendarRequest): HttpParams {
    let httpParams: HttpParams = new HttpParams();
    Object.keys(driverCalendarParam).forEach(param => {
      httpParams = httpParams.set(param, driverCalendarParam[param]);
    });
    return httpParams;
  }
}
