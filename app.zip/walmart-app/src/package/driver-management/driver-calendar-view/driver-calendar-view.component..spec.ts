// import { ViewEncapsulation } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder } from '@angular/forms';
import { of as observableOf } from 'rxjs';

import { ActivatedRoute, Router } from '@angular/router';
import { DriverCalendarServiceMock, MockSearchPanelComponent } from '../../mock';
import { DriverQueryStaticService } from '../common-services';
import { DriverCalendarViewComponent } from './driver-calendar-view.component';
import { DriverCalendarService } from './services';

declare var require: any;
const driverCalendarMockData = require('../../mock/json-files/driver-calendar.json');

const router = {
  navigate: jasmine.createSpy('navigate')
};
describe('DriverCalendarViewComponent', () => {
  let component: DriverCalendarViewComponent;
  let fixture: ComponentFixture<DriverCalendarViewComponent>;
  let driverCalendarServiceMock: DriverCalendarServiceMock;
  beforeEach(async(() => {
    driverCalendarServiceMock = new DriverCalendarServiceMock();
    TestBed.configureTestingModule({
      declarations: [DriverCalendarViewComponent, MockSearchPanelComponent]
    }).overrideComponent(DriverCalendarViewComponent, {
      set: {
        template: '<div><twist-search-panel #searchPanel></twist-search-panel></div>',
        encapsulation: ViewEncapsulation.Emulated,
        providers: [
          DriverCalendarService,
          FormBuilder,
          { provide: DriverCalendarService, useValue: driverCalendarServiceMock },
          { provide: DriverQueryStaticService, useValue: driverCalendarServiceMock },
          {
            provide: ActivatedRoute,
            useValue: {
              //tslint:disable-next-line
              queryParams: observableOf({ selectedDriverId: 123 })
            }
          },
          {
            provide: Router,
            useValue: router
          }
        ]
      }
    });
  }));
  beforeEach(() => {
    fixture = TestBed.createComponent(DriverCalendarViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  afterAll(() => {
    fixture.destroy();
    component = null;
  });
  it('should create', () => {
    expect(component).toBeTruthy();
  });
  describe('On Init', () => {
    it('should intialialize driver id form', () => {
      expect(component.driverId).toBeDefined();
    });
    it('should set driver id  from driver query to driver calendar', () => {
      expect(component.driverId.value).toEqual(123);
    });
    it('should set driver as null by default ', () => {
      component.driverId.setValue(null);
    });
  });
  describe('driver calendar search', () => {
    it('should set driver benifit profile deatils when driver calendar search', () => {
      component.driverId.setValue('123');
      component.searchCalendar();
      expect(component.calendarResponse.driverBenefitProfile).toEqual(
        driverCalendarMockData.driverBenefitProfile
      );
    });
    it('should set personal sick when driver calendar search', () => {
      component.driverId.setValue('123');
      component.searchCalendar();
      expect(component.calendarResponse.driverBenefitProfile.personalSick).toEqual(
        driverCalendarMockData.driverBenefitProfile.personalSick
      );
    });
    it('should set safe days when driver calendar based on driver id search', () => {
      component.driverId.setValue('123');
      component.searchCalendar();
      expect(component.calendarResponse.driverBenefitProfile.safeDays).toEqual(
        driverCalendarMockData.driverBenefitProfile.safeDays
      );
    });
    it('should set vacation when driver calendar based on driver id search', () => {
      component.driverId.setValue('123');
      component.searchCalendar();
      expect(component.calendarResponse.driverBenefitProfile.vacation).toEqual(
        driverCalendarMockData.driverBenefitProfile.vacation
      );
    });
    it('should set vacation paycount when driver calendar based on driver id search', () => {
      component.driverId.setValue('123');
      component.searchCalendar();
      expect(component.calendarResponse.driverBenefitProfile.vacationPayCount).toEqual(
        driverCalendarMockData.driverBenefitProfile.vacationPayCount
      );
    });
    it('should set deferred holidays when driver calendar based on driver id search', () => {
      component.driverId.setValue('123');
      component.searchCalendar();
      expect(component.calendarResponse.driverBenefitProfile.deferredHolidays).toEqual(
        driverCalendarMockData.driverBenefitProfile.deferredHolidays
      );
    });
    it('should set firstName  when driver calendar based on driver id search', () => {
      component.driverId.setValue('123');
      component.searchCalendar();
      expect(component.calendarResponse.firstName).toEqual(driverCalendarMockData.firstName);
    });
    it('should set lastname  when driver calendar based on driver id search', () => {
      component.driverId.setValue('123');
      component.searchCalendar();
      expect(component.calendarResponse.lastName).toEqual(driverCalendarMockData.lastName);
    });
    it('should set personalTime when driver calendar based on driver id search', () => {
      component.driverId.setValue('123');
      component.searchCalendar();
      expect(component.calendarResponse.driverBenefitProfile.personalTime).toEqual(
        driverCalendarMockData.driverBenefitProfile.personalTime
      );
    });
    it('should set driver status as host search based on driverid', () => {
      component.driverId.setValue('123');
      const driverCalendarDetails = driverCalendarMockData;
      driverCalendarDetails.driverBenefitProfile.status = '6';
      driverCalendarDetails.driverBenefitProfile.terminationDate.timeStamp = '10/23/1986';
      spyOn(driverCalendarServiceMock, 'fetchDriverCalendar').and.returnValue(
        observableOf(driverCalendarDetails)
      );
      component.searchCalendar();
      expect(component.calendarResponse.driverBenefitProfile.status).toEqual(
        driverCalendarMockData.driverBenefitProfile.status
      );
    });
    it('should set pending schedule status as not available search based on driverid', () => {
      component.driverId.setValue('123');
      const driverCalendarDetails = driverCalendarMockData;
      driverCalendarDetails.driverBenefitProfile.status = '6';
      driverCalendarDetails.driverWorkSchedules[1].driverWorkSchdlStatus = '';
      spyOn(driverCalendarServiceMock, 'fetchDriverCalendar').and.returnValue(
        observableOf(driverCalendarDetails)
      );
      component.searchCalendar();
      expect(component.calendarPendingScheduleType).toEqual('not available');
    });
    it('should set current schedule status as not available search based on driverid', () => {
      component.driverId.setValue('123');
      const driverCalendarDetails = driverCalendarMockData;
      driverCalendarDetails.driverBenefitProfile.status = '6';
      driverCalendarDetails.driverWorkSchedules[0].driverWorkSchdlStatus = '';
      spyOn(driverCalendarServiceMock, 'fetchDriverCalendar').and.returnValue(
        observableOf(driverCalendarDetails)
      );
      component.searchCalendar();
      expect(component.calendarCurrentScheduleType).toEqual('not available');
    });

    it('should not show driver calendar benefits, if response is empty', () => {
      spyOn(driverCalendarServiceMock, 'fetchDriverCalendar').and.returnValue(observableOf(null));
      component.searchCalendar();
      expect(component.calendarResponse).toEqual(null);
    });
    it('should disable search if driverid  is invalid', () => {
      component.driverId.setValue('6801111');
      component.isSearchDisable();
      expect(component.isSearchDisable()).toEqual(true);
    });
    it('should disable search if isd user driver id ', () => {
      component.driverId.setValue('55667');
      component.isSearchDisable();
      expect(component.isSearchDisable()).toEqual(true);
    });
  });
  describe('driver calendar clear', () => {
    it('should clear driver id on reset', () => {
      component.driverId.setValue('123');
      component.resetDriverCalendar();
      expect(component.driverId.value).toEqual(null);
    });
    it('should clear driver benefits details on reset', () => {
      component.driverId.setValue('123');
      component.resetDriverCalendar();
      expect(component.calendarResponse).toEqual(null);
    });
  });
});