import { AfterViewInit, ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { MatSidenav } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import { SearchPanelComponent } from '@transom/ui';
import * as moment from 'moment-timezone';
import { driverConstants } from '../../common/driver-constants';
import { driverCalendarConstants } from '../../constants/driver-management-constant';
import { driverProfileQueryConstants } from '../../constants/driver-management-constant';
import { DriverQueryStaticService } from '../../driver-management/common-services';
import {
  DriverCalendarRequest,
  DriverCalendarResponse,
  KeyValueModel,
  PayrollDatesResponse
} from '../model';
import { DriverCalendarService } from './services';

@Component({
  selector: 'driver-calendar-view',
  templateUrl: './driver-calendar-view.component.html',
  styleUrls: ['./driver-calendar-view.component.scss']
})
export class DriverCalendarViewComponent implements OnInit, AfterViewInit {
  @ViewChild('sidenav') sidenav: MatSidenav;
  @ViewChild('searchPanel') searchPanel: SearchPanelComponent;
  private calendarRequest: DriverCalendarRequest;
  calendarResponse: DriverCalendarResponse;
  payrollDatesResposne: PayrollDatesResponse;
  driverId = new FormControl(null, [
    Validators.maxLength(driverProfileQueryConstants.driverIdMaxLength),
    Validators.pattern(driverConstants.regExpressions.numeric)
  ]);
  driverBenefitStatus: KeyValueModel[];
  driverScheduleType: KeyValueModel[];
  calendarCurrentScheduleType: string;
  calendarPendingScheduleType: string;
  payPeriodStartDate: Date;
  payPeriodEndDate: Date;
  driverStatus: string;
  calendarClear: string;
  searchClose: boolean;

  constructor(
    private cdr: ChangeDetectorRef,
    private driverCalendarsService: DriverCalendarService,
    private driverQueryStaticService: DriverQueryStaticService,
    private route: ActivatedRoute
  ) {}
  ngOnInit() {
    if (
      this.route.queryParams['value'] !== undefined &&
      this.route.queryParams['value'].selectedDriverId !== undefined
    ) {
      this.searchClose = true;
      this.driverId.setValue(this.route.queryParams['value'].selectedDriverId);
    }
    this.fetchPayrollDate();
    this.fetchStaticData();
    this.driverId.valueChanges.subscribe(driverId => this.isSearchDisable());
  }
  ngAfterViewInit() {
    if (
      this.searchClose &&
      this.route.queryParams['value'] !== undefined &&
      this.route.queryParams['value'] !== null &&
      this.route.queryParams['value'].selectedDriverId !== undefined
    ) {
      this.searchPanel.closePanel();
      this.searchClose = false;
      this.cdr.detectChanges();
    }
    this.cdr.detectChanges();
  }

  isSearchDisable(): Boolean {
    if (this.driverId.valid && this.driverId.value === driverCalendarConstants.isdDriverID) {
      this.driverId.setErrors({ isdUserValidation: true });
      return true;
    } else if (!this.driverId.valid) return true;
    else return false;
  }
  resetDriverCalendar(): void {
    this.calendarResponse = null;
    this.calendarCurrentScheduleType = null;
    this.calendarPendingScheduleType = null;
    this.driverStatus = null;
    this.driverId.reset();
    this.calendarClear = driverCalendarConstants.clear;
  }
  setCalendarDate($event): void {
    this.calendarRequest = {
      fromdate: moment(new Date($event.start)).format(driverCalendarConstants.dateFormat),
      todate: moment(new Date($event.end))
        .add(driverCalendarConstants.startDate, 'days')
        .format(driverCalendarConstants.toDate)
    };
    this.searchCalendar();
  }
  private fetchPayrollDate(): void {
    const calendarPayRollRequest = {
      fromdate: moment(new Date())
        .add(-driverCalendarConstants.payrollDate, 'month')
        .format(driverCalendarConstants.dateFormat),
      todate: moment(new Date())
        .add(driverCalendarConstants.payrollDate, 'month')
        .format(driverCalendarConstants.toDate)
    };
    this.driverCalendarsService
      .fetchPayRoll(calendarPayRollRequest)
      .subscribe(this.handlePayrollSuccess);
  }
  private handlePayrollSuccess = (payRollResponse: PayrollDatesResponse): void => {
    this.getCurrentPayPeriod(payRollResponse);
  };
  private getCurrentPayPeriod = (payRollResponse: PayrollDatesResponse): void => {
    let currentPayPeriod;
    if (payRollResponse.payPeriods !== undefined && payRollResponse.payPeriods !== null) {
      currentPayPeriod = payRollResponse.payPeriods.find(
        payrollOffset =>
          payrollOffset.offsetFromCurrent === driverCalendarConstants.currentPayPeriodOffsetStart
      );
      if (currentPayPeriod !== null)
        this.payPeriodStartDate = moment(new Date(currentPayPeriod.payrollDate))
          .add(driverCalendarConstants.startDate, 'days')
          .format(driverCalendarConstants.dateYearFormat);
      const endPayPeriod = payRollResponse.payPeriods.find(
        payrollOffset =>
          payrollOffset.offsetFromCurrent === driverCalendarConstants.currentPayPeriodOffsetEnd
      );
      this.payPeriodEndDate = moment(new Date(endPayPeriod.payrollDate)).format(
        driverCalendarConstants.dateYearFormat
      );
    }
  };
  searchCalendar(status?: boolean): void {
    this.calendarClear = driverCalendarConstants.resetChanges;
    this.calendarClear = driverCalendarConstants.resetChanges;
    if (this.driverId.value != null)
      this.driverCalendarsService
        .fetchDriverCalendar(this.driverId.value, this.calendarRequest)
        .subscribe((driverCalendarResponse: DriverCalendarResponse) =>
          this.handleFetchCalenderSuccess(driverCalendarResponse, status)
        );
  }
  private fetchStaticData(): void {
    this.driverQueryStaticService
      .fetchDriverBenefitStatus()
      .subscribe((response: KeyValueModel[]) => {
        this.driverBenefitStatus = response;
      });
    this.driverQueryStaticService.fetchScheduleType().subscribe((response: KeyValueModel[]) => {
      this.driverScheduleType = response;
    });
  }
  private handleFetchCalenderSuccess = (
    driverCalendarResponse: DriverCalendarResponse,
    status: boolean
  ): void => {
    this.calendarResponse = null;
    if (driverCalendarResponse !== undefined && driverCalendarResponse != null) {
      if (status) this.searchPanel.closePanel();
      if (
        this.searchClose &&
        this.route.queryParams['value'] !== undefined &&
        this.route.queryParams['value'] !== null &&
        this.route.queryParams['value'].selectedDriverId !== undefined
      ) {
        this.searchPanel.closePanel();
        this.searchClose = false;
      }
      if (driverCalendarResponse.serviceCoCode === driverProfileQueryConstants.serviceCoCode)
        driverCalendarResponse.isWalmartDriver = true;
      else driverCalendarResponse.isWalmartDriver = false;
      this.getDriverStatus(driverCalendarResponse);
      this.calendarPendingScheduleType = this.getWorkSchedule(driverCalendarResponse, driverCalendarConstants.driversPendingScheduleStatus);
      this.calendarCurrentScheduleType = this.getWorkSchedule(driverCalendarResponse, driverCalendarConstants.driversCurrentScheduleStatus);
      this.calendarResponse = driverCalendarResponse;
    }
  };
  private getDriverStatus = (driverCalendarResponse: DriverCalendarResponse): void => {
    driverCalendarResponse.isDriverTerminated = false;
    if (driverCalendarResponse.driverBenefitProfile !== undefined && driverCalendarResponse.driverBenefitProfile !== null
    ) {
      const driverStatus = this.driverBenefitStatus.find(
        status => status.id === driverCalendarResponse.driverBenefitProfile.status
      );
      this.driverStatus = driverStatus ? driverStatus.name : '';
      if (
        (driverCalendarResponse.driverBenefitProfile.terminationDate !== null &&
          driverCalendarResponse.driverBenefitProfile.terminationDate.timeStamp.trim() &&
          driverCalendarResponse.driverBenefitProfile.status ===
            driverCalendarConstants.hostStatusQTCode) ||
        driverCalendarResponse.driverBenefitProfile.status ===
          driverCalendarConstants.hostStatusFICode
      )
        driverCalendarResponse.isDriverTerminated = true;
      else driverCalendarResponse.isDriverTerminated = false;
    }
  };
  private getWorkSchedule(driverCalendarResponse: DriverCalendarResponse, driversScheduleStatus: string): string {
    let getCurrentScheduleType;
    if (driverCalendarResponse.driverWorkSchedules !== null && driverCalendarResponse.driverWorkSchedules !== undefined) {
      const getPendingStatus = driverCalendarResponse.driverWorkSchedules.find(
        driverWorkSchedule => driverWorkSchedule.driverWorkSchdlStatus === driversScheduleStatus
      );
      if (getPendingStatus) {
        const getPendingScheduleType = this.driverScheduleType.find(
          scheduleTypeId => scheduleTypeId.id === getPendingStatus.drivingScheduleCode.toString()
        );
        getCurrentScheduleType = ':' + getPendingScheduleType.name;
      } else getCurrentScheduleType = driverCalendarConstants.notAvailable;
      return getCurrentScheduleType;
    } else return driverCalendarConstants.notAvailable;
  }
  
  rebindCalendarEvent(event) {
    this.searchCalendar()
  }
}
