import { HttpHeaders } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { async, getTestBed, TestBed } from '@angular/core/testing';
import { TranslateService } from '@ngx-translate/core';
import { EnvService } from '@transom/services';
import { ToastrService } from '@transom/ui';

import { LoadingDialogService } from '../../../common/loading-dialog/loading-dialog.service';
import { DRIVER_QUERY_VIEW_SERVICE_URL } from '../../../common/urls';
import {
  LoadingDialogServiceMock,
  ToastrMessageServiceMock,
  TranslateServiceMock
} from '../../../mock';
import { DriverProfileQueryCriteria } from '../../model';
import { DriverQueryProfileService } from './driver-query-profile.service';
declare var require: any;
const driverQueryProfileMock = require('../../../mock/json-files/driver-query-profile.json');
describe('DriverQueryProfileService', () => {
  let mockBackend: HttpTestingController;
  let translateServiceMock: TranslateServiceMock;
  let toastrServiceMock: ToastrMessageServiceMock;
  let driverQueryProfileService: DriverQueryProfileService;
  let loadingServiceMock: LoadingDialogServiceMock;
  const marketPrefixValue = '/us';
  const envServiceMock = {
    marketPrefix: marketPrefixValue
  };
  const dialogLoaderRef = {
    close: jasmine.createSpy('close')
  };
  beforeEach(async(() => {
    translateServiceMock = new TranslateServiceMock();
    toastrServiceMock = new ToastrMessageServiceMock();
    loadingServiceMock = new LoadingDialogServiceMock();
    TestBed.configureTestingModule({
      providers: [
        DriverQueryProfileService,
        { provide: ToastrService, useValue: toastrServiceMock },
        { provide: TranslateService, useValue: translateServiceMock },
        { provide: LoadingDialogService, useValue: loadingServiceMock },
        { provide: EnvService, useValue: envServiceMock }
      ],
      imports: [HttpClientTestingModule]
    });
    mockBackend = getTestBed().get(HttpTestingController);
    driverQueryProfileService = getTestBed().get(DriverQueryProfileService);
    (driverQueryProfileService as any)['dialogLoader'] = dialogLoaderRef;
  }));
  describe('success response in  driver query profile service', () => {
    it('should get the driver query details if service success', async(() => {
      driverQueryProfileService = getTestBed().get(DriverQueryProfileService);
      const driverProfileQueryCriteria = new DriverProfileQueryCriteria();
      const url = envServiceMock.marketPrefix.toLowerCase() + DRIVER_QUERY_VIEW_SERVICE_URL;
      driverQueryProfileService
        .fetchDriverQueryDetails(driverProfileQueryCriteria)
        .subscribe((successResult: any) => {
          expect(successResult).toEqual(driverQueryProfileMock.driverProfilePreviewResponse);
        });
      mockBackend
        .expectOne({
          url: url,
          method: 'POST'
        })
        .flush(driverQueryProfileMock.driverProfilePreviewResponse);
    }));
    it('should show info message if response is empty', async(() => {
      const tostMsgSpy = spyOn(toastrServiceMock, 'info').and.callThrough();
      const url = envServiceMock.marketPrefix.toLowerCase() + DRIVER_QUERY_VIEW_SERVICE_URL;
      const driverQueryProfileRequest: DriverProfileQueryCriteria = new DriverProfileQueryCriteria();
      const previewResponse = '';
      const customInfoMessage = 'test';
      driverQueryProfileService
        .fetchDriverQueryDetails(driverQueryProfileRequest)
        .subscribe(successResult => {
          expect(tostMsgSpy).toHaveBeenCalledWith(customInfoMessage);
        });
      mockBackend
        .expectOne({
          url: url,
          method: 'POST'
        })
        .flush(previewResponse);
    }));
  });
  describe('failure response in driver query profile service', () => {
    it('should show custom error message if response status 404', async(() => {
      spyOn(toastrServiceMock, 'info').and.callThrough();
      const customErrorMessage = 'test';
      const url = envServiceMock.marketPrefix.toLowerCase() + DRIVER_QUERY_VIEW_SERVICE_URL;
      const driverQueryProfileRequest: DriverProfileQueryCriteria = new DriverProfileQueryCriteria();
      driverQueryProfileService
        .fetchDriverQueryDetails(driverQueryProfileRequest)
        .subscribe(() => expect(toastrServiceMock.info).toHaveBeenCalledWith(customErrorMessage));
      mockBackend
        .expectOne({
          url: url,
          method: 'POST'
        })
        .flush({ message: 'Error' }, { status: 404, statusText: 'No record found' });
    }));
    it('should show error message if response status 500', async(() => {
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const url = envServiceMock.marketPrefix.toLowerCase() + DRIVER_QUERY_VIEW_SERVICE_URL;
      const driverQueryProfileRequest: DriverProfileQueryCriteria = new DriverProfileQueryCriteria();
      const customErrorMessage = 'test';
      driverQueryProfileService
        .fetchDriverQueryDetails(driverQueryProfileRequest)
        .subscribe(() => expect(toastrServiceMock.error).toHaveBeenCalledWith(customErrorMessage));
      mockBackend
        .expectOne({
          url: url,
          method: 'POST'
        })
        .flush({ message: 'Error' }, { status: 500, statusText: 'Server Error' });
    }));

    it('should show  toastr info message if response status is 409 ', async(() => {
      spyOn(toastrServiceMock, 'info').and.callThrough();
      const url = envServiceMock.marketPrefix.toLowerCase() + DRIVER_QUERY_VIEW_SERVICE_URL;
      const driverQueryProfileRequest: DriverProfileQueryCriteria = new DriverProfileQueryCriteria();
      driverQueryProfileService
        .fetchDriverQueryDetails(driverQueryProfileRequest)
        .subscribe(() =>
          expect(toastrServiceMock.info).toHaveBeenCalledWith(
            translateServiceMock.instant('Message_No_Records_Found')
          )
        );
      mockBackend
        .expectOne({
          url: url,
          method: 'POST'
        })
        .flush(
          { message: 'Error' },
          { headers: new HttpHeaders(), status: 409, statusText: 'No record found' }
        );
    }));
    it('should show  toastr info message if response status is 409 ', async(() => {
      spyOn(toastrServiceMock, 'info').and.callThrough();
      const url = envServiceMock.marketPrefix.toLowerCase() + DRIVER_QUERY_VIEW_SERVICE_URL;
      const driverQueryProfileRequest: DriverProfileQueryCriteria = new DriverProfileQueryCriteria();
      driverQueryProfileService
        .fetchDriverQueryDetails(driverQueryProfileRequest)
        .subscribe(() =>
          expect(toastrServiceMock.info).toHaveBeenCalledWith(
            translateServiceMock.instant('Message_No_Records_Found')
          )
        );
      mockBackend
        .expectOne({
          url: url,
          method: 'POST'
        })
        .flush(
          { message: 'Error' },
          { headers: new HttpHeaders(), status: 409, statusText: 'No record found' }
        );
    }));
  });
});
