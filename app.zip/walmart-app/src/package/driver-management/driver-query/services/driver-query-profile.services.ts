import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { EnvService } from '@transom/services';
import { ToastrService } from '@transom/ui';
import { Observable, of } from 'rxjs';
import { catchError, finalize, map } from 'rxjs/operators';

import { LoadingDialogService } from '../../../common/loading-dialog/loading-dialog.service';
import { DRIVER_QUERY_VIEW_SERVICE_URL } from '../../../common/urls';
import { errors } from '../../../constants/driver-management-constant';
import {
  DriverProfileQueryCriteria,
  DriverProfileQueryResponse,
  DriverQueryPreviewResponse
} from '../../model';

@Injectable()
export class DriverQueryProfileService {
  constructor(
    private http: HttpClient,
    private envService: EnvService,
    private loadingDialogService: LoadingDialogService,
    private toastrService: ToastrService,
    private translateService: TranslateService
  ) {}
  fetchDriverQueryDetails(
    searchDriverID: DriverProfileQueryCriteria
  ): Observable<DriverProfileQueryResponse[]> {
    this.loadingDialogService.openLoaderDialog(this.translateService.instant('Processing'));
    return this.http
      .post<DriverQueryPreviewResponse>(
        this.envService.marketPrefix.toLowerCase() + DRIVER_QUERY_VIEW_SERVICE_URL,
        { driverProfileCriteria: searchDriverID },
        { headers: new HttpHeaders({ 'skip-retry': 'true' }) }
      )
      .pipe(
        map((response: DriverQueryPreviewResponse) => {
          if (!response || (response && response.driverProfilePreviewResponse.length <= 0)) {
            this.toastrService.info(this.translateService.instant('Message_No_Records_Found'));
            return [];
          } else return response.driverProfilePreviewResponse;
        }),
        catchError(error => {
          if (error.status === errors.conflict) {
            this.toastrService.info(this.translateService.instant('Message_No_Records_Found'));
            return of([]);
          } else return this.handleError(error);
        }),
        finalize(() => this.loadingDialogService.closeLoader())
      );
  }
  fetchQueryPreviewResponse(result?: DriverProfileQueryResponse[]): DriverProfileQueryResponse[] {
    if (!result) this.toastrService.info(this.translateService.instant('Message_No_Records_Found'));
    else return result;
  }
  private handleError(errorResponse: HttpErrorResponse): Observable<never> {
    this.loadingDialogService.closeLoader();
    if (errorResponse) {
      const errorStatusCode = errorResponse.status;
      if (errorStatusCode === errors.notFound)
        this.toastrService.info(this.translateService.instant('Message_No_Records_Found'));
      else if (errorStatusCode === errors.internalServer)
        this.toastrService.error(this.translateService.instant('InternalServerError'));
      else this.toastrService.error(errorResponse.statusText);
    }
    return new Observable<never>();
  }
}
