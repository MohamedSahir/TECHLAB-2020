import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Columns } from '@transom/ui';

@Injectable()
export class DriverQueryColumnsService {
  constructor(private translate: TranslateService) {}
  private driverQueryGridColumns: Columns[] = [
    {
      columnName: this.translate.instant('DriverId_Full'),
      field: 'driverId',
      hideShow: { hidden: false },
      orderable: true,
      width: '100'
    },
    {
      columnName: this.translate.instant('FirstName'),
      field: 'firstName',
      hideShow: { hidden: false },
      orderable: true,
      width: '300'
    },
    {
      columnName: this.translate.instant('LastName'),
      field: 'lastName',
      hideShow: { hidden: false },
      orderable: true,
      width: '300px'
    },
    {
      columnName: this.translate.instant('Region'),
      field: 'region',
      hideShow: { hidden: false },
      orderable: true,
      width: '100px'
    },
    {
      columnName: this.translate.instant('DriverStatus'),
      field: 'driverStatus',
      hideShow: { hidden: false },
      orderable: true,
      width: '130px'
    },
    {
      columnName: this.translate.instant('DriverType'),
      field: 'driverTypeCode',
      hideShow: { hidden: false },
      orderable: true,
      width: '100px'
    },
    {
      columnName: this.translate.instant('Company'),
      field: 'serviceCoCode',
      hideShow: { hidden: false },
      orderable: true,
      width: '80px'
    },
    {
      columnName: this.translate.instant('Board'),
      field: 'coordinatorBoard',
      hideShow: { hidden: false },
      orderable: true,
      width: '120px'
    },
    {
      columnName: this.translate.instant('Team_Partner'),
      field: 'teamPartner',
      hideShow: { hidden: false },
      orderable: true,
      width: '225px'
    },
    {
      columnName: this.translate.instant('Domicile_Full'),
      field: 'domicile',
      hideShow: { hidden: false },
      orderable: true,
      width: '200px'
    },
    {
      columnName: this.translate.instant('Smoker_Indicator'),
      field: 'smokerIndicator',
      hideShow: { hidden: false },
      orderable: true,
      width: '100px'
    },
    {
      columnName: this.translate.instant('Longevity_Rank'),
      field: 'longevitySeqNumber',
      hideShow: { hidden: false },
      orderable: true,
      width: '100px'
    },
    {
      columnName: this.translate.instant('DepartDay'),
      field: 'departDay',
      hideShow: { hidden: false },
      orderable: true,
      width: '100px'
    },
    {
      columnName: this.translate.instant('DepartTime'),
      field: 'departTime',
      hideShow: { hidden: false },
      orderable: true,
      width: '100px'
    }
  ];
  private safetyLogsGridColumns: Columns[] = [
    {
      columnName: this.translate.instant('Type'),
      field: 'safetyLogTypeDesc',
      hideShow: { hidden: false },
      orderable: true,
      width: '100'
    },
    {
      columnName: this.translate.instant('Date'),
      field: 'safetyLogDate',
      hideShow: { hidden: false },
      orderable: true,
      width: '200'
    },
    {
      columnName: this.translate.instant('Remarks'),
      field: 'remarks',
      hideShow: { hidden: false },
      orderable: true,
      width: '300px'
    },
    {
      columnName: this.translate.instant('LastChangeUserId'),
      field: 'lastChangeUserId',
      hideShow: { hidden: false },
      orderable: true,
      width: '100px'
    },
    {
      columnName: this.translate.instant('LastChangeTS'),
      field: 'lastChangeTS',
      hideShow: { hidden: false },
      orderable: true,
      width: '130px'
    }
  ];
  getColumnName() {
    return this.driverQueryGridColumns;
  }
  getDriverLogsColumnName() {
    return this.safetyLogsGridColumns;
  }
}
