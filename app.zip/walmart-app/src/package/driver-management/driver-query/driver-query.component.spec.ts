import { ViewEncapsulation } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder } from '@angular/forms';
import { MatProgressSpinnerModule } from '@angular/material';
import { MatDialog, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { NotProdGuard } from '@transom/guards';
import { AuthZService } from '@transom/services';
import { ToastrService } from '@transom/ui';
import { of as observableOf } from 'rxjs';
import { NotCertGuard } from '../../common/guards';
import {
  DriverManagementServiceMock,
  DriverQueryProfileServiceMock,
  DriverQueryStaticServiceMock,
  FakeCascadingSearchPanelComponent,
  FakeMatSideNavComponent,
  FakeMultiInputComponent,
  FakeSearchPanelComponent,
  NotCertGuardMock,
  NotProdGuardMock,
  ToastrMessageServiceMock,
  TranslateServiceMock,
  TransomGridMockComponent
} from '../../mock';
import { DriverManagementService, DriverQueryStaticService } from '../common-services';
import { DriverProfileQueryResponse } from '../model';
import { LoadingDialogService } from './../../common/loading-dialog/loading-dialog.service';
import {
  ActivateDedicatedDriverServiceMock,
  LoadingDialogServiceMock,
  MatDialogMock
} from './../../mock/';
import { ActivateDedicatedDriverService } from './../activate-dedicated-drivers/services/activate-dedicated-driver.service';
import { DriverQueryComponent } from './driver-query.component';
import { DriverQueryProfileService } from './services';
declare var require: any;
const scheduleTypeMockData = require('../../mock/json-files/scheduleType.json');
const coordinatorBoardMockData = require('../../mock/json-files/coordinatorBoard.json');
const driverQueryProfileMock = require('../../mock/json-files/driver-query-profile.json');

describe('DriverQueryComponent', () => {
  let component: DriverQueryComponent;
  let toastrServiceMock: ToastrMessageServiceMock;
  let fixture: ComponentFixture<DriverQueryComponent>;
  let driverQueryStaticServiceMock: DriverQueryStaticServiceMock;
  let driverManagementServiceMock: DriverManagementServiceMock;
  let driverQueryProfileServiceMock: DriverQueryProfileServiceMock;
  let translateServiceMock: TranslateServiceMock;
  let notCertGuardMock: NotCertGuardMock;
  let notProdGuardMock: NotProdGuardMock;
  let matDialogRefMock: MatDialogMock;
  let dialog: MatDialog;
  let activateDedicatedDriverServiceMock: ActivateDedicatedDriverServiceMock;
  let loadingServiceMock: LoadingDialogServiceMock;
  const router = {
    navigate: jasmine.createSpy('navigate')
  };
  const mockAuth = {
    hasOneCapabilityOf() {
      return observableOf(true);
    }
  };
  const mockDialogRef = {
    afterClosed: function() {
      return observableOf({ data: 'test' });
    },
    close: function() {
      return 'closed';
    }
  };
  const mockMatDialog = {
    open: function() {
      return mockDialogRef;
    },
    closeAll: function() {
      return mockDialogRef.close() + ' all';
    }
  };
  const router = {
    navigate: jasmine.createSpy('navigate')
  };

  beforeEach(async(() => {
    notCertGuardMock = new NotCertGuardMock();
    notProdGuardMock = new NotProdGuardMock();
    driverQueryStaticServiceMock = new DriverQueryStaticServiceMock();
    driverManagementServiceMock = new DriverManagementServiceMock();
    driverQueryProfileServiceMock = new DriverQueryProfileServiceMock();
    toastrServiceMock = new ToastrMessageServiceMock();
    translateServiceMock = new TranslateServiceMock();
    matDialogRefMock = new MatDialogMock();
    activateDedicatedDriverServiceMock = new ActivateDedicatedDriverServiceMock();
    loadingServiceMock = new LoadingDialogServiceMock();
    TestBed.configureTestingModule({
      declarations: [
        DriverQueryComponent,
        FakeCascadingSearchPanelComponent,
        FakeSearchPanelComponent,
        FakeMatSideNavComponent,
        FakeMultiInputComponent,
        TransomGridMockComponent
      ],
      imports: [MatDialogModule, MatProgressSpinnerModule],
      providers: [
        FormBuilder,
        { provide: DriverManagementService, useValue: driverManagementServiceMock },
        { provide: DriverQueryStaticService, useValue: driverQueryStaticServiceMock },
        { provide: DriverQueryProfileService, useValue: driverQueryProfileServiceMock },
        { provide: ToastrService, useValue: toastrServiceMock },
        { provide: AuthZService, useValue: mockAuth },
        { provide: TranslateService, useValue: translateServiceMock },
        { provide: NotCertGuard, useValue: notCertGuardMock },
        { provide: NotProdGuard, useValue: notProdGuardMock },
        { provide: MatDialog, useValue: mockMatDialog },
        { provide: MatDialogRef, useValue: mockDialogRef },
        { provide: ActivateDedicatedDriverService, useValue: activateDedicatedDriverServiceMock },
        { provide: LoadingDialogService, useValue: loadingServiceMock },
        {
          provide: ActivatedRoute,
          useValue: {
            //tslint:disable-next-line
            queryParams: observableOf({ selectedDriverId: 123 })
          }
        },
        {
          provide: Router,
          useValue: router
        },
        { provide: LoadingDialogService, useValue: loadingServiceMock }
      ]
    })
      .overrideComponent(DriverQueryComponent, {
        set: {
          template: `<div>
            <fake-search-panel #searchPanel> </fake-search-panel>
            <fake-multi-input-component #driverIds  transomIsWholeNumber></fake-multi-input-component>
            <transom-grid id='dr-qry-view-grid' [columns]="gridColumn" [gridProperties]="gridproperties" [rowDetails]="rows" [paginationRequired]=true [singleSelect]=false (singleClick)="driverGridSingleClick($event)" (doubleClick)="driverQueryProfileView()" #driverProfileQueryGrid></transom-grid>
            <fake-cascading-search-panel #cascadeSearchPanel></fake-cascading-search-panel>
           </div>`,
          encapsulation: ViewEncapsulation.Emulated
        }
      })
      .compileComponents();
    dialog = TestBed.get(MatDialog);
  }));
  beforeEach(() => {
    fixture = TestBed.createComponent(DriverQueryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.dialog = dialog;
  });
  it('should create a driver query component', () => {
    expect(component).toBeTruthy();
  });

  describe('driver query form  initialization', () => {
    it('should initialize driver query form', () => {
      expect(component.driverQueryForm.controls.domicile.value).toBe(null);
    });
  });
  describe('reset functionality', () => {
    it('should clear the driver value on reset', () => {
      component.driverId.setValue(['99996', '777']);
      component.resetDriverQueryFormToDefault();
      expect(component.driverId.value).toEqual(null);
    });
    it('should clear the domicile values on clear', () => {
      component.driverQueryForm.controls.domicile.setValue('6197');
      component.resetDriverQueryFormToDefault();
      expect(component.driverQueryForm.controls.domicile.value).toEqual(null);
    });
    it('should clear the  coordinator board values on clear', () => {
      component.driverQueryForm.controls.coordinatorBoard.setValue('A');
      component.resetDriverQueryFormToDefault();
      expect(component.driverQueryForm.controls.coordinatorBoard.value).toEqual(null);
    });
    it('should clear the schedule types values on clear', () => {
      component.driverQueryForm.controls.scheduleTypes.setValue('6197');
      component.resetDriverQueryFormToDefault();
      expect(component.driverQueryForm.controls.scheduleTypes.value).toEqual(null);
    });
  });

  describe('static data binding', () => {
    it('should get and initialize domicile list', () => {
      component.domicileOptions$.subscribe(response => {
        expect(response).toEqual(driverQueryProfileMock.businessLocation);
      });
    });
    it('should get and initialize coordinator board list', () => {
      component.setCoodinatorOptions$.subscribe(response => {
        expect(response).toEqual(coordinatorBoardMockData);
      });
    });
    it('should get and initialize schedule type list', () => {
      component.scheduleTypeOptions$.subscribe(response => {
        expect(response).toEqual(scheduleTypeMockData);
      });
    });
    it('should set  a departday on departday selection', () => {
      const departDay = 'sunday';
      component.driverQueryForm.get('departDay').setValue(departDay);
      expect(component.driverQueryForm.get('departDay').value).toEqual(departDay);
    });
    it('should set a depart time on departtime selection', () => {
      const departTime = '00:00';
      component.driverQueryForm.get('departTime').setValue(departTime);
      expect(component.driverQueryForm.get('departTime').value).toEqual(departTime);
    });
  });
  describe('driver query form validation', () => {
    it('should enable the driver query search  if driverID is valid', () => {
      component.driverId.setValue('77');
      component.driverId.setErrors(null);
      expect(component.isSearchDisable()).toEqual(false);
    });
    it('should enable the driver query search if domicile is valid', () => {
      component.driverQueryForm.get('domicile').setValue('6801');
      expect(component.isSearchDisable()).toEqual(false);
    });
    it('should disable the driver query search on initialization', () => {
      expect(component.isSearchDisable()).toEqual(true);
    });
    it('should enable the domicile on initialization', () => {
      expect(component.isDisabledDomicile()).toEqual(false);
    });
    it('should enable the driverId on initialize', () => {
      expect(component.driverId.disabled).toEqual(false);
    });
    it('should disable schedule type,coordinator board,driver status,driver type,depart time,depart day  when domicile is not have value', () => {
      expect(component.isDisableOtherCtrlExceptDomicile()).toEqual(true);
    });
    it('should disable domicile,schedule type,coordinator board,driver status,driver type,depart time,departday  when driverId have value', () => {
      component.driverId.setValue('6801');
      expect(component.isDisableOtherCtrlExceptDomicile()).toEqual(true);
    });
    it('should enable schedule type,coordinator board, driver status,driver type, depart time, depart day when domicile have value', () => {
      component.driverQueryForm.patchValue({ domicile: [{ id: null, name: '6801' }] });
      expect(component.isDisableOtherCtrlExceptDomicile()).toEqual(false);
    });

    it('should enable the domicile is valid', () => {
      component.driverQueryForm.get('domicile').setValue('6801');
      expect(component.isDisabledDomicile()).toEqual(false);
    });

    it('should check whether the max length of entered characters for driverId id is 6', () => {
      const maxlength = 6;
      expect(component.driverIdMultiInput['userInput'].nativeElement.maxLength).toBe(maxlength);
    });
  });

  describe('driver query search', () => {
    it('should search based on driverid', () => {
      const driverIDs = ['77', '78'];
      component.driverId.setValue(driverIDs);
      component.searchDriverProfileQuery();
      expect(component.rows.length).toBe(3);
    });
    it('should set driverid in driverId search', () => {
      const driverIDs = ['77'];
      component.driverId.setValue(driverIDs);
      component.searchDriverProfileQuery();
      expect(component.rows[0].driverId).toEqual(77);
    });

    it('should set error when invalid driverid in driverId search', () => {
      const driverIDs = ['77@#'];
      component.driverId.setValue(driverIDs);
      component.ngOnInit();
      expect(component.driverId.errors.validateDriverId).toEqual(true);
    });

    it('should set an error in driverId if driverId less than maxlimit', () => {
      const driverIDs = '77';
      const maxDriverId = [];
      let startValue;
      for (startValue = 0; startValue < 52; startValue++) maxDriverId.push(driverIDs);
      component.driverId.setValue(maxDriverId);
      expect(component.driverId.errors.validDriverIdLimit).toEqual(true);
    });

    it('should clear domicile error if driverId have value', () => {
      const driverIDs = '77';
      component.driverQueryForm.controls.domicile.setValue(driverQueryProfileMock.domicileOption);
      component.driverId.setValue(driverIDs);
      expect(component.driverQueryForm.controls.domicile.errors).toEqual(null);
    });

    it('should show validation message when domicile have more than 6 items', () => {
      component.driverQueryForm.controls.domicile.setValue(driverQueryProfileMock.domicileOption);
      expect(component.driverQueryForm.controls.domicile.errors.setDomicileError).toEqual(true);
    });

    it('should only show 1000 search records  when  search response have more than 1000 items', () => {
      const driverQueryResponse = [];
      let i;
      for (i = 0; i < 1002; i++)
        driverQueryResponse.push(driverQueryProfileMock.driverProfilePreviewResponse[0]);
      spyOn(driverQueryProfileServiceMock, 'fetchDriverQueryDetails').and.returnValue(
        observableOf(driverQueryResponse)
      );
      component.searchDriverProfileQuery();
      expect(component.rows.length).toEqual(1000);
    });

    it('should show domicile result when search based on domicile name', () => {
      const domicile = [
        { id: null, name: '6197' },
        { id: null, name: '6801' },
        { id: null, name: '6804' }
      ];
      component.driverQueryForm.get('domicile').setValue(domicile);
      component.searchDriverProfileQuery();
      expect(component.rows.length).toBe(3);
    });

    it('should set domicile and search based on domicile value ', () => {
      const domicile = [{ id: null, name: '6801' }];
      component.driverQueryForm.get('domicile').setValue(domicile);
      component.searchDriverProfileQuery();
      expect(component.rows[0].domicile).toEqual(6801);
    });
    it('should set company and based on company search ', () => {
      const company = [{ id: null, name: 'Dedicated' }];
      component.driverQueryForm.controls.company.setValue(company);
      component.searchDriverProfileQuery();
      expect(component.rows[0].serviceCoCode).toEqual('Dedicated');
    });
    it('should show driver tractor if have driver tractor capability', () => {
      component.rows = driverQueryProfileMock.driverProfilePreviewResponse;
      component.isDriverTractorVisible();
      expect(component.isDriverTractorVisible()).toEqual(true);
    });
    it('should  not show driver tractor if  driver tractor has no  capability', () => {
      component.rows = driverQueryProfileMock.driverProfilePreviewResponse;
      spyOn(component as any, 'hasCapabilityOf').and.returnValue(observableOf(false));
      component.isDriverTractorVisible();
      expect(component.isDriverTractorVisible()).toEqual(false);
    });
    it('should  not show driver calender if  driver calender has no  capability', () => {
      spyOn(component as any, 'hasCapabilityOf').and.returnValue(observableOf(false));
      component.rows = driverQueryProfileMock.driverProfilePreviewResponse;
      expect(component.isDriverCalanderVisible()).toEqual(false);
    });

    it('should  not show activated dedicated driver if  activated dedicated driver has no  capability', () => {
      component.rows = driverQueryProfileMock.driverProfilePreviewResponse;
      spyOn(component as any, 'hasCapabilityOf').and.returnValue(observableOf(false));
      component.isActivatedDedicatedVisible();
      expect(component.isActivatedDedicatedVisible()).toEqual(false);
    });
    it('should show driver calendar if driver calendar capability with selected item be less than 1', () => {
      component.driverProfileQueryGrid.selected = [
        driverQueryProfileMock.driverProfilePreviewResponse[0]
      ];
      component.isDriverCalanderVisible();
      expect(component.isDriverCalanderVisible()).toEqual(true);
    });
    it('should not show driver calendar if  driver calendar have  capability with selected item be greater than 1', () => {
      component.driverProfileQueryGrid.selected =
        driverQueryProfileMock.driverProfilePreviewResponse;
      component.isDriverCalanderVisible();
      expect(component.isDriverCalanderVisible()).toEqual(false);
    });
    it('should not show the activated dedicated driver if  activated dedicated driver no capability ', () => {
      component.driverProfileQueryGrid = component.driverProfileQueryGrid;
      component.isActivatedDedicatedVisible();
      expect(component.isActivatedDedicatedVisible()).toEqual(false);
    });
    it('should show activated dedicated driver if activated dedicated driver have capability and firstName and last name be empty with dedicated company and driverStatus to be Inactive', () => {
      component.driverProfileQueryGrid.selected = [
        driverQueryProfileMock.driverProfilePreviewResponse[0]
      ];
      (component as any).isActivatedDriverCapability();
      component.isActivatedDedicatedVisible();
      expect(component.isActivatedDedicatedVisible()).toEqual(true);
    });
    it('should show  activated dedicated driver if activated dedicated driver have capability and firstName and last name be empty with dedicated company and driverStatus to be paypending', () => {
      component.driverProfileQueryGrid.selected = [
        driverQueryProfileMock.driverProfilePreviewResponse[1]
      ];
      (component as any).isActivatedDriverCapability();
      component.isActivatedDedicatedVisible();
      expect(component.isActivatedDedicatedVisible()).toEqual(true);
    });
  });

  describe('activated Dedicated Driver', () => {
    it('should open activated dedicated driver dialog', () => {
      spyOn(matDialogRefMock, 'open').and.returnValue({
        afterClosed: () => observableOf({ success: false, response: [] })
      });
      spyOn(matDialogRefMock, 'afterClosed').and.callThrough();
      component.openActivateDedicatedDriverDialog();
      //not actually being opened
      // expect(matDialogRefMock.open).toHaveBeenCalled();
    });

    it('should empty the rows and close popup', () => {
      const driverIDs = ['77', '78'];
      component.driverId.setValue(driverIDs);
      spyOn(matDialogRefMock, 'afterClosed').and.callThrough();
      component.openActivateDedicatedDriverDialog();
      expect(component.rows.length).toEqual(3);
    });
  });

  it('should show the driver profile details of selected driver and list all drivers on driver selection', () => {
    const selectedRow = <DriverProfileQueryResponse>(
      driverQueryProfileMock.driverProfilePreviewResponse[0]
    );
    component.showDriverProfileDetails(selectedRow);
    expect(component.selectedDriver).toEqual({ driverId: selectedRow.driverId, index: 0 });
  });

  it('should show the driver profile details of selected driver on driver selection from list', () => {
    const driverId = 1034;
    const region = 1491;
    component.showDriverDetailsByDriverId(driverId, region);
    expect(component.selectedDriver).toEqual({ driverId: driverId, index: 0 });
  });
  afterAll(() => {
    fixture.destroy();
    component = null;
  });
});
