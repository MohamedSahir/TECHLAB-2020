import {
    AfterViewInit,
    ChangeDetectorRef,
    Component,
    OnDestroy,
    OnInit,
    ViewChild
  } from '@angular/core';
  import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
  import { MatDialog, MatDialogRef } from '@angular/material/dialog';
  import { ActivatedRoute, Router } from '@angular/router';
  import { TranslateService } from '@ngx-translate/core';
  import { NotProdGuard } from '@transom/guards';
  import { AuthZService } from '@transom/services';
  import {
    CascadingSearchComponent,
    Columns,
    GridComponent,
    GridProperties,
    MultiInputComponent,
    SearchPanelComponent,
    ToastrService
  } from '@transom/ui';
  import { Observable, of, Subscription } from 'rxjs';
  import { map } from 'rxjs/operators';
  import { LoadingDialogService } from './../../common/loading-dialog/loading-dialog.service';
  import { ActivateDedicatedDriversComponent } from './../activate-dedicated-drivers/activate-dedicated-drivers.component';
  
  import { NotCertGuard } from '../../common/guards';
  import {
    activateDedicatedDriverCapability,
    assignmentDriverViewCapability,
    driverCalendarAdminCapability,
    driverCalendarViewCapability,
    driverCalendarWriteCapability,
    driverProfileAdminCapability,
    driverProfileBenefitsEditCapability,
    driverProfileBenefitsViewCapability,
    driverProfileDetailsEditCapability,
    driverProfileQueryConstants,
    driverProfileViewCapability,
    driverQueryCompany,
    driverSafetyReadCapability,
    driverSafetyWriteCapability,
    driverTypeConstants,
    weekdays
  } from '../../constants/driver-management-constant';
  import { DriverManagementService, DriverQueryStaticService } from '../common-services';
  import { DriverQueryRequestMapper } from '../common-services/driver-query-request-mapper';
  import {
    DepartDay,
    DriverProfileQueryCriteria,
    DriverProfileQueryResponse,
    DriverProfileQuerySelectedDriver,
    KeyValueModel
  } from '../model';
  import { driverConstants } from './../../common/driver-constants';
  import { DriverQueryColumnsService, DriverQueryProfileService } from './services';
  
  @Component({
    selector: 'driver-query-profile',
    templateUrl: './driver-query.component.html',
    styleUrls: ['./driver-query.component.scss'],
    providers: [DriverQueryColumnsService]
  })
  export class DriverQueryComponent implements OnInit, AfterViewInit, OnDestroy {
    constructor(
      private toastrService: ToastrService,
      private authZService: AuthZService,
      public changeRef: ChangeDetectorRef,
      private driverManagementService: DriverManagementService,
      private driverQueryColumnsService: DriverQueryColumnsService,
      private driverQueryStaticService: DriverQueryStaticService,
      private formBuilder: FormBuilder,
      private driverQueryProfileService: DriverQueryProfileService,
      public translateService: TranslateService,
      private notProdGuard: NotProdGuard,
      private notCertGuard: NotCertGuard,
      public dialog: MatDialog,
      private loadingDialogService: LoadingDialogService,
      private route: ActivatedRoute,
      private router: Router
    ) {}
    @ViewChild('searchPanel')
    searchWindow: SearchPanelComponent;
    @ViewChild('driverIds')
    driverIdMultiInput: MultiInputComponent;
    @ViewChild('driverProfileQueryGrid')
    driverProfileQueryGrid: GridComponent;
    @ViewChild('cascadeSearchPanel')
    cascadePanel: CascadingSearchComponent;
  
    driverId = new FormControl();
    departDay: DepartDay[];
    departTime: string[];
    driverQueryForm: FormGroup;
    gridColumn: Columns[];
    gridproperties: GridProperties;
    companyOptions: KeyValueModel[];
    driverStatusOptions: KeyValueModel[];
    businessLocation: KeyValueModel[];
    driverTypeOptions$: Observable<KeyValueModel[]>;
    domicileOptions$: Observable<KeyValueModel[]>;
    setCoodinatorOptions$: Observable<KeyValueModel[]>;
    scheduleTypeOptions$: Observable<KeyValueModel[]>;
    driverStatusSelection$: Observable<KeyValueModel[]>;
    rows: DriverProfileQueryResponse[];
    selectedRows: DriverProfileQueryResponse[];
    domicileSelectedItem: number;
    showEmptyMessage: boolean;
    selectedDriver: DriverProfileQuerySelectedDriver;
    resetSelectedDriver: DriverProfileQuerySelectedDriver;
    dialogRef: MatDialogRef<ActivateDedicatedDriversComponent>;
    private driverCompanyCodeChange: Subscription;
    private driverDomicileSelection: Subscription;
    hasDriverSelected: boolean;
    displayProperty = (option: KeyValueModel) => option.name;
  
    ngOnInit() {
      this.initialize();
    }
    ngAfterViewInit() {
      this.driverIdMultiInput['userInput'].nativeElement.maxLength =
        driverProfileQueryConstants.driverIdMaxLength;
      this.changeRef.detectChanges();
    }
    ngOnDestroy() {
      this.driverCompanyCodeChange.unsubscribe();
      this.driverDomicileSelection.unsubscribe();
    }
    isActivatedDedicatedVisible(): Boolean {
      if (
        this.driverProfileQueryGrid !== undefined &&
        this.driverProfileQueryGrid.selected &&
        this.driverProfileQueryGrid.selected.length > 0 &&
        this.isActivatedDriverCapability()
      ) {
        const isStatus = this.driverProfileQueryGrid.selected.filter(
          selecteditem =>
            (selecteditem.serviceCoCode &&
              selecteditem.serviceCoCode.trim() !== driverProfileQueryConstants.serviceCoCode &&
              (selecteditem.driverStatus &&
                selecteditem.driverStatus.trim() === driverProfileQueryConstants.inActive &&
                selecteditem.firstName &&
                selecteditem.firstName.trim() === '' &&
                selecteditem.lastName &&
                selecteditem.lastName.trim() === '')) ||
            (selecteditem.driverStatus &&
              selecteditem.driverStatus.trim() === driverProfileQueryConstants.payPending)
        ).length;
        return this.driverProfileQueryGrid.selected.length === isStatus;
      } else return false;
    }
    isDisabledDomicile(): Boolean {
      return this.isValidDriverId();
    }
    isDisableOtherCtrlExceptDomicile(): Boolean {
      if (this.isValidDriverId()) return true;
      else if (this.isValidDomicileId()) return false;
      else return true;
    }
    isDriverTractorVisible(): Boolean {
      let isTractorVisible = false;
      this.hasCapabilityOf([assignmentDriverViewCapability]).subscribe((hasCapability: boolean) => {
        isTractorVisible = hasCapability && this.rows.length > 0;
      });
      return isTractorVisible;
    }
    isDriverCalanderVisible(): Boolean {
      let isCalendarVisible = false;
      this.hasCapabilityOf([
        driverCalendarViewCapability,
        driverCalendarWriteCapability,
        driverCalendarAdminCapability
      ]).subscribe((hasCapability: boolean) => {
        isCalendarVisible =
          hasCapability &&
          this.driverProfileQueryGrid &&
          this.driverProfileQueryGrid.selected.length <= 1;
      });
      return isCalendarVisible;
    }
    isSearchDisable(): Boolean {
      if (this.isValidDriverId() && this.driverId.valid) return false;
      else if (this.isValidDomicileId() && this.driverId.valid) return false;
      else return true;
    }
    resetDriverQueryFormToDefault(): void {
      this.driverId.reset();
      this.driverQueryForm.reset();
      this.showEmptyMessage = false;
      this.rows = [];
      this.domicileSelectedItem = null;
      this.cascadePanel.showBaseView();
      this.driverQueryForm.patchValue({
        company: [this.companyOptions[0]],
        driverStatus: [this.driverStatusOptions !== undefined ? this.driverStatusOptions[0] : null]
      });
      this.selectedDriver = null;
    }
    resetSelectedDriverId(resetSelectedDriver: DriverProfileQuerySelectedDriver) {
      this.resetSelectedDriver = resetSelectedDriver;
    }
    highLightSelectedDriver(driverId) {
      if (this.resetSelectedDriver) return driverId === this.resetSelectedDriver.driverId;
      else if (this.selectedDriver) return driverId === this.selectedDriver.driverId;
      else return false;
    }
    searchDriverProfileQuery(): void {
      this.rows = [];
      this.selectedRows = [];
      this.cascadePanel.showBaseView();
      this.showEmptyMessage = false;
      this.fetchDriverQueryPreview(true);
      this.selectedDriver = null;
    }
    showDriverProfileDetails(selectedRow: DriverProfileQueryResponse): void {
      if (
        this.isNotCert() &&
        this.isNotProd() &&
        this.driverManagementService.hasAnyOneCapabilityOf([
          driverProfileBenefitsViewCapability,
          driverProfileViewCapability,
          driverSafetyReadCapability,
          driverSafetyWriteCapability,
          driverProfileBenefitsEditCapability,
          driverProfileAdminCapability,
          driverProfileDetailsEditCapability
        ])
      ) {
        this.hasDriverSelected = false;
        const selectedDriverIndex = this.rows.indexOf(selectedRow, 0);
        if (selectedDriverIndex > -1) this.rows.splice(selectedDriverIndex, 1);
        this.rows.unshift(selectedRow);
        this.rows.map(selectedDriver => {
          selectedDriver.driverId === selectedRow.driverId &&
          selectedDriver.region === selectedRow.region
            ? (selectedDriver.listSelect = true)
            : (selectedDriver.listSelect = false);
        });
        this.selectedDriver = { driverId: selectedRow.driverId, index: 0 };
        this.cascadePanel.showDetailsView();
      }
    }
  
    openActivateDedicatedDriverDialog(): void {
      this.loadingDialogService.openLoaderDialog(this.translateService.instant('Processing'));
      this.dialogRef = this.dialog.open(ActivateDedicatedDriversComponent, {
        data: this.driverProfileQueryGrid.selected,
        disableClose: true,
        panelClass: 'transom-flush-dialog'
      });
      this.dialogRef.afterClosed().subscribe((result: boolean) => {
        if (result) this.fetchDriverQueryPreview(false);
      });
    }
    driverQuerySingleClick(): DriverProfileQueryResponse[] {
      return this.driverProfileQueryGrid.selected;
    }
    openDriverCalendar(): void {
      const selectedDriver = this.driverQuerySingleClick();
      selectedDriver.map(selectedDriverId => {
        this.router.navigate(['../Driver_Calendar'], {
          relativeTo: this.route,
          queryParams: { selectedDriverId: selectedDriverId.driverId }
        });
      });
    }
  
    private isActivatedDriverCapability(): Boolean {
      let isActivatedDedicated = false;
      this.hasCapabilityOf([activateDedicatedDriverCapability]).subscribe(
        (hasCapability: boolean) => {
          isActivatedDedicated = hasCapability;
        }
      );
      return isActivatedDedicated;
    }
    private fetchStaticData(): void {
      this.setDomicileOptions();
      this.setCoodinatorOptions$ = this.driverQueryStaticService.fetchCoordinatorBoard();
      this.scheduleTypeOptions$ = this.driverQueryStaticService.fetchScheduleType().pipe(
        map((response: KeyValueModel[]) => {
          return response.sort(this.orderScheduleType);
        })
      );
      this.setDriverStatus();
      this.setDriverType();
    }
    private orderScheduleType(prevScheduleTypeName, nextScheduleTypeName): number {
      const scheduleTypePrevName =
        prevScheduleTypeName.name !== undefined ? prevScheduleTypeName.name.toUpperCase() : '';
      const scheduleTypeNextName =
        nextScheduleTypeName.name !== undefined ? nextScheduleTypeName.name.toUpperCase() : '';
      let compare = 0;
      if (scheduleTypePrevName > scheduleTypeNextName) compare = 1;
      else if (scheduleTypePrevName < scheduleTypeNextName) compare = -1;
      return compare;
    }
    private isValidDriverId(): Boolean {
      return this.driverId.value != null && this.driverId.value.length > 0 && this.driverId.valid;
    }
    private isValidDomicileId(): Boolean {
      return (
        this.driverQueryForm.get('domicile').value != null &&
        this.driverQueryForm.get('domicile').value.length > 0 &&
        this.driverQueryForm.controls.domicile.valid
      );
    }
    private initialize(): void {
      this.initializeValue();
      this.initializeGrid();
      this.fetchStaticData();
      this.initializeForm();
      this.driverCompanyCodeChange = this.driverQueryForm.controls['company'].valueChanges.subscribe(
        companyValue => {
          this.driverStatusSelection$ = of(this.getCompanySelection(companyValue));
        }
      );
      this.driverDomicileSelection = this.driverQueryForm.controls['domicile'].valueChanges.subscribe(
        domicile => this.getDomicileSelection(domicile)
      );
      this.driverId.valueChanges.subscribe(driverId => this.validateDriverId(driverId));
    }
    private initializeValue(): void {
      this.rows = [];
      this.selectedRows = [];
      this.companyOptions = driverQueryCompany;
      this.departDay = [...weekdays];
      this.departTime = this.driverManagementService.getDepartTime();
    }
    private initializeForm(): void {
      this.driverQueryForm = this.formBuilder.group({
        domicile: [],
        coordinatorBoard: [],
        company: [[this.companyOptions[0]]],
        driverStatus: [],
        scheduleTypes: [],
        driverTypes: [],
        departDay: [],
        departTime: []
      });
    }
    private initializeGrid(): void {
      this.gridColumn = this.driverQueryColumnsService.getColumnName();
      this.gridproperties = { currentPageSize: 10, gridMaxHeight: 500 };
    }
  
    private getCompanySelection(companyValue: KeyValueModel[]): KeyValueModel[] {
      if (companyValue != null) {
        const isWalmart = companyValue.findIndex(
          (companyItems: KeyValueModel) => companyItems.name === driverProfileQueryConstants.walmart
        );
        if (isWalmart !== -1 && companyValue.length === 1)
          return this.driverStatusOptions != null
            ? this.driverStatusOptions
                .slice()
                .filter(
                  company =>
                    company.name && company.name.trim() !== driverProfileQueryConstants.payPending
                )
            : [];
      }
      return this.driverStatusOptions;
    }
    private getDomicileSelection(domicile: KeyValueModel[]): void {
      if (domicile != null && domicile.length > driverProfileQueryConstants.domicileMaxLimit) {
        this.domicileSelectedItem = domicile.length;
        this.driverQueryForm.controls.domicile.setErrors({ setDomicileError: true });
      }
    }
    private fetchDriverQueryPreview(isToggled: Boolean): void {
      if (this.driverId.value != null)
        this.getDriverQueryResponse({ driverIds: this.driverId.value }, isToggled);
      else {
        const driverQueryRequestMapper = new DriverQueryRequestMapper();
        const requestCriteria = driverQueryRequestMapper.validateDriverQueryCriteria(
          this.driverQueryForm.getRawValue()
        );
        this.getDriverQueryResponse(requestCriteria, isToggled);
      }
    }
    private getDriverQueryResponse(
      requestCriteria: DriverProfileQueryCriteria,
      isToggled: Boolean
    ): void {
      let successResponse;
      this.driverQueryProfileService.fetchDriverQueryDetails(requestCriteria).subscribe(response => {
        successResponse = response;
        this.getDriverProfileQuerySuccess(successResponse, isToggled);
      });
    }
    private getDriverProfileQuerySuccess(response: DriverProfileQueryResponse[], isToggled: Boolean) {
      this.showEmptyMessage = true;
      if (response && response.length > 0) {
        if (isToggled) this.searchWindow.sidenav.toggle();
        this.rows = response.map((driverItem: DriverProfileQueryResponse) => {
          driverItem.departDay =
            driverItem.departDayCode != null
              ? weekdays.find(item => item.key === driverItem.departDayCode).value
              : '';
          driverItem.smokerIndicator =
            driverItem.smokerIndicator &&
            driverProfileQueryConstants.yes === driverItem.smokerIndicator
              ? driverProfileQueryConstants.yesDesc
              : driverProfileQueryConstants.noDesc;
          driverItem.serviceCoCode = this.getCompanyName(driverItem);
          driverItem.driverTypeCode = this.getDriverType(driverItem);
          return driverItem;
        });
        this.driverProfileQueryGridMaxLimit(this.rows);
      }
    }
    private getDriverType(driverItem: DriverProfileQueryResponse): string {
      return (driverItem.driverTypeCode =
        driverItem.driverTypeCode != null &&
        driverTypeConstants.find(driverTypeName => driverTypeName.id === driverItem.driverTypeCode)
          ? driverTypeConstants.find(
              driverTypeName => driverTypeName.id === driverItem.driverTypeCode
            ).name
          : '');
    }
    private getCompanyName(driverItem: DriverProfileQueryResponse): string {
      return driverItem.serviceCoCode != null &&
        driverQueryCompany.find(company => company.id === driverItem.serviceCoCode)
        ? driverQueryCompany.find(company => company.id === driverItem.serviceCoCode).name
        : driverProfileQueryConstants.dedicated;
    }
    private driverProfileQueryGridMaxLimit(
      driverProfileQueryRows: DriverProfileQueryResponse[]
    ): void {
      if (
        driverProfileQueryRows &&
        driverProfileQueryRows.length >= driverProfileQueryConstants.driverQueryGridMaxLimit
      )
        this.toastrService.warning(this.translateService.instant('Message_Narrow_Search_Criteria'));
      this.rows.splice(
        driverProfileQueryConstants.driverQueryGridMaxLimit,
        driverProfileQueryRows.length
      );
    }
    private hasCapabilityOf(capabilityName): Observable<Boolean> {
      return this.authZService.hasOneCapabilityOf(capabilityName);
    }
    private setDomicileOptions(): void {
      this.domicileOptions$ = this.driverQueryStaticService.fetchBusinessLocation().pipe(
        map((response: KeyValueModel[]) => {
          return response != null
            ? response.filter(
                domicile =>
                  domicile !== undefined &&
                  domicile !== null &&
                  domicile.id.trim() === driverProfileQueryConstants.locationTypeCode_DISP
              )
            : [];
        })
      );
    }
    private setDriverType(): void {
      this.driverTypeOptions$ = this.driverQueryStaticService.fetchDriverType().pipe(
        map((response: KeyValueModel[]) => {
          return response.filter(
            driverType =>
              driverType != null &&
              driverType.name &&
              !driverType.name
                .trim()
                .startsWith(driverProfileQueryConstants.driverTypeDescription_ORDS)
          );
        })
      );
    }
    private setDriverStatus(): void {
      this.driverStatusSelection$ = this.driverQueryStaticService.fetchDriverStatus().pipe(
        map((response: KeyValueModel[]) => {
          this.driverStatusOptions = response;
          return this.getCompanySelection([this.companyOptions[0]]);
        })
      );
    }
    private validateDriverId(driverId: string[]): void {
      if (this.isValidDriverId() && !driverId[0].match(driverConstants.regExpressions.numeric)) {
        driverId.splice(0, 1);
        this.driverId.setErrors({ validateDriverId: true });
      }
      if (
        this.driverId.value != null &&
        this.driverId.value.length > driverProfileQueryConstants.driverIdMaxLimit
      )
        this.driverId.setErrors({ validDriverIdLimit: true });
      if (this.driverQueryForm.controls.domicile.invalid)
        this.driverQueryForm.controls.domicile.setErrors(null);
    }
    showDriverDetailsByDriverId(driverId: number, region: number): void {
      this.hasDriverSelected = true;
      this.resetSelectedDriver = null;
      this.rows.map(selectedDriver => {
        selectedDriver.driverId === driverId && selectedDriver.region === region
          ? (selectedDriver.listSelect = true)
          : (selectedDriver.listSelect = false);
      });
      this.selectedDriver = { driverId: driverId, index: 0 };
    }
    //Temporarily implementing not prod guard until it reaches production
    private isNotProd(): boolean {
      let isNotProd = true;
      this.notProdGuard.notProd().subscribe(response => {
        isNotProd = response;
      });
      return isNotProd;
    }
    //Temporarily implementing cert guard until it reaches cert
    private isNotCert(): boolean {
      let isNotCert = true;
      this.notCertGuard.notCert().subscribe(response => {
        isNotCert = response;
      });
      return isNotCert;
    }
  }
  