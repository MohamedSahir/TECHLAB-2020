import { ViewEncapsulation } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import * as moment from 'moment-timezone';
import { of as ObservableOf } from 'rxjs';

import {
  DriverCalendarServiceMock,
  DriverManagementServiceMock,
  DriverQueryStaticServiceMock,
  FakeMatSideNavComponent,
  MockSearchPanelComponent,
  OfficeCalendarServiceMock,
  TranslateServiceMock,
  TransomCalendarMockComponent
} from '../../mock';
import { DriverManagementService, DriverQueryStaticService } from '../common-services';
import { DriverCalendarViewDetailsService } from '../driver-calendar-view/driver-calendar-view-details/services/driver-calendar-view-details.service';
import { DriverCalendarService } from '../driver-calendar-view/services';
import { OfficeCalendarComponent } from './office-calendar.component';
import { OfficeCalendarService } from './services';

declare var require: any;
const businessLocationMockData = require('../../mock/json-files/driver-query-profile.json');
const calendarEventMockData = require('../../mock/json-files/calendar-events.json');
const officeCalendarEventMockData = require('../../mock/json-files/office-calendar.json');
describe('OfficeCalendarComponent', () => {
  let component: OfficeCalendarComponent;
  let fixture: ComponentFixture<OfficeCalendarComponent>;
  let translateServiceMock: TranslateServiceMock;
  let driverQueryStaticServiceMock: DriverQueryStaticServiceMock;
  let officeCalendarServiceMock: OfficeCalendarServiceMock;
  let driverManagementServiceMock: DriverManagementServiceMock;
  let driverCalendarServiceMock: DriverCalendarServiceMock;
  beforeEach(async(() => {
    translateServiceMock = new TranslateServiceMock();
    driverQueryStaticServiceMock = new DriverQueryStaticServiceMock();
    officeCalendarServiceMock = new OfficeCalendarServiceMock();
    driverManagementServiceMock = new DriverManagementServiceMock();
    driverCalendarServiceMock = new DriverCalendarServiceMock();
    TestBed.configureTestingModule({
      declarations: [
        TransomCalendarMockComponent,
        OfficeCalendarComponent,
        MockSearchPanelComponent,
        FakeMatSideNavComponent
      ]
    })
      .overrideComponent(OfficeCalendarComponent, {
        set: {
          template: `<div><twist-search-panel #searchPanel><transom-calendar></transom-calendar>
          <fake-matside-nav #sidenav></fake-matside-nav></twist-search-panel>
          </div>`,
          encapsulation: ViewEncapsulation.Emulated,
          providers: [
            { provide: TranslateService, useValue: translateServiceMock },
            { provide: DriverQueryStaticService, useValue: driverQueryStaticServiceMock },
            { provide: OfficeCalendarService, useValue: officeCalendarServiceMock },
            { provide: DriverManagementService, useValue: driverManagementServiceMock },
            { provide: DriverCalendarService, useValue: driverCalendarServiceMock },
            DriverCalendarViewDetailsService
          ]
        }
      })
      .compileComponents();
  }));
  beforeEach(() => {
    fixture = TestBed.createComponent(OfficeCalendarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  afterAll(() => {
    component = null;
    fixture.destroy();
  });
  it('should create office calendar component', () => {
    expect(component).toBeTruthy();
  });
  describe('static data binding', () => {
    it('should get domicile types data', () => {
      let locationList = [];
      component.domicileOptions$.subscribe(response => {
        locationList = response;
      });
      expect(locationList).toEqual(businessLocationMockData.businessLocation);
    });
    it('should get empty errors if domicile types data is null', () => {
      spyOn(driverQueryStaticServiceMock, 'fetchBusinessLocation').and.returnValue(
        ObservableOf(null)
      );
      component.ngOnInit();
      expect(component.domicileId.errors).toEqual(null);
    });
    it('should get calendar event static data', () => {
      expect((component as any).officeCalendarEventTypes.length).toEqual(
        calendarEventMockData.length
      );
    });
  });
  it('should clear domicile data from text box', () => {
    component.resetToDefault();
    expect(component.domicileId.value).toEqual(null);
  });
  it('should get office calendar events data', () => {
    const event = {
      start: '2018-10-28T00:15:00',
      end: '2018-11-28T00:05:00',
      type: 'week'
    };
    const domicileFormControl: FormControl = component.domicileId;
    domicileFormControl.setValue(1234);
    component.locationId = 1234;
    spyOn(driverQueryStaticServiceMock, 'fetchCalendarEventTypes').and.returnValue(
      ObservableOf(calendarEventMockData)
    );
    spyOn(officeCalendarServiceMock, 'fetchOfficeCalendar').and.returnValue(
      ObservableOf(officeCalendarEventMockData)
    );
    component.calendarViewChange(event);
    expect(component.allCalendarEvents.length).toEqual(2);
  });

  it('should get office calendar events data', () => {
    const event = {
      start: '2018-10-28T00:15:00',
      end: '2018-11-28T00:05:00',
      type: 'week'
    };
    const domicileFormControl: FormControl = component.domicileId;
    domicileFormControl.setValue(1234);
    component.locationId = 1234;
    spyOn(driverQueryStaticServiceMock, 'fetchCalendarEventTypes').and.returnValue(
      ObservableOf(calendarEventMockData)
    );
    spyOn(officeCalendarServiceMock, 'fetchOfficeCalendar').and.returnValue(
      ObservableOf(officeCalendarEventMockData)
    );
    component.calendarViewChange(event);
    expect(component.allCalendarEvents.length).toEqual(2);
  });
  it('should get location id office calendar events data if user click next button', () => {
    const event = {
      start: '2018-10-28T00:15:00',
      end: '2018-11-28T00:05:00'
    };
    component.calendarViewChange(event);
    const domicileFormControl: FormControl = component.domicileId;
    domicileFormControl.setValue(1234);
    spyOn(driverQueryStaticServiceMock, 'fetchCalendarEventTypes').and.returnValue(
      ObservableOf(calendarEventMockData)
    );
    spyOn(officeCalendarServiceMock, 'fetchOfficeCalendar').and.returnValue(ObservableOf([]));
    spyOn(officeCalendarServiceMock, 'fetchCalendarRange');
    component.getOfficeCalendarData(true);
    expect(component.locationId).toEqual(1234);
  });
  it('should not get office calendar events data without domicileId', () => {
    const event = {
      start: '2018-10-28T00:15:00',
      end: '2018-11-28T00:05:00',
      type: 'week'
    };
    const domicileFormControl: FormControl = component.domicileId;
    domicileFormControl.setValue(null);
    spyOn(driverQueryStaticServiceMock, 'fetchCalendarEventTypes').and.returnValue(
      ObservableOf(calendarEventMockData)
    );
    component.calendarViewChange(event);
    expect(component.locationId).toEqual(undefined);
  });
  it('should get office calendar date if user click on a day', () => {
    component.locationId = 6801;
    component.allCalendarEvents = [
      {
        associatedDrivers: [1676, 656],
        end: '2018-10-27T01:00:00',
        eventTypeCode: 5,
        id: 1168042,
        isAllDay: false,
        start: '2018-10-27T00:00:00',
        title: 'DDC'
      },
      {
        associatedDrivers: [],
        end: '2018-11-05T03:30:00',
        eventTypeCode: 5,
        id: 1167972,
        isAllDay: false,
        start: '2018-11-05T02:00:00',
        title: 'DDC'
      },
      {
        associatedDrivers: [],
        end: '2018-11-05T13:00:00',
        eventTypeCode: 31,
        id: 1167971,
        isAllDay: true,
        start: '2018-11-05T02:15:00',
        title: 'OFFICEWORK'
      }
    ];
    spyOn(driverManagementServiceMock, 'hasCapabilityOf').and.returnValue(true);
    component.selectedCalendarDate(new Date());
    expect(component.selectedDate).toEqual(moment(new Date()).format('MM/DD/YYYY'));
  });
  it('should  disable add event button if  user has only view  capability', () => {
    component.locationId = 6801;
    component.allCalendarEvents = [
      {
        associatedDrivers: [1676, 656],
        end: '2018-10-27T01:00:00',
        eventTypeCode: 5,
        id: 1168042,
        isAllDay: false,
        start: '2018-10-27T00:00:00',
        title: 'DDC'
      },
      {
        associatedDrivers: [],
        end: '2018-11-05T03:30:00',
        eventTypeCode: 5,
        id: 1167972,
        isAllDay: false,
        start: '2018-11-05T02:00:00',
        title: 'DDC'
      },
      {
        associatedDrivers: [],
        end: '2018-11-05T13:00:00',
        eventTypeCode: 31,
        id: 1167971,
        isAllDay: true,
        start: '2018-11-05T02:15:00',
        title: 'OFFICEWORK'
      }
    ];
    spyOn(driverManagementServiceMock, 'hasCapabilityOf').and.returnValue(false);
    component.selectedCalendarDate(new Date());
    expect(component.isEnableAdd).toEqual(false);
  });
  it('should  get calendar event end time details if user click on day event', () => {
    const event = {
      allDay: false,
      start: '2018-11-06T00:15:00',
      end: '2018-11-06T01:30:00',
      associatedDrivers: [673, 1035],
      eventTypeCode: 5,
      id: 1168032,
      isAllDay: false,
      title: 'DDC'
    };
    component.allCalendarEvents = [
      {
        associatedDrivers: [1676, 656],
        end: '2018-10-27T01:00:00',
        eventTypeCode: 5,
        id: 1168042,
        isAllDay: false,
        start: '2018-11-06T00:15:00',
        title: 'DDC'
      },
      {
        associatedDrivers: [],
        end: '2018-11-05T03:30:00',
        eventTypeCode: 5,
        id: 1167972,
        isAllDay: false,
        start: '2018-11-05T02:00:00',
        title: 'DDC'
      },
      {
        associatedDrivers: [],
        end: '2018-11-05T13:00:00',
        eventTypeCode: 31,
        id: 1167971,
        isAllDay: true,
        start: '2018-11-05T02:15:00',
        title: 'OFFICEWORK'
      }
    ];
    component.selectedCalendarEvent(event);
    expect(component.selectedEvent.end).toEqual('2018-11-06T01:30:00');
  });
  it('should get null if user click on day event', () => {
    const event = null;
    component.selectedCalendarEvent(event);
    expect(component.selectedEvent).toEqual(null);
  });

  it('should get false if user click add event button', () => {
    component.addEvent();
    expect(component.isEnableAdd).toEqual(false);
  });
  it('should get locationId if user save the event successfully', () => {
    component.locationId = 1234;
    (component as any).officeEvent = {
      start: '2018-10-28T00:15:00',
      end: '2018-11-28T00:05:00'
    };
    component.officeCalendarDayEvent(true);
    expect(component.locationId).toEqual(1234);
  });
  it('should get undefined locationId if user save the event failed', () => {
    component.officeCalendarDayEvent(false);
    expect(component.locationId).toEqual(undefined);
  });
});
