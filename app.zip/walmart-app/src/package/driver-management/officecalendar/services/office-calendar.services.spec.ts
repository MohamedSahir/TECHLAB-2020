import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { async, getTestBed, TestBed } from '@angular/core/testing';
import { TranslateService } from '@ngx-translate/core';
import { EnvService } from '@transom/services';
import { ToastrService } from '@transom/ui';
import { of as observableOf } from 'rxjs';

import { LoadingDialogService } from '../../../common/loading-dialog/loading-dialog.service';
import { DRIVER_OFFICE_CALENDAR_URL, WALMART_CALENDAR_DATE_RANGE_URL } from '../../../common/urls';
import { driverProfileQueryConstants } from '../../../constants/driver-management-constant';
import {
  EnvServiceMock,
  LoadingDialogServiceMock,
  OfficeCalendarServiceMock,
  ToastrMessageServiceMock, TranslateServiceMock
} from '../../../mock';
import { OfficeCalendarService } from './office-calendar.service';

describe('OfficeCalendaService', () => {
  let mockBackend: HttpTestingController;
  let translateServiceMock: TranslateServiceMock;
  let loadingServiceMock: LoadingDialogServiceMock;
  let toastrServiceMock: ToastrMessageServiceMock;
  let envServiceMock: EnvServiceMock;
  let officeCalendarService: OfficeCalendarService;
  let officeCalendarServiceMock: OfficeCalendarServiceMock;
  beforeEach(async(() => {
    translateServiceMock = new TranslateServiceMock();
    loadingServiceMock = new LoadingDialogServiceMock();
    toastrServiceMock = new ToastrMessageServiceMock();
    officeCalendarServiceMock = new OfficeCalendarServiceMock();
    envServiceMock = new EnvServiceMock();
    TestBed.configureTestingModule({
      providers: [
        OfficeCalendarService,
        { provide: ToastrService, useValue: toastrServiceMock },
        { provide: TranslateService, useValue: translateServiceMock },
        { provide: LoadingDialogService, useValue: loadingServiceMock },
        { provide: EnvService, useValue: envServiceMock }
      ],
      imports: [HttpClientTestingModule]
    })
    mockBackend = getTestBed().get(HttpTestingController);
  }));
  it('should be created Office Calendar Service', () => {
    const service: OfficeCalendarService = TestBed.get(OfficeCalendarService);
    expect(service).toBeTruthy();
  });
  it('should  get office calendar events 200 status  response', async(() => {
    officeCalendarService = getTestBed().get(OfficeCalendarService);
    const url = envServiceMock.marketPrefix.toLowerCase() + DRIVER_OFFICE_CALENDAR_URL + "?fromdate=20180927T000000&todate=20181027T000000&locType=DISP&locId=6197";
    const offCalendarRequest = {
      fromdate: '20180927T000000',
      todate: '20181027T000000',
      locType: driverProfileQueryConstants.locationTypeCode_DISP,
      locId: 6197
    }
    officeCalendarService.fetchOfficeCalendar(offCalendarRequest).subscribe((successResult: any) => {
      expect(successResult.status).toEqual(200);
    });
    mockBackend
      .expectOne({
        url: url,
        method: 'GET'
      })
      .flush({ status: 200 });
  }));
  it('should show error message when office calendar events service call failed 500 status', async(() => {
    officeCalendarService = getTestBed().get(OfficeCalendarService);
    const url = envServiceMock.marketPrefix.toLowerCase() + DRIVER_OFFICE_CALENDAR_URL + "?fromdate=20180927T000000&todate=20181027T000000&locType=DISP&locId=6197";
    const offCalendarRequest = {
      fromdate: '20180927T000000',
      todate: '20181027T000000',
      locType: driverProfileQueryConstants.locationTypeCode_DISP,
      locId: 6197
    }
    const toastrSpy = spyOn(toastrServiceMock, 'error').and.callThrough();
    officeCalendarService.fetchOfficeCalendar(offCalendarRequest)
      .subscribe(
        () => fail('ObservableOf should not reach failure path'),
        () =>
          expect(toastrSpy).toHaveBeenCalledWith(translateServiceMock.instant('Service_Failure'))
      );
    mockBackend
      .expectOne({
        url: url,
        method: 'GET'
      })
      .flush({ message: 'Error' }, { status: 500, statusText: 'Service Unavailable' });
  }));
  it('should show info message no records found during the office calendar events service', async(() => {
    officeCalendarService = getTestBed().get(OfficeCalendarService);
    const url = envServiceMock.marketPrefix.toLowerCase() + DRIVER_OFFICE_CALENDAR_URL + "?fromdate=20180927T000000&todate=20181027T000000&locType=DISP&locId=6197";
    const offCalendarRequest = {
      fromdate: '20180927T000000',
      todate: '20181027T000000',
      locType: driverProfileQueryConstants.locationTypeCode_DISP,
      locId: 6197
    }
    spyOn(officeCalendarServiceMock, 'fetchOfficeCalendar').and.returnValue(observableOf([]));
    const toastrSpy = spyOn(toastrServiceMock, 'info').and.callThrough();
    officeCalendarService.fetchOfficeCalendar(offCalendarRequest).subscribe(() => {
      expect(toastrSpy).toHaveBeenCalledWith(
        translateServiceMock.instant('Message_No_Records_Found')
      );
    });
    mockBackend
      .expectOne({
        url: url,
        method: 'GET'
      })
      .flush('');
  }));

  it('should  get office calendar range 200 status  response', async(() => {
    officeCalendarService = getTestBed().get(OfficeCalendarService);
    const url = envServiceMock.marketPrefix.toLowerCase() + WALMART_CALENDAR_DATE_RANGE_URL;
    officeCalendarService.fetchCalendarRange().subscribe((successResult: any) => {
      expect(successResult.status).toEqual(200);
    });
    mockBackend
      .expectOne({
        url: url,
        method: 'GET'
      })
      .flush({ status: 200 });
  }));
  it('should show error message when office calendar range service call failed 500 status', async(() => {
    officeCalendarService = getTestBed().get(OfficeCalendarService);
    const url = envServiceMock.marketPrefix.toLowerCase() + WALMART_CALENDAR_DATE_RANGE_URL;
    const toastrSpy = spyOn(toastrServiceMock, 'error').and.callThrough();
    officeCalendarService.fetchCalendarRange()
      .subscribe(
        () => fail('ObservableOf should not reach failure path'),
        () =>
          expect(toastrSpy).toHaveBeenCalledWith(translateServiceMock.instant('Service_Failure'))
      );
    mockBackend
      .expectOne({
        url: url,
        method: 'GET'
      })
      .flush({ message: 'Error' }, { status: 500, statusText: 'Service Unavailable' });
  }));
  it('should show info message no records found during the office calendar range service', async(() => {
    officeCalendarService = getTestBed().get(OfficeCalendarService);
    const url = envServiceMock.marketPrefix.toLowerCase() + WALMART_CALENDAR_DATE_RANGE_URL;
    spyOn(officeCalendarServiceMock, 'fetchCalendarRange').and.returnValue(observableOf([]));
    const toastrSpy = spyOn(toastrServiceMock, 'info').and.callThrough();
    officeCalendarService.fetchCalendarRange().subscribe(() => {
      expect(toastrSpy).toHaveBeenCalledWith(
        translateServiceMock.instant('Message_No_Records_Found'));
    });
    mockBackend
      .expectOne({
        url: url,
        method: 'GET'
      })
      .flush('');
  }));
  afterEach(() => {
    mockBackend.verify();
  });
});