import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { EnvService } from '@transom/services';
import { ToastrService } from '@transom/ui';
import { Observable } from 'rxjs';
import { catchError, finalize, tap } from 'rxjs/operators';

import { LoadingDialogService } from '../../../common/loading-dialog/loading-dialog.service';
import { DRIVER_OFFICE_CALENDAR_URL, WALMART_CALENDAR_DATE_RANGE_URL } from '../../../common/urls';
import { CalendarDateRange, OfficeCalendar, OfficeCalendarRequest } from '../../model';

@Injectable()
export class OfficeCalendarService {
    constructor(
        private http: HttpClient,
        private envService: EnvService,
        private loadingDialogService: LoadingDialogService,
        private toastrService: ToastrService,
        private translateService: TranslateService
    ) { }
    fetchCalendarRange(): Observable<CalendarDateRange> {
        this.loadingDialogService.openLoaderDialog(this.translateService.instant('Processing'));
        const URL = this.envService.marketPrefix.toLowerCase() + WALMART_CALENDAR_DATE_RANGE_URL;
        return this.http.get<CalendarDateRange>(URL).pipe(
            tap(response => {
                if (!response)
                    this.toastrService.info(this.translateService.instant('Message_No_Records_Found'));
                else return response;
            }),
            catchError(error =>
                this.handleError(error, this.translateService.instant('ApplicationError'))
            )
        );
    }
    fetchOfficeCalendar(offCalendarRequest: OfficeCalendarRequest): Observable<OfficeCalendar> {
        this.loadingDialogService.openLoaderDialog(this.translateService.instant('Processing'), true);
        const URL = this.envService.marketPrefix.toLowerCase() + DRIVER_OFFICE_CALENDAR_URL;
        const params: HttpParams = this.getHttpParams(offCalendarRequest);
        return this.http.get<OfficeCalendar>(URL, { params }).pipe(
            tap(response => {
                if (!response)
                    this.toastrService.info(this.translateService.instant('Message_No_Records_Found'));
                else return response;
            }),
            catchError(error =>
                this.handleError(error, this.translateService.instant('ApplicationError'))
            ),
            finalize(() => this.loadingDialogService.closeLoader(true))
        );
    }
    private handleError(errorResponse: HttpErrorResponse, failureMessage: string): Observable<never> {
        this.toastrService.error(failureMessage);
        return new Observable<never>();
    }
    private getHttpParams(driverCalendarParam: OfficeCalendarRequest): HttpParams {
        let httpParams: HttpParams = new HttpParams();
        Object.keys(driverCalendarParam).forEach(param => {
            httpParams = httpParams.set(param, driverCalendarParam[param]);
        });
        return httpParams;
    }
}
