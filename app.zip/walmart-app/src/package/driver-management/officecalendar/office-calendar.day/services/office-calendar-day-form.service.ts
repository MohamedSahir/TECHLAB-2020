<router-outlet></router-outleimport { Injectable } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import * as moment from 'moment-timezone';

import { UserService } from '@transom/services';

import { officeDayViewConstant } from '../../../../constants/driver-management-constant';
import { DriverProfileDate, OfficeEventSave } from '../../../model';
import { OfficeCalendarDayValidator } from '../validator/office-calendar-day-validator';

@Injectable()
export class OfficeCalendarDayFormService {
  constructor(
    private formBuilder: FormBuilder,
    private translate: TranslateService,
    private userService: UserService
  ) {}
  private officeCalendarDayGridColumns: any[] = [
    {
      name: this.translate.instant('DriverId_Full'),
      prop: 'driverId'
    },
    {
      name: this.translate.instant('DriverName'),
      prop: 'driverName'
    },
    {
      name: this.translate.instant('DepartDayTime'),
      prop: 'deptDayTime'
    }
  ];

  initializeForm(): FormGroup {
    let officeCalendarDayForm: FormGroup;
    officeCalendarDayForm = this.formBuilder.group(
      {
        reason: [],
        beginDate: new FormControl({ value: '', disabled: true }),
        beginTime: [],
        endDate: new FormControl({ value: '', disabled: true }),
        endTime: []
      },
      {
        validator: [OfficeCalendarDayValidator.validateEndTime]
      }
    );
    return officeCalendarDayForm;
  }
  getColumnName(): any[] {
    return this.officeCalendarDayGridColumns;
  }
  createOfficeEventSaveData(
    officeCalendarDayForm: FormGroup,
    editEventId: number,
    selectedDriverList
  ): OfficeEventSave {
    let officeEventDetails: OfficeEventSave;
    officeEventDetails = {
      eventId: editEventId,
      eventTypeCode: officeCalendarDayForm.controls.reason.value,
      commentId: 0,
      beginTs: this.getTimeStampFormat(
        officeCalendarDayForm.controls.beginDate.value,
        officeCalendarDayForm.controls.beginTime.value
      ),
      endTs: this.getTimeStampFormat(
        officeCalendarDayForm.controls.endDate.value,
        officeCalendarDayForm.controls.endTime.value
      ),
      lastChangeUserId: this.userService.userId ? this.userService.userId.trim() : null,
      versionId: 0,
      owningLocation: {
        locationId: 6890,
        locationType: officeDayViewConstant.locationType
      },
      physicalLocation: null,
      fullDayEvent: false,
      associatedDrivers: selectedDriverList.map(mapObject => {
        return mapObject.driverId;
      })
    };
    return officeEventDetails;
  }
  private getTimeStampFormat(formDate, formTime): DriverProfileDate {
    const dateFormat = moment(formDate).format(officeDayViewConstant.dateRangeFormat);
    const timeFormat = moment(formTime, officeDayViewConstant.timeFormatA).format(
      officeDayViewConstant.timeFormat
    );
    const timeStamp = dateFormat + ' ' + timeFormat;
    return {
      timeStamp: timeStamp,
      timeZone: null
    };
  }
}