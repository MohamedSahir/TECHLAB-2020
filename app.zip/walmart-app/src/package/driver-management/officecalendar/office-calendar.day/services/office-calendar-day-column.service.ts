import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Injectable()
export class OfficeCalendarDayColumnsService {
  constructor(private translate: TranslateService) {}

  private officeCalendarDayGridColumns: any[] = [
    {
      name: this.translate.instant('DriverId_Full'),
      prop: 'driverId'
    },
    {
      name: this.translate.instant('DriverName'),
      prop: 'driverName'
    },
    {
      name: this.translate.instant('DepartDayTime'),
      prop: 'deptDayTime'
    }
  ];

  getColumnName() {
    return this.officeCalendarDayGridColumns;
  }
}