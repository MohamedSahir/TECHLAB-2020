import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { EnvService, UserService } from '@transom/services';
import { Observable } from 'rxjs';
import { catchError, finalize, tap } from 'rxjs/operators';

import { ToastrService } from '@transom/ui';

import { LoadingDialogService } from '../../../../common/loading-dialog/loading-dialog.service';
import {
  OFFICE_CALENDAR_DAY_DRIVER_LIST_URL,
  OFFICE_DAY_CALENDAR_EVENT_URL
} from '../../../../common/urls';
import { errors } from '../../../../constants/driver-management-constant';
import { DriverUtils } from '../../../../utils/driver-utils';
import { OfficeCalendarDayDriverPool, OfficeEventSave } from '../../../model';

@Injectable()
export class OfficeCalendarDayService {
  constructor(
    private userService: UserService,
    private http: HttpClient,
    private envService: EnvService,
    private loadingDialogService: LoadingDialogService,
    private toastrService: ToastrService,
    private translateService: TranslateService,
    private driverUtils: DriverUtils
  ) {}

  deleteOfficeEvent<T>(eventId: number, versionId: number): Observable<T> {
    const requestOptions = {
      headers: {
        ...this.driverUtils.getJsonHeaders(this.envService, this.userService),
        'If-Match': versionId.toString()
      }
    };
    return this.http
      .delete<T>(
        this.envService.marketPrefix + OFFICE_DAY_CALENDAR_EVENT_URL + eventId,
        requestOptions
      )
      .pipe(
        tap((response: T) => {
          this.toastrService.persistentSuccess(
            this.translateService.instant('Event_Delete_Success')
          );
          return true;
        }),
        catchError((error: HttpErrorResponse) => this.handleError(error)),
        finalize(() => this.loadingDialogService.closeLoader())
      );
  }
  fetchOfficeCalendarDayScheduledDrivers(
    requestParam: string
  ): Observable<OfficeCalendarDayDriverPool> {
    const url = this.envService.marketPrefix + OFFICE_CALENDAR_DAY_DRIVER_LIST_URL + requestParam;
    this.loadingDialogService.openLoaderDialog(this.translateService.instant('Processing'));
    return this.http.get<OfficeCalendarDayDriverPool>(url).pipe(
      tap((driverPoolResponse: OfficeCalendarDayDriverPool) => {
        if (!driverPoolResponse)
          this.toastrService.info(this.translateService.instant('Message_No_Records_Found'));
        return driverPoolResponse;
      }),
      catchError((error: HttpErrorResponse) => this.handleError(error)),
      finalize(() => this.loadingDialogService.closeLoader())
    );
  }
  createOfficeEvent<T>(eventDetails: OfficeEventSave): Observable<T> {
    const requestOptions = {
      headers: this.driverUtils.getJsonHeaders(this.envService, this.userService)
    };
    const url = this.envService.marketPrefix + OFFICE_DAY_CALENDAR_EVENT_URL;
    return this.http.post<T>(url, eventDetails, requestOptions).pipe(
      tap((response: T) => {
        this.toastrService.persistentSuccess(this.translateService.instant('Event_Save_Success'));
        return true;
      }),
      catchError((error: HttpErrorResponse) => this.handleError(error)),
      finalize(() => {
        this.loadingDialogService.closeLoader();
      })
    );
  }
  updateOfficeEvent(eventDetails: OfficeEventSave, eventId: number): Observable<OfficeEventSave> {
    const requestOptions = {
      headers: this.driverUtils.getJsonHeaders(this.envService, this.userService)
    };
    const url = this.envService.marketPrefix + OFFICE_DAY_CALENDAR_EVENT_URL + eventId;
    return this.http.put<OfficeEventSave>(url, eventDetails, requestOptions).pipe(
      tap(response => {
        if (response) {
          this.toastrService.persistentSuccess(
            this.translateService.instant('Event_Update_Success')
          );
          return response;
        }
      }),
      catchError((error: HttpErrorResponse) => this.handleError(error)),
      finalize(() => {
        this.loadingDialogService.closeLoader();
      })
    );
  }

  private handleError(error): Observable<never> {
    this.loadingDialogService.closeLoader();
    let errMsg;
    if (error instanceof HttpErrorResponse && error.status === errors.internalServer)
      this.toastrService.info(this.translateService.instant('Internal_Server_Error'));
    else {
      if (error instanceof HttpErrorResponse && error.status === errors.conflict)
        errMsg = error.statusText;
      else errMsg = this.translateService.instant('Server_Error');
      this.toastrService.error(errMsg);
    }
    return new Observable<never>();
  }
}