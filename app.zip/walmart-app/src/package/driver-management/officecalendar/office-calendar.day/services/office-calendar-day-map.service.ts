import { Injectable } from '@angular/core';

import { officeDayViewConstant, weekdays } from '../../../../constants/driver-management-constant';
import {
  CalendarEventTypes,
  OfficeCalendarDayDriver,
  OfficeCalendarDayOffList,
  OfficeCalendarDriverCount
} from '../../../model';

@Injectable()
export class OfficeCalendarDayMapService {
  mapScheduledDriverDetails(
    availableDriverDetails: OfficeCalendarDayDriver[],
    editDriverFlag?,
    editScheduledFlag?
  ): OfficeCalendarDayDriver[] {
    let scheduledDriver: OfficeCalendarDayDriver[] = [];
    availableDriverDetails.map(driverData => {
      scheduledDriver = [
        ...scheduledDriver,
        {
          driverName: driverData.firstName + ' ' + driverData.lastName,
          driverId: driverData.driverId,
          deptDayTime:
            weekdays.find(deptDay => deptDay.key === driverData.departDayCode).value +
            ' ' +
            driverData.departTime,
          eventTypeCode: driverData.eventTypeCode,
          editAssociatedDriver: editDriverFlag ? editDriverFlag : false,
          hideAssociatedDriver:
            driverData.eventTypeCode in officeDayViewConstant.offDriverEventTypeCodes
              ? true
              : false,
          eventScheduled: editScheduledFlag ? editScheduledFlag : false
        }
      ];
    });
    return scheduledDriver;
  }

  getOffDriverList(
    timeOffDrivers: OfficeCalendarDayDriver[],
    calendarEventTypes: CalendarEventTypes[]
  ): OfficeCalendarDayOffList {
    const groupedOffDriverList = this.groupOffDriverDetails(timeOffDrivers);
    let offDriverList: OfficeCalendarDayOffList;
    let filteredOffDriverList;
    let previewOffData: OfficeCalendarDayOffList[];
    previewOffData = new Array<OfficeCalendarDayOffList>();
    if (groupedOffDriverList)
      groupedOffDriverList.filter(driverData => {
        calendarEventTypes.map(eventData => {
          if (driverData.officeEvent === eventData.code) {
            offDriverList = new OfficeCalendarDayOffList(
              eventData.code,
              eventData.abbreviation,
              driverData.officeEventValue.length
            );
            previewOffData.push(offDriverList);
          }
        });
        filteredOffDriverList = previewOffData;
      });
    return filteredOffDriverList;
  }
  private groupOffDriverDetails(timeOffDriverData: OfficeCalendarDayDriver[]) {
    // return type is not able to mention need to discuss
    if (timeOffDriverData) {
      const groupedOffDriverObj = timeOffDriverData.reduce((prevDriverObj, curDriverObj) => {
        if (!prevDriverObj[curDriverObj[officeDayViewConstant.eventTypeCode]])
          prevDriverObj[curDriverObj[officeDayViewConstant.eventTypeCode]] = [curDriverObj];
        else prevDriverObj[curDriverObj[officeDayViewConstant.eventTypeCode]].push(curDriverObj);
        return prevDriverObj;
      }, {});
      return Object.keys(groupedOffDriverObj).map(officeEvent => ({
        officeEvent,
        officeEventValue: groupedOffDriverObj[officeEvent]
      }));
    }
    return null;
  }
  getOfficeCalendarDriverCount(availableDriverCount, offDriverCount): OfficeCalendarDriverCount {
    let driverCountDetails: OfficeCalendarDriverCount;
    driverCountDetails = {
      ...driverCountDetails,
      availableDriverCount: availableDriverCount,
      offDriverCount: offDriverCount,
      offDriverPercent: this.getPercentCount(offDriverCount, availableDriverCount)
    };
    return driverCountDetails;
  }

  private getPercentCount(offDriverCount: number, availableDriverCount: number): number {
    return +((offDriverCount / availableDriverCount) * officeDayViewConstant.digitHundred).toFixed(
      2
    );
  }
}