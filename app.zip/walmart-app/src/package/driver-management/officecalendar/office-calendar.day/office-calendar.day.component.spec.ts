import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { GridModule } from '@progress/kendo-angular-grid';

import { AppComponent } from './app.component';

@NgModule({
  imports: [ BrowserModule, BrowserAnimationsModule, GridModule ],
  declarations: [ AppComponent ],
  bootstrap: [ AppComponent ]
})

export class AppModule { }import { ViewEncapsulation } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { TranslateService } from '@ngx-translate/core';
import { UserService } from '@transom/services';
import { of as observableOf } from 'rxjs';

import { ToastrService } from '@transom/ui';

import {
  DataTableMockComponent,
  DriverManagementServiceMock,
  MatDialogConfirmationMock,
  OfficeCalendarDayMapServiceMock,
  OfficeCalendarDayServiceMock,
  ToastrMessageServiceMock,
  TranslateServiceMock,
  UserServiceMock
} from '../../../mock';
import { DriverManagementService } from '../../common-services';
import { OfficeCalendarDayComponent } from './office-calendar-day.component';
import {
  OfficeCalendarDayFormService,
  OfficeCalendarDayGridService,
  OfficeCalendarDayMapService,
  OfficeCalendarDayService
} from './services';
declare var require;
const officeDriverDetails = require('../../../mock/json-files/office-driver-details.json');

describe('OfficeCalendarDayComponent', () => {
  let component: OfficeCalendarDayComponent;
  let fixture: ComponentFixture<OfficeCalendarDayComponent>;
  let toastrServiceMock: ToastrMessageServiceMock;
  let translateServiceMock: TranslateServiceMock;
  let matDialogRefMock: MatDialogConfirmationMock;
  let officeCalendarDayServiceMock: OfficeCalendarDayServiceMock;
  let officeCalendarDayMapServiceMock: OfficeCalendarDayMapServiceMock;
  let driverManagementServiceMock: DriverManagementServiceMock;
  let userServiceMock: UserServiceMock;

  beforeEach(async(() => {
    officeCalendarDayMapServiceMock = new OfficeCalendarDayMapServiceMock();
    officeCalendarDayServiceMock = new OfficeCalendarDayServiceMock();
    toastrServiceMock = new ToastrMessageServiceMock();
    translateServiceMock = new TranslateServiceMock();
    matDialogRefMock = new MatDialogConfirmationMock();
    driverManagementServiceMock = new DriverManagementServiceMock();
    userServiceMock = new UserServiceMock();

    TestBed.configureTestingModule({
      declarations: [DataTableMockComponent, OfficeCalendarDayComponent],
      imports: []
    }).overrideComponent(OfficeCalendarDayComponent, {
      set: {
        template: '<div><transom-datatable></transom-datatable></div>',
        encapsulation: ViewEncapsulation.Emulated,
        providers: [
          FormBuilder,
          OfficeCalendarDayFormService,
          OfficeCalendarDayGridService,
          { provide: OfficeCalendarDayService, useValue: officeCalendarDayServiceMock },
          { provide: ToastrService, useValue: toastrServiceMock },
          { provide: TranslateService, useValue: translateServiceMock },
          { provide: MatDialog, useValue: matDialogRefMock },
          { provide: DriverManagementService, useValue: driverManagementServiceMock },
          { provide: OfficeCalendarDayMapService, useValue: officeCalendarDayMapServiceMock },
          { provide: UserService, useValue: userServiceMock }
        ]
      }
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OfficeCalendarDayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterAll(() => {
    component = null;
    fixture.destroy();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should initialize form controls oninit', () => {
    expect(component.officeCalendarDayForm.controls['beginDate'].value).toEqual(null);
  });
  it('should call fetchOfficeCalendarDayScheduledDrivers on fetchScheduledDriverDetails success', () => {
    const spyDriver = spyOn(
      officeCalendarDayServiceMock,
      'fetchOfficeCalendarDayScheduledDrivers'
    ).and.returnValue(observableOf(officeDriverDetails));
    component.ngOnInit();
    expect(spyDriver).toHaveBeenCalled();
  });
  it('should not set form control values if selectedEvent is empty', () => {
    component.selectedEvent = undefined;
    component.ngOnInit();
    expect(component.officeCalendarDayForm.get('beginDate').value).toEqual(null);
  });
  it('should set form control values if selectedEvent available', () => {
    (component as any).editEventData = {
      eventTypeCode: 31,
      start: '2018-12-12',
      end: '2018-12-12',
      associatedDrivers: []
    };
    (component as any).setOfficeEventDetails((component as any).editEventData);
    expect(component.officeCalendarDayForm.get('beginDate').value).toEqual('12/12/2018');
  });
  it('should get eventTypeList on setReasonCodeValue', () => {
    (component as any).officeCalendarDayEventTypes = [
      { abbreviation: 'DDC', code: '33', eventCategoryCode: 2 },
      { abbreviation: 'OFFICEWORK', code: '31', eventCategoryCode: 2 },
      { abbreviation: 'VACCATION', code: '1', eventCategoryCode: 3 }
    ];
    component.ngOnInit();
    expect(component.eventTypeList.length).toEqual(2);
  });
  it('should get beginDate when beginDate is empty on setCalendarDateValues', () => {
    (component as any).calendarDate = '12/08/2018';
    component.officeCalendarDayForm.get('beginDate').setValue('');
    (component as any).setCalendarDateValues();
    expect(component.officeCalendarDayForm.get('beginDate').value).toEqual('12/08/2018');
  });
  it('should get endDate when endDate is empty on setCalendarDateValues', () => {
    (component as any).calendarDate = '12/08/2018';
    component.officeCalendarDayForm.get('endDate').setValue('');
    (component as any).setCalendarDateValues();
    expect(component.officeCalendarDayForm.get('endDate').value).toEqual('12/08/2018');
  });
  it('should enable beginTime if reason code is selected', () => {
    (component as any).editEventData = {
      eventTypeCode: 31,
      start: '2018-12-12',
      end: '2018-12-12',
      associatedDrivers: []
    };
    component.officeCalendarDayForm.get('reason').setValue('DDC');
    (component as any).overlapMessageIds = [1234];
    (component as any).setReasonCodeValue();
    expect(component.officeCalendarDayForm.get('beginTime').enabled).toEqual(true);
  });
  it('should call mapScheduledDriverDetails if working drivers are available', () => {
    (component as any).overlapMessageIds = [78];
    (component as any).editEventData = {
      eventTypeCode: 31,
      start: '2018-12-12',
      end: '2018-12-12',
      associatedDrivers: []
    };
    spyOn(driverManagementServiceMock, 'hasCapabilityOf').and.returnValue(observableOf(true));
    const spyData = spyOn(
      officeCalendarDayMapServiceMock,
      'mapScheduledDriverDetails'
    ).and.returnValue(officeDriverDetails.scheduleDriver);
    (component as any).fetchScheduledDriverDetailsSuccess(officeDriverDetails);
    expect(spyData).toHaveBeenCalled();
  });
  it('should not call mapScheduledDriverDetails if working drivers are unavailable', () => {
    spyOn(driverManagementServiceMock, 'hasCapabilityOf').and.returnValue(observableOf(true));
    const spyData = spyOn(officeCalendarDayMapServiceMock, 'mapScheduledDriverDetails');
    (component as any).fetchScheduledDriverDetailsSuccess([]);
    expect(spyData).not.toHaveBeenCalled();
  });
  it('should call getOffDriverList if time off drivers and event types are available', () => {
    (component as any).officeCalendarDayEventTypes = [
      { abbreviation: 'DDC', code: '33', eventCategoryCode: 2 },
      { abbreviation: 'OFFICEWORK', code: '31', eventCategoryCode: 2 },
      { abbreviation: 'VACCATION', code: '1', eventCategoryCode: 3 }
    ];
    spyOn(driverManagementServiceMock, 'hasCapabilityOf').and.returnValue(observableOf(true));
    const spyData = spyOn(officeCalendarDayMapServiceMock, 'getOffDriverList').and.returnValue(
      officeDriverDetails.timeOffGroup
    );
    (component as any).fetchScheduledDriverDetailsSuccess(officeDriverDetails);
    expect(spyData).toHaveBeenCalled();
  });
  it('should not call getOffDriverList if time off drivers are not available', () => {
    spyOn(driverManagementServiceMock, 'hasCapabilityOf').and.returnValue(observableOf(true));
    const spyData = spyOn(officeCalendarDayMapServiceMock, 'getOffDriverList');
    (component as any).fetchScheduledDriverDetailsSuccess(officeDriverDetails.availableDrivers);
    expect(spyData).not.toHaveBeenCalled();
  });
  it('should disabled the form for normal user in previous pay period date', () => {
    component.isPreviousPayPeriod = true;
    spyOn(driverManagementServiceMock, 'hasCapabilityOf').and.returnValue(false);
    (component as any).checkUserAccess();
    expect(component.officeCalendarDayForm.disabled).toEqual(true);
  });
  it('should get admin access if user has admin capability', async(() => {
    spyOn(driverManagementServiceMock, 'hasCapabilityOf').and.returnValue(true);
    (component as any).hasUserAdminAccess();
    expect((component as any).hasUserAdminAccess()).toEqual(true);
  }));
  it('should show toaster message if overlapMessageIds are available on validateGridMapping', () => {
    (component as any).overlapMessageIds = [1234];
    component.officeCalendarDayForm.get('beginTime').setValue('1:15');
    component.officeCalendarDayForm.get('endTime').setValue('1:30');
    const spyMock = spyOn(toastrServiceMock, 'info');
    (component as any).validateGridMapping();
    expect(spyMock).toHaveBeenCalledWith('test1234');
  });
  it('should disable save button if form is not valid', () => {
    component.officeCalendarDayForm.get('beginTime').setValue('11:15 am');
    component.isPreviousPayPeriod = true;
    expect(component.disableSave()).toEqual(true);
  });

  it('should disable cancel button if form is touched', () => {
    expect(component.disableCancel()).toEqual(true);
  });
  it('should disable delete button if event is in previous payperiod', () => {
    component.isPreviousPayPeriod = true;
    expect(component.disableDelete()).toEqual(true);
  });
  it('should enable delete button if event is not in previous payperiod and in editMode', () => {
    component.isPreviousPayPeriod = false;
    (component as any).isEditMode = true;
    expect(component.disableDelete()).toEqual(false);
  });
  it('should call confirmEventDelete if editMode is true', () => {
    (component as any).editEventData = {
      eventTypeCode: 31,
      start: '2018-12-12',
      end: '2018-12-12',
      associatedDrivers: []
    };
    spyOn(matDialogRefMock, 'afterClosed').and.callThrough();
    const spyBox = spyOn(component as any, 'confirmEventDelete').and.callThrough();
    component.confirmEventDelete();
    expect(spyBox).toHaveBeenCalled();
  });
  it('should call deleteOfficeEvent when confirmation dialog get confirmed', () => {
    (component as any).editEventData = {
      eventTypeCode: 31,
      start: '2018-12-12',
      end: '2018-12-12',
      associatedDrivers: []
    };
    (component as any).dialogRef = new MatDialogConfirmationMock();
    spyOn((component as any).dialogRef, 'afterClosed').and.returnValue(observableOf(true));
    const deleteSpy = spyOn(officeCalendarDayServiceMock, 'deleteOfficeEvent').and.callThrough();
    component.confirmEventDelete();
    expect(deleteSpy).toHaveBeenCalled();
  });
  it('should call createOfficeEvent if user add an office event', () => {
    component.selected = [
      {
        driverName: 'GREG HAMBERG',
        driverId: 1073,
        deptDayTime: 'Monday 06:00',
        eventTypeCode: null,
        editAssociatedDriver: true,
        eventScheduled: false,
        hideAssociatedDriver: false
      }
    ];
    const spyData = spyOn(officeCalendarDayServiceMock, 'createOfficeEvent').and.returnValue(
      observableOf(true)
    );
    component.saveOfficeEvent();
    expect(spyData).toHaveBeenCalled();
  });
  it('should call updateOfficeEvent if user edit an office event', () => {
    component.selected = [
      {
        driverName: 'GREG HAMBERG',
        driverId: 1073,
        deptDayTime: 'Monday 06:00',
        eventTypeCode: null,
        editAssociatedDriver: true,
        eventScheduled: false,
        hideAssociatedDriver: false
      }
    ];
    (component as any).editEventData = {
      id: 12345,
      eventTypeCode: 31,
      start: '2018-12-12',
      end: '2018-12-12',
      associatedDrivers: []
    };
    const spyData = spyOn(officeCalendarDayServiceMock, 'updateOfficeEvent').and.returnValue(
      observableOf(true)
    );
    component.saveOfficeEvent();
    expect(spyData).toHaveBeenCalled();
  });
  it('should call checkReasonCodeChange on changes', () => {
    component.officeCalendarDayForm.get('reason').setValue('DDC');
    const spyGrid = spyOn(component as any, 'checkReasonCodeChange').and.callThrough();
    component.ngOnChanges();
    expect(spyGrid).toHaveBeenCalled();
  });
  it('should call checkBeginTimeChange on changes', () => {
    component.officeCalendarDayForm.get('reason').setValue('DDC');
    component.officeCalendarDayForm.get('beginTime').setValue('12:10 a');
    const spyGrid = spyOn(component as any, 'checkBeginTimeChange').and.callThrough();
    component.ngOnChanges();
    expect(spyGrid).toHaveBeenCalled();
  });
  it('should call checkEndTimeChange on changes', () => {
    component.officeCalendarDayForm.get('reason').setValue('DDC');
    component.officeCalendarDayForm.get('endTime').setValue('12:10 a');
    const spyGrid = spyOn(component as any, 'checkEndTimeChange').and.callThrough();
    component.ngOnChanges();
    expect(spyGrid).toHaveBeenCalled();
  });
});