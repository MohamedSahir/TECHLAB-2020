import {
    Component,
    EventEmitter,
    Input,
    OnChanges,
    OnDestroy,
    OnInit,
    Output
  } from '@angular/core';
  import { FormGroup } from '@angular/forms';
  import { MatDialog, MatDialogRef } from '@angular/material';
  import { TranslateService } from '@ngx-translate/core';
  import * as moment from 'moment-timezone';
  import { Subscription } from 'rxjs';
  
  import { ConfirmDialogComponent, ToastrService } from '@transom/ui';
  
  import {
    officeCalendarAdminCapability,
    officeCalendarWriteCapability,
    officeDayViewConstant
  } from '../../../constants/driver-management-constant';
  import { DriverManagementService } from '../../common-services';
  import {
    CalendarEvent,
    CalendarEventTypes,
    OfficeCalendarDayDriver,
    OfficeCalendarDayDriverPool,
    OfficeCalendarDayOffList,
    OfficeCalendarDriverCount,
    OfficeEventSave
  } from '../../model';
  import {
    OfficeCalendarDayFormService,
    OfficeCalendarDayGridService,
    OfficeCalendarDayMapService,
    OfficeCalendarDayService
  } from './services';
  
  @Component({
    selector: 'office-calendar-day',
    templateUrl: './office-calendar-day.component.html',
    styleUrls: ['./office-calendar-day.component.scss'],
    providers: [
      OfficeCalendarDayFormService,
      OfficeCalendarDayService,
      OfficeCalendarDayMapService,
      OfficeCalendarDayGridService
    ]
  })
  export class OfficeCalendarDayComponent implements OnChanges, OnInit, OnDestroy {
    selected = [];
    eventTypeList: CalendarEventTypes[];
    officeCalendarDayGridColumn: any[];
    officeCalendarDayForm: FormGroup;
    officeCalendarDayGridRows: OfficeCalendarDayDriver[];
    officeCalendarTime: string[];
    offDriverCount: number;
    availableDriverCount: number;
    filteredOffList: OfficeCalendarDayOffList;
    driverCountDetails: OfficeCalendarDriverCount;
  
    private isEditMode: boolean;
    private editEventData: CalendarEvent;
    private calendarDate: Date;
    private allDayOfficeEvents: CalendarEvent[];
    private officeCalendarDayEventTypes: CalendarEventTypes[];
    private workingDrivers: OfficeCalendarDayDriver[];
    private overlapMessageIds: number[];
    private dialogRef: MatDialogRef<ConfirmDialogComponent>;
    private changeInReasonCode: Subscription;
    private changeInEndTime: Subscription;
    private changeInBeginTime: Subscription;
    private locationId: number;
  
    @Output() dayViewCloseConfirm = new EventEmitter();
    @Input()
    set isEditable(value) {
      this.isEditMode = value;
    }
    get isEditable(): boolean {
      return this.isEditMode;
    }
    @Input()
    set selectedEvent(selectedEvent: CalendarEvent) {
      this.editEventData = selectedEvent;
    }
    get selectedEvent() {
      return this.editEventData;
    }
    @Input()
    set domicileId(domicileId: number) {
      this.locationId = domicileId;
    }
    get domicileId() {
      return this.locationId;
    }
    @Input()
    isPreviousPayPeriod = false;
    @Input()
    set officeCalendarEventTypes(value) {
      this.officeCalendarDayEventTypes = value;
      if (this.officeCalendarDayEventTypes) this.setReasonCodeValue();
    }
    get officeCalendarEventTypes(): CalendarEventTypes[] {
      return this.officeCalendarDayEventTypes;
    }
    @Input()
    set allDayEvents(value) {
      this.allDayOfficeEvents = value;
    }
    get allDayEvents(): CalendarEvent[] {
      return this.allDayOfficeEvents;
    }
    @Input()
    set selectedDate(value) {
      this.calendarDate = value;
      if (this.calendarDate)
        this.officeCalendarDayForm = this.officeCalendarDayFormService.initializeForm();
    }
    get selectedDate(): Date {
      return this.calendarDate;
    }
  
    constructor(
      private dialog: MatDialog,
      private officeCalendarDayFormService: OfficeCalendarDayFormService,
      private officeCalendarDayService: OfficeCalendarDayService,
      private driverManagementService: DriverManagementService,
      private officeCalendarDayMapService: OfficeCalendarDayMapService,
      private officeCalendarDayGridService: OfficeCalendarDayGridService,
      private toastrService: ToastrService,
      private translateService: TranslateService
    ) {
      this.driverCountDetails = new OfficeCalendarDriverCount();
    }
  
    ngOnInit() {
      this.officeCalendarDayForm = this.officeCalendarDayFormService.initializeForm();
      this.fetchScheduledDriverDetails();
      this.initializeStaticData();
      this.checkUserAccess();
      this.disableTimeControls(!this.isEditMode);
    }
    ngOnChanges() {
      if (this.officeCalendarDayForm) {
        this.checkReasonCodeChange();
        this.checkBeginTimeChange();
        this.checkEndTimeChange();
      }
      if (this.editEventData) {
        this.disableTimeControls(false);
        this.setOfficeEventDetails(this.editEventData);
      }
    }
    ngOnDestroy() {
      if (this.changeInReasonCode) this.changeInReasonCode.unsubscribe();
      if (this.changeInBeginTime) this.changeInBeginTime.unsubscribe();
      if (this.changeInEndTime) this.changeInEndTime.unsubscribe();
    }
    disableSave(): boolean {
      if (
        this.officeCalendarDayForm.touched &&
        !this.isPreviousPayPeriod &&
        this.officeCalendarDayForm.valid
      )
        return false;
      else return true;
    }
    disableCancel(): boolean {
      return this.officeCalendarDayForm.touched ? false : true;
    }
    disableDelete(): boolean {
      if (this.isEditMode && !this.isPreviousPayPeriod) return false;
      else return true;
    }
    saveOfficeEvent(): void {
      if (this.editEventData)
        this.officeCalendarDayService
          .updateOfficeEvent(this.getOfficeEventRequest(), this.editEventData.id)
          .subscribe(this.officeEventSaveSuccess);
      else
        this.officeCalendarDayService
          .createOfficeEvent(this.getOfficeEventRequest())
          .subscribe(this.officeEventSaveSuccess);
    }
    onSelect({ selected }) {
      this.selected.splice(0, this.selected.length);
      this.selected.push(...selected);
    }
    confirmEventDelete(): void {
      if (this.editEventData)
        this.dialogRef = this.dialog.open(ConfirmDialogComponent, {
          data: {
            confirmText: this.translateService.instant('Delete_Confirmation'),
            title: this.translateService.instant('Confirm_Cancel_Title')
          },
          disableClose: true
        });
      this.dialogAfterclose();
    }
    private checkBeginTimeChange(): void {
      this.changeInBeginTime = this.officeCalendarDayForm
        .get('beginTime')
        .valueChanges.subscribe(beginTime => {
          this.validateGridMapping();
        });
    }
    private checkEndTimeChange(): void {
      this.changeInEndTime = this.officeCalendarDayForm
        .get('endTime')
        .valueChanges.subscribe(endTime => {
          this.validateGridMapping();
        });
    }
    private checkUserAccess(): void {
      if (this.isPreviousPayPeriod && !this.hasUserAdminAccess())
        this.officeCalendarDayForm.disable();
    }
    private checkReasonCodeChange(): void {
      this.changeInReasonCode = this.officeCalendarDayForm
        .get('reason')
        .valueChanges.subscribe(calendarEventType => {
          if (calendarEventType && calendarEventType.trim()) {
            this.disableTimeControls(false);
            this.setCalendarDateValues();
            this.officeCalendarDayGridRows = this.officeCalendarDayGridService.validateAndDisableDrivers(
              this.officeCalendarDayGridRows,
              this.workingDrivers,
              this.hasUserAdminAccess(),
              this.hasUserWriteAccess(),
              this.officeCalendarDayForm,
              this.allDayOfficeEvents,
              this.editEventData
            );
          }
        });
    }
    private deleteOfficeEvent(): void {
      this.officeCalendarDayService.deleteOfficeEvent(this.editEventData.id, null).subscribe();
    }
    private dialogAfterclose(): void {
      this.dialogRef.afterClosed().subscribe(userResponse => {
        if (userResponse) this.deleteOfficeEvent();
      });
    }
    private disableTimeControls(actionDisable: boolean): void {
      if (actionDisable) {
        this.officeCalendarDayForm.get('beginTime').disable();
        this.officeCalendarDayForm.get('endTime').disable();
      } else {
        this.officeCalendarDayForm.get('beginTime').enable();
        this.officeCalendarDayForm.get('endTime').enable();
      }
    }
    private fetchScheduledDriverDetails(): void {
      const queryParam = '?locType=DISP&locId=6809&date=20190107T000000';
      this.officeCalendarDayService
        .fetchOfficeCalendarDayScheduledDrivers(queryParam)
        .subscribe((driverPoolResponse: OfficeCalendarDayDriverPool) =>
          this.fetchScheduledDriverDetailsSuccess(driverPoolResponse)
        );
    }
    private fetchScheduledDriverDetailsSuccess = (
      driverPoolResponse: OfficeCalendarDayDriverPool
    ): void => {
      if (driverPoolResponse) {
        this.workingDrivers = driverPoolResponse.availableDrivers;
        const timeOffDrivers = driverPoolResponse.timeOffDrivers;
        this.setDriverCountDetails(timeOffDrivers);
        if (this.workingDrivers)
          this.officeCalendarDayGridRows = this.officeCalendarDayMapService.mapScheduledDriverDetails(
            this.workingDrivers
          );
        if (timeOffDrivers && this.officeCalendarDayEventTypes)
          this.filteredOffList = this.officeCalendarDayMapService.getOffDriverList(
            timeOffDrivers,
            this.officeCalendarDayEventTypes
          );
        if (this.editEventData)
          this.officeCalendarDayGridRows = this.officeCalendarDayGridService.validateAndDisableDrivers(
            this.officeCalendarDayGridRows,
            this.workingDrivers,
            this.hasUserAdminAccess(),
            this.hasUserWriteAccess(),
            this.officeCalendarDayForm,
            this.allDayOfficeEvents,
            this.editEventData
          );
      }
    };
    private getOfficeEventRequest(): OfficeEventSave {
      let editEventId: number;
      if (this.editEventData) editEventId = this.editEventData.id;
      else editEventId = 0;
      const selectedDriverList = this.selected as OfficeCalendarDayDriver[];
      return this.officeCalendarDayFormService.createOfficeEventSaveData(
        this.officeCalendarDayForm,
        editEventId,
        selectedDriverList
      );
    }
    private hasUserAdminAccess(): boolean {
      return this.driverManagementService.hasCapabilityOf([officeCalendarAdminCapability]);
    }
    private hasUserWriteAccess(): boolean {
      return this.driverManagementService.hasCapabilityOf([officeCalendarWriteCapability]);
    }
    private initializeStaticData(): void {
      this.officeCalendarDayGridColumn = this.officeCalendarDayFormService.getColumnName();
      this.officeCalendarTime = this.driverManagementService.getCalendarTime();
      this.setReasonCodeValue();
    }
    private setDriverCountDetails(timeOffDrivers?: OfficeCalendarDayDriver[]): void {
      const availableDriversLength = this.workingDrivers ? this.workingDrivers.length : 0;
      const timeOffDriversLength = timeOffDrivers ? timeOffDrivers.length : 0;
      this.driverCountDetails = this.officeCalendarDayMapService.getOfficeCalendarDriverCount(
        availableDriversLength,
        timeOffDriversLength
      );
    }
    private officeEventSaveSuccess = (response): void => {
      this.dayViewCloseConfirm.emit({
        isResult: true
      });
    };
    private setOfficeEventDetails(officeEventData: CalendarEvent): void {
      const date = officeEventData.start;
      const calendarDate = moment(date).format(officeDayViewConstant.officeDateRangeFormat);
      this.officeCalendarDayForm.setValue({
        reason: officeEventData.eventTypeCode.toString(),
        beginDate: calendarDate,
        beginTime: moment(officeEventData.start).format(officeDayViewConstant.timeFormatA),
        endDate: calendarDate,
        endTime: moment(officeEventData.end).format(officeDayViewConstant.timeFormatA)
      });
    }
    private setReasonCodeValue(): void {
      if (this.officeCalendarDayEventTypes)
        this.eventTypeList = this.officeCalendarDayEventTypes.filter(
          reasonCode => reasonCode.eventCategoryCode === officeDayViewConstant.eventCategoryCodeTwo
        );
      this.setOfficeCalendarDayFormValues();
    }
    private setOfficeCalendarDayFormValues(): void {
      if (this.editEventData) {
        this.disableTimeControls(false);
        this.officeCalendarDayGridRows = this.officeCalendarDayGridService.validateAndDisableDrivers(
          this.officeCalendarDayGridRows,
          this.workingDrivers,
          this.hasUserAdminAccess(),
          this.hasUserWriteAccess(),
          this.officeCalendarDayForm,
          this.allDayOfficeEvents,
          this.editEventData
        );
      } else {
        this.disableTimeControls(true);
        this.officeCalendarDayForm.get('beginDate').setValue(null);
        this.officeCalendarDayForm.get('endDate').setValue(null);
        this.checkReasonCodeChange();
      }
    }
    private setCalendarDateValues(): void {
      if (this.officeCalendarDayForm.get('beginDate').value === '')
        this.officeCalendarDayForm.get('beginDate').setValue(this.calendarDate);
      if (this.officeCalendarDayForm.get('endDate').value === '')
        this.officeCalendarDayForm.get('endDate').setValue(this.calendarDate);
    }
    private validateGridMapping(): void {
      if (
        this.officeCalendarDayForm.get('beginTime').value &&
        this.officeCalendarDayForm.get('endTime').value
      )
        this.officeCalendarDayGridRows = this.officeCalendarDayGridService.validateAndDisableDrivers(
          this.officeCalendarDayGridRows,
          this.workingDrivers,
          this.hasUserAdminAccess(),
          this.hasUserWriteAccess(),
          this.officeCalendarDayForm,
          this.allDayOfficeEvents,
          this.editEventData
        );
      if (this.overlapMessageIds && this.overlapMessageIds.length > 0)
        this.toastrService.info(
          this.translateService.instant('Message_Removed_Drivers_Since_Conflicting_Office_Event') +
            this.overlapMessageIds
        );
    }
  }