import { AbstractControl } from '@angular/forms';

export class OfficeCalendarDayValidator {
  static validateEndTime(control: AbstractControl) {
    if (control.value.endTime && control.value.beginTime)
      if (control.value.endTime <= control.value.beginTime) return { endTimeCriteria: true };
  }
}