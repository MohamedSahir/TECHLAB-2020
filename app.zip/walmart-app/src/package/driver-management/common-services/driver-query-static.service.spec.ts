import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { async, getTestBed, TestBed } from '@angular/core/testing';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from '@transom/ui';

import {
  BASE_TERMINAL_SERVICE_URL,
  BULOCATION_SERVICE_URL,
  CALENDAR_EVENT_TYPES_URL,
  DRIVER_BENEFITS_STATUS_URL,
  DRIVER_CLASS_URL,
  DRIVER_COORDINATOR_BOARD_URL,
  DRIVER_DOMICILE_URL,
  DRIVER_DRIVER_STATUS_URL,
  DRIVER_LICENSE_TYPES_URL,
  DRIVER_SAFETY_TYPES_URL,
  DRIVER_SCHEDULE_TYPE_URL,
  DRIVER_STATE_URL,
  DRIVER_TYPE_SERVICE_URL
} from '../../common/urls';
import { ToastrMessageServiceMock, TranslateServiceMock } from '../../mock';
import { DriverQueryStaticService } from './driver-query-static.service';
declare var require: any;
const domicileMockData = require('../../mock/json-files/domicileCode.json');
const businessLocationMockData = require('../../mock/json-files/driver-query-profile.json');
const scheduleTypeMockData = require('../../mock/json-files/scheduleType.json');
const coordinatorBoardMockData = require('../../mock/json-files/coordinatorBoard.json');
const driverStatusMockData = require('../../mock/json-files/driverStatus.json');
const driverTypeMockData = require('../../mock/json-files/driverType.json');
const driverClassMockData = require('../../mock/json-files/driverClass.json');
const baseTerminalMockData = require('../../mock/json-files/baseTerminal.json');
const calendarEventMockData = require('../../mock/json-files/calendar-events.json');
const driverBenefitMockData = require('../../mock/json-files/driver-benefit-data.json');
const stateMockData = require('../../mock/json-files/states.json');
const licenseMockData = require('../../mock/json-files/licenseMockData.json');

describe('DriverQueryStaticService', () => {
  let mockBackend: HttpTestingController;
  let service: DriverQueryStaticService;
  let translateServiceMock: TranslateServiceMock;
  let toastrServiceMock: ToastrMessageServiceMock;

  beforeEach(async(() => {
    translateServiceMock = new TranslateServiceMock();
    toastrServiceMock = new ToastrMessageServiceMock();
    TestBed.configureTestingModule({
      providers: [
        DriverQueryStaticService,
        { provide: ToastrService, useValue: toastrServiceMock },
        { provide: TranslateService, useValue: translateServiceMock }
      ],
      imports: [HttpClientTestingModule]
    });
    mockBackend = getTestBed().get(HttpTestingController);
    service = getTestBed().get(DriverQueryStaticService);
  }));

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  describe('success response', () => {
    it('should fetch driver types static data for status 200', async(() => {
      service.fetchDriverType().subscribe(successResult => {
        expect(successResult).toBeDefined();
      });
      mockBackend
        .expectOne({
          method: 'GET',
          url: DRIVER_TYPE_SERVICE_URL
        })
        .flush([driverTypeMockData]);
    }));
    it('should fetch domicile types static data for status 200', async(() => {
      service.fetchDomicile().subscribe(successResult => {
        expect(successResult).toBeDefined();
      });
      mockBackend
        .expectOne({
          method: 'GET',
          url: DRIVER_DOMICILE_URL
        })
        .flush([domicileMockData]);
    }));
    it('should fetch benefit static data for status 200', async(() => {
      service.fetchDriverBenefitStatus().subscribe(successResult => {
        expect(successResult.length).toEqual(1);
      });
      mockBackend
        .expectOne({
          method: 'GET',
          url: DRIVER_BENEFITS_STATUS_URL
        })
        .flush([driverBenefitMockData]);
    }));
    it('should fetch driver coordinator board static data for status 200', async(() => {
      service.fetchCoordinatorBoard().subscribe(successResult => {
        expect(successResult).toBeDefined();
      });
      mockBackend
        .expectOne({
          method: 'GET',
          url: DRIVER_COORDINATOR_BOARD_URL
        })
        .flush([coordinatorBoardMockData]);
    }));
    it('should fetch driver status static data for status 200', async(() => {
      service.fetchDriverStatus().subscribe(successResult => {
        expect(successResult).toBeDefined();
      });
      mockBackend
        .expectOne({
          method: 'GET',
          url: DRIVER_DRIVER_STATUS_URL
        })
        .flush([driverStatusMockData]);
    }));
    it('should fetch business location static data for status 200', async(() => {
      service.fetchBusinessLocation().subscribe(successResult => {
        expect(successResult).toBeDefined();
      });
      mockBackend
        .expectOne({
          method: 'GET',
          url: BULOCATION_SERVICE_URL
        })
        .flush([businessLocationMockData.businessLocation]);
    }));

    it('should fetch scheduleType status static data for status 200', async(() => {
      service.fetchScheduleType().subscribe(successResult => {
        expect(successResult).toBeDefined();
      });
      mockBackend
        .expectOne({
          method: 'GET',
          url: DRIVER_SCHEDULE_TYPE_URL
        })
        .flush([scheduleTypeMockData]);
    }));
    it('should fetch driver class static data for status 200', async(() => {
      service.fetchDriverClass().subscribe(successResult => {
        expect(successResult.length).toEqual([driverClassMockData].length);
      });
      mockBackend
        .expectOne({
          method: 'GET',
          url: DRIVER_CLASS_URL
        })
        .flush([driverClassMockData]);
    }));
    it('should fetch base terminal static data for status 200', async(() => {
      service.fetchBaseTerminals().subscribe(successResult => {
        expect(successResult.length).toEqual([baseTerminalMockData].length);
      });
      mockBackend
        .expectOne({
          method: 'GET',
          url: BASE_TERMINAL_SERVICE_URL
        })
        .flush([baseTerminalMockData]);
    }));
    it('should fetch calendar event static data for status 200', async(() => {
      service.fetchCalendarEventTypes().subscribe(successResult => {
        expect(successResult.length).toEqual([calendarEventMockData].length);
      });
      mockBackend
        .expectOne({
          method: 'GET',
          url: CALENDAR_EVENT_TYPES_URL
        })
        .flush([calendarEventMockData]);
    }));
  });
  it('should fetch state static data for status 200', async(() => {
    service.fetchStates().subscribe(successResult => {
      expect(successResult.length).toEqual([stateMockData].length);
    });
    mockBackend
      .expectOne({
        method: 'GET',
        url: DRIVER_STATE_URL
      })
      .flush([stateMockData]);
  }));
  it('should fetch license type static data for status 200', async(() => {
    service.fetchLicenseTypes().subscribe(successResult => {
      expect(successResult.length).toEqual([licenseMockData].length);
    });
    mockBackend
      .expectOne({
        method: 'GET',
        url: DRIVER_LICENSE_TYPES_URL
      })
      .flush([licenseMockData]);
  }));
  describe('failure response', () => {
    it('should show custom error message if response status is 500 for business location static service', async(() => {
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const customErrorMessage = 'test';
      service
        .fetchBusinessLocation()
        .subscribe(
          () => fail('ObservableOf should not reach failure path'),
          () => expect(toastrServiceMock.error).toHaveBeenCalledWith(customErrorMessage)
        );
      mockBackend
        .expectOne({
          url: BULOCATION_SERVICE_URL,
          method: 'GET'
        })
        .flush({ message: 'Error' }, { status: 500, statusText: 'Server Error' });
    }));

    it('should show error message if response status is conflict for schedule type static service', async(() => {
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const messageConflict = 'Conflict has occured';
      service
        .fetchScheduleType()
        .subscribe(
          () => fail('ObservableOf should not reach failure path'),
          () => expect(toastrServiceMock.error).toHaveBeenCalledWith(messageConflict)
        );
      mockBackend
        .expectOne({
          url: DRIVER_SCHEDULE_TYPE_URL,
          method: 'GET'
        })
        .flush({ errorMessage: 'Conflict' }, { status: 409, statusText: messageConflict });
    }));

    it('should show error message if response status is conflict for driver status static service', async(() => {
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const messageConflict = 'Conflict has occured';
      service
        .fetchDriverStatus()
        .subscribe(
          () => fail('ObservableOf should not reach failure path'),
          () => expect(toastrServiceMock.error).toHaveBeenCalledWith(messageConflict)
        );
      mockBackend
        .expectOne({
          url: DRIVER_DRIVER_STATUS_URL,
          method: 'GET'
        })
        .flush({ errorMessage: 'Conflict' }, { status: 409, statusText: messageConflict });
    }));

    it('should show error message if response status is conflict for driver type service', async(() => {
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const messageConflict = 'Conflict has occured';
      service
        .fetchDriverStatus()
        .subscribe(
          () => fail('ObservableOf should not reach failure path'),
          () => expect(toastrServiceMock.error).toHaveBeenCalledWith(messageConflict)
        );
      mockBackend
        .expectOne({
          url: DRIVER_DRIVER_STATUS_URL,
          method: 'GET'
        })
        .flush({ errorMessage: 'Conflict' }, { status: 409, statusText: messageConflict });
    }));
    it('should show error message if response status is conflict for coordinator board static service', async(() => {
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const messageConflict = 'Conflict has occured';
      service
        .fetchCoordinatorBoard()
        .subscribe(
          () => fail('ObservableOf should not reach failure path'),
          () => expect(toastrServiceMock.error).toHaveBeenCalledWith(messageConflict)
        );
      mockBackend
        .expectOne({
          url: DRIVER_COORDINATOR_BOARD_URL,
          method: 'GET'
        })
        .flush({ errorMessage: 'Conflict' }, { status: 409, statusText: messageConflict });
    }));

    it('should show error message if response status is conflict for business location service', async(() => {
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const messageConflict = 'Conflict has occured';
      service
        .fetchBusinessLocation()
        .subscribe(
          () => fail('ObservableOf should not reach failure path'),
          () => expect(toastrServiceMock.error).toHaveBeenCalledWith(messageConflict)
        );
      mockBackend
        .expectOne({
          url: BULOCATION_SERVICE_URL,
          method: 'GET'
        })
        .flush({ errorMessage: 'Conflict' }, { status: 409, statusText: messageConflict });
    }));

    it('should show error message if response status is conflict for schedule type static service', async(() => {
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const messageConflict = 'Conflict has occured';
      service
        .fetchScheduleType()
        .subscribe(
          () => fail('ObservableOf should not reach failure path'),
          () => expect(toastrServiceMock.error).toHaveBeenCalledWith(messageConflict)
        );
      mockBackend
        .expectOne({
          url: DRIVER_SCHEDULE_TYPE_URL,
          method: 'GET'
        })
        .flush({ errorMessage: 'Conflict' }, { status: 409, statusText: messageConflict });
    }));

    it('should show error message if response status is conflict for driver status static service', async(() => {
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const messageConflict = 'Conflict has occured';
      service
        .fetchDriverStatus()
        .subscribe(
          () => fail('ObservableOf should not reach failure path'),
          () => expect(toastrServiceMock.error).toHaveBeenCalledWith(messageConflict)
        );
      mockBackend
        .expectOne({
          url: DRIVER_DRIVER_STATUS_URL,
          method: 'GET'
        })
        .flush({ errorMessage: 'Conflict' }, { status: 409, statusText: messageConflict });
    }));

    it('should show error message if response status is conflict for driver type service', async(() => {
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const messageConflict = 'Conflict has occured';
      service
        .fetchDriverStatus()
        .subscribe(
          () => fail('ObservableOf should not reach failure path'),
          () => expect(toastrServiceMock.error).toHaveBeenCalledWith(messageConflict)
        );
      mockBackend
        .expectOne({
          url: DRIVER_DRIVER_STATUS_URL,
          method: 'GET'
        })
        .flush({ errorMessage: 'Conflict' }, { status: 409, statusText: messageConflict });
    }));
    it('should show error message if response status is conflict for coordinator board static service', async(() => {
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const messageConflict = 'Conflict has occured';
      service
        .fetchCoordinatorBoard()
        .subscribe(
          () => fail('ObservableOf should not reach failure path'),
          () => expect(toastrServiceMock.error).toHaveBeenCalledWith(messageConflict)
        );
      mockBackend
        .expectOne({
          url: DRIVER_COORDINATOR_BOARD_URL,
          method: 'GET'
        })
        .flush({ errorMessage: 'Conflict' }, { status: 409, statusText: messageConflict });
    }));
    it('should show custom error message if response status is 500 for driver Class static service', async(() => {
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const customErrorMessage = 'test';
      service
        .fetchDriverClass()
        .subscribe(
          () => fail('ObservableOf should not reach failure path'),
          () => expect(toastrServiceMock.error).toHaveBeenCalledWith(customErrorMessage)
        );
      mockBackend
        .expectOne({
          url: DRIVER_CLASS_URL,
          method: 'GET'
        })
        .flush({ message: 'Error' }, { status: 500, statusText: 'Server Error' });
    }));
    it('should show error message if response status is conflict for driver class static service', async(() => {
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const messageConflict = 'Conflict has occured';
      service
        .fetchDriverClass()
        .subscribe(
          () => fail('ObservableOf should not reach failure path'),
          () => expect(toastrServiceMock.error).toHaveBeenCalledWith(messageConflict)
        );
      mockBackend
        .expectOne({
          url: DRIVER_CLASS_URL,
          method: 'GET'
        })
        .flush({ errorMessage: 'Conflict' }, { status: 409, statusText: messageConflict });
    }));
  });
  describe('driver safety log static data', () => {
    it('should fetch driver safety log types  static data for status 200', async(() => {
      service.fetchDriverSafetyTypes().subscribe(successResult => {
        expect(successResult[0].id).toEqual('1');
      });
      mockBackend
        .expectOne({
          method: 'GET'
        })
        .flush([driverTypeMockData.driverSafetyLogTypes]);
    }));
    it('should call driver safety log types data service static api data service failed 500 status', async(() => {
      const toastrSpy = spyOn(toastrServiceMock, 'error').and.callThrough();
      service
        .fetchDriverSafetyTypes()
        .subscribe(
          () => fail('ObservableOf should not reach failure path'),
          () =>
            expect(toastrSpy).toHaveBeenCalledWith(translateServiceMock.instant('Service_Failure'))
        );
      mockBackend
        .expectOne({
          url: DRIVER_SAFETY_TYPES_URL,
          method: 'GET'
        })
        .flush({ message: 'Error' }, { status: 500, statusText: 'Service Unavailable' });
    }));
    it('should show custom error message if response status is 500 for domicile static service', async(() => {
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const customErrorMessage = 'test';
      service
        .fetchDomicile()
        .subscribe(
          () => fail('ObservableOf should not reach failure path'),
          () => expect(toastrServiceMock.error).toHaveBeenCalledWith(customErrorMessage)
        );
      mockBackend
        .expectOne({
          url: DRIVER_DOMICILE_URL,
          method: 'GET'
        })
        .flush({ message: 'Error' }, { status: 500, statusText: 'Server Error' });
    }));
    it('should show custom error message if response status is 500 for benefit static service', async(() => {
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const customErrorMessage = 'test';
      service
        .fetchDriverBenefitStatus()
        .subscribe(
          () => fail('ObservableOf should not reach failure path'),
          () => expect(toastrServiceMock.error).toHaveBeenCalledWith(customErrorMessage)
        );
      mockBackend
        .expectOne({
          url: DRIVER_BENEFITS_STATUS_URL,
          method: 'GET'
        })
        .flush({ message: 'Error' }, { status: 500, statusText: 'Server Error' });
    }));
  });
  it('should show custom error message if response status is 500 for base terminal static service', async(() => {
    spyOn(toastrServiceMock, 'error').and.callThrough();
    const customErrorMessage = 'test';
    service
      .fetchBaseTerminals()
      .subscribe(
        () => fail('ObservableOf should not reach failure path'),
        () => expect(toastrServiceMock.error).toHaveBeenCalledWith(customErrorMessage)
      );
    mockBackend
      .expectOne({
        url: BASE_TERMINAL_SERVICE_URL,
        method: 'GET'
      })
      .flush({ message: 'Error' }, { status: 500, statusText: 'Server Error' });
  }));
  it('should show error message if response status is conflict for base terminal static service', async(() => {
    spyOn(toastrServiceMock, 'error').and.callThrough();
    const messageConflict = 'Conflict has occured';
    service
      .fetchBaseTerminals()
      .subscribe(
        () => fail('ObservableOf should not reach failure path'),
        () => expect(toastrServiceMock.error).toHaveBeenCalledWith(messageConflict)
      );
    mockBackend
      .expectOne({
        url: BASE_TERMINAL_SERVICE_URL,
        method: 'GET'
      })
      .flush({ errorMessage: 'Conflict' }, { status: 409, statusText: messageConflict });
  }));
  it('should show custom error message if response status is 500 for calendar event static service', async(() => {
    spyOn(toastrServiceMock, 'error').and.callThrough();
    const customErrorMessage = 'test';
    service
      .fetchCalendarEventTypes()
      .subscribe(
        () => fail('ObservableOf should not reach failure path'),
        () => expect(toastrServiceMock.error).toHaveBeenCalledWith(customErrorMessage)
      );
    mockBackend
      .expectOne({
        url: CALENDAR_EVENT_TYPES_URL,
        method: 'GET'
      })
      .flush({ message: 'Error' }, { status: 500, statusText: 'Server Error' });
  }));

  it('should show error message if response status is conflict for calendar event static service', async(() => {
    spyOn(toastrServiceMock, 'error').and.callThrough();
    const messageConflict = 'Conflict has occured';
    service
      .fetchCalendarEventTypes()
      .subscribe(
        () => fail('ObservableOf should not reach failure path'),
        () => expect(toastrServiceMock.error).toHaveBeenCalledWith(messageConflict)
      );
    mockBackend
      .expectOne({
        url: CALENDAR_EVENT_TYPES_URL,
        method: 'GET'
      })
      .flush({ errorMessage: 'Conflict' }, { status: 409, statusText: messageConflict });
  }));
  afterEach(() => {
    mockBackend.verify();
  });
  it('should show error message if response status is conflict for qualification states static service', async(() => {
    spyOn(toastrServiceMock, 'error').and.callThrough();
    const messageConflict = 'Conflict';
    service
      .fetchStates()
      .subscribe(
        () => fail('ObservableOf should not reach failure path'),
        () => expect(toastrServiceMock.error).toHaveBeenCalledWith(messageConflict)
      );
    mockBackend
      .expectOne({
        url: DRIVER_STATE_URL,
        method: 'GET'
      })
      .flush({ errorMessage: 'Conflict' }, { status: 409, statusText: messageConflict });
  }));
  it('should call state service static api data service failed 500 status', async(() => {
    const toastrSpy = spyOn(toastrServiceMock, 'error').and.callThrough();
    service
      .fetchStates()
      .subscribe(
        () => fail('ObservableOf should not reach failure path'),
        () =>
          expect(toastrSpy).toHaveBeenCalledWith(translateServiceMock.instant('Service_Failure'))
      );
    mockBackend
      .expectOne({
        url: DRIVER_STATE_URL,
        method: 'GET'
      })
      .flush({ message: 'Error' }, { status: 500, statusText: 'Service Unavailable' });
  }));
  it('should show error message if response status is conflict for license types static service', async(() => {
    spyOn(toastrServiceMock, 'error').and.callThrough();
    const messageConflict = 'Conflict has occured';
    service
      .fetchLicenseTypes()
      .subscribe(
        () => fail('ObservableOf should not reach failure path'),
        () => expect(toastrServiceMock.error).toHaveBeenCalledWith(messageConflict)
      );
    mockBackend
      .expectOne({
        url: DRIVER_LICENSE_TYPES_URL,
        method: 'GET'
      })
      .flush({ errorMessage: 'Conflict' }, { status: 409, statusText: messageConflict });
  }));
  it('should call license type service static api data service failed 500 status', async(() => {
    const toastrSpy = spyOn(toastrServiceMock, 'error').and.callThrough();
    service
      .fetchLicenseTypes()
      .subscribe(
        () => fail('ObservableOf should not reach failure path'),
        () => expect(toastrSpy).toHaveBeenCalledWith('Service_Failure')
      );
    mockBackend
      .expectOne({
        url: DRIVER_LICENSE_TYPES_URL,
        method: 'GET'
      })
      .flush({ message: 'Error' }, { status: 500, statusText: 'Service Unavailable' });
  }));
});