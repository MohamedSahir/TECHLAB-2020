import { async, getTestBed, TestBed } from '@angular/core/testing';
import { AuthZService } from '@transom/services';
import { of as observableOf } from 'rxjs';

import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from '@transom/ui';
import {
  driverProfileBenefitsEditCapability,
  driverProfileDetailsEditCapability
} from '../../constants/driver-management-constant';
import { AuthzServiceMock, ToastrMessageServiceMock, TranslateServiceMock } from '../../mock';
import { DriverManagementService } from './driver-management.service';
describe('DriverManagementService', () => {
  let authzServiceMock: AuthzServiceMock;
  let toastrServiceMock: ToastrMessageServiceMock;
  let translateServiceMock: TranslateServiceMock;
  beforeEach(async(() => {
    authzServiceMock = new AuthzServiceMock();
    translateServiceMock = new TranslateServiceMock();
    toastrServiceMock = new ToastrMessageServiceMock();
    TestBed.configureTestingModule({
      providers: [
        DriverManagementService,
        { provide: AuthZService, useValue: authzServiceMock },
        { provide: TranslateService, useValue: translateServiceMock },
        { provide: ToastrService, useValue: toastrServiceMock }
      ]
    });
  }));
  it('should get  starting department time', async(() => {
    const driverManagementService: DriverManagementService = getTestBed().get(
      DriverManagementService
    );
    expect(driverManagementService.getDepartTime()[0]).toEqual('00:00');
  }));
  it('should get last department time', async(() => {
    const driverManagementService: DriverManagementService = getTestBed().get(
      DriverManagementService
    );
    const timeList = driverManagementService.getDepartTime();
    expect(timeList[timeList.length - 1]).toEqual('23:30');
  }));
  it('should return true, if user has capability', async(() => {
    const driverManagementService: DriverManagementService = getTestBed().get(
      DriverManagementService
    );
    spyOn(authzServiceMock, 'hasAllCapabilitiesOf').and.returnValue(observableOf(true));
    const isCapability = driverManagementService.hasCapabilityOf([
      driverProfileBenefitsEditCapability,
      driverProfileDetailsEditCapability
    ]);
    expect(isCapability).toEqual(true);
  }));
  it('should return false, if user has no capability', async(() => {
    const driverManagementService: DriverManagementService = getTestBed().get(
      DriverManagementService
    );
    spyOn(authzServiceMock, 'hasAllCapabilitiesOf').and.returnValue(observableOf(false));
    const isCapability = driverManagementService.hasCapabilityOf([
      driverProfileBenefitsEditCapability,
      driverProfileDetailsEditCapability
    ]);
    expect(isCapability).toEqual(false);
  }));
  it('should return true, if user has atleast one capability', async(() => {
    const driverManagementService: DriverManagementService = getTestBed().get(
      DriverManagementService
    );
    spyOn(authzServiceMock, 'hasOneCapabilityOf').and.returnValue(observableOf(true));
    const isCapability = driverManagementService.hasAnyOneCapabilityOf([
      driverProfileBenefitsEditCapability,
      driverProfileDetailsEditCapability
    ]);
    expect(isCapability).toEqual(true);
  }));
  it('should return false, if user has not even one capability', async(() => {
    const driverManagementService: DriverManagementService = getTestBed().get(
      DriverManagementService
    );
    spyOn(authzServiceMock, 'hasOneCapabilityOf').and.returnValue(observableOf(false));
    const isCapability = driverManagementService.hasAnyOneCapabilityOf([
      driverProfileBenefitsEditCapability,
      driverProfileDetailsEditCapability
    ]);
    expect(isCapability).toEqual(false);
  }));
  it('should show error message, if internal server error occurs.', () => {
    const tostMsgSpy = spyOn(toastrServiceMock, 'error').and.callThrough();
    spyOn(translateServiceMock, 'instant').and.returnValue('Internal server error occurred.');
    const driverManagementService: DriverManagementService = getTestBed().get(
      DriverManagementService
    );
    driverManagementService.handleError({ status: 500 });
    expect(tostMsgSpy).toHaveBeenCalledWith(
      translateServiceMock.instant('Internal server error occurred.')
    );
  });
  it('should show error message, if server side conflict occurs.', () => {
    const tostMsgSpy = spyOn(toastrServiceMock, 'info').and.callThrough();
    spyOn(translateServiceMock, 'instant').and.returnValue('This failed due to server issue.');
    const driverManagementService: DriverManagementService = getTestBed().get(
      DriverManagementService
    );
    const errorConflict = {
      status: 409,
      error: {
        Errors: [
          {
            message: 'This failed due to server issue.',
            status: 'Conflict'
          }
        ]
      }
    };
    driverManagementService.handleError(errorConflict);
    expect(tostMsgSpy).toHaveBeenCalledWith(
      translateServiceMock.instant('This failed due to server issue.')
    );
  });
  it('should show information message, if no records found.', () => {
    const tostMsgSpy = spyOn(toastrServiceMock, 'info').and.callThrough();
    spyOn(translateServiceMock, 'instant').and.returnValue('No records found');
    const driverManagementService: DriverManagementService = getTestBed().get(
      DriverManagementService
    );
    driverManagementService.handleError({ status: 404, statusText: 'No records found' });
    expect(tostMsgSpy).toHaveBeenCalledWith(
      translateServiceMock.instant('Message_No_Records_Found')
    );
  });
  it('should show no message, if no error', () => {
    const tostMsgSpy = spyOn(toastrServiceMock, 'info').and.callThrough();
    const driverManagementService: DriverManagementService = getTestBed().get(
      DriverManagementService
    );
    driverManagementService.handleError(null);
    expect(tostMsgSpy).not.toHaveBeenCalled();
  });
  it('should get  starting end of work week time', async(() => {
    const driverManagementService: DriverManagementService = getTestBed().get(
      DriverManagementService
    );
    expect(driverManagementService.getEndTime(30)[0]).toEqual('12:00 AM');
  }));
  it('should get last end time', async(() => {
    const driverManagementService: DriverManagementService = getTestBed().get(
      DriverManagementService
    );
    const timeList = driverManagementService.getEndTime(30);
    expect(timeList[timeList.length - 1]).toEqual('11:30 PM');
  }));
});