import { DriverProfileQueryCriteria, DriverProfileQueryFormModel } from '../model';
export class DriverQueryRequestMapper {
  validateDriverQueryCriteria(formValue: DriverProfileQueryFormModel): DriverProfileQueryCriteria {
    let requestCriteria: DriverProfileQueryCriteria = {};
    if (formValue.domicile != null && formValue.domicile.length > 0)
      requestCriteria.domiciles = formValue.domicile.map(domicile => domicile.name);
    if (formValue.coordinatorBoard != null && formValue.coordinatorBoard.length > 0)
      requestCriteria.coordinatorBoards = formValue.coordinatorBoard.map(
        coordinatorBoard => coordinatorBoard.name
      );
    if (formValue.company != null && formValue.company.length > 0)
      requestCriteria.serviceCoCodes = formValue.company.map(company => company.id);
    requestCriteria = this.setDepartureDayTime(formValue, requestCriteria);
    requestCriteria = this.setDriverStatusScheduleType(formValue, requestCriteria);
    return requestCriteria;
  }
  private setDepartureDayTime(
    formValue: DriverProfileQueryFormModel,
    requestCriteria: DriverProfileQueryCriteria
  ): DriverProfileQueryCriteria {
    requestCriteria.departDayCode = formValue.departDay;
    if (formValue.departTime != null && formValue.departTime)
      requestCriteria.departTime = formValue.departTime;
    return requestCriteria;
  }
  private setDriverStatusScheduleType(
    formValue: DriverProfileQueryFormModel,
    requestCriteria: DriverProfileQueryCriteria
  ): DriverProfileQueryCriteria {
    if (formValue.driverStatus != null && formValue.driverStatus.length > 0)
      requestCriteria.status = formValue.driverStatus.map(status => status.name.trim());
    if (formValue.scheduleTypes != null && formValue.scheduleTypes.length > 0)
      requestCriteria.scheduleTypes = formValue.scheduleTypes.map(scheduleType => scheduleType.id);
    if (formValue.driverTypes != null && formValue.driverTypes.length > 0)
      requestCriteria.driverTypes = formValue.driverTypes.map(driverType => driverType.id);
    return requestCriteria;
  }
}