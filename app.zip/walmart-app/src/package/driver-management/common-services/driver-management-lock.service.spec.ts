import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { async, getTestBed, TestBed } from '@angular/core/testing';
import { MatDialog } from '@angular/material/dialog';
import { TranslateService } from '@ngx-translate/core';
import { EnvService, UserService } from '@transom/services';
import { ToastrService } from '@transom/ui';
import * as moment from 'moment-timezone';
import { of as observableOf } from 'rxjs';

import { DriverManagementLockService } from '.';
import { LoadingDialogService } from '../../common/loading-dialog/loading-dialog.service';
import {
  DRIVER_ALL_LOCK_URL,
  DRIVER_LOCK_URL,
  DRIVER_RELEASE_ALL_LOCK_URL
} from '../../common/urls';
import {
  equalOperator,
  lockId,
  questionare,
  seperator
} from '../../constants/driver-management-constant';
import {
  EnvServiceMock,
  LoadingDialogServiceMock,
  ToastrMessageServiceMock,
  TranslateServiceMock,
  UserServiceMock
} from '../../mock';
import { Lock, LockRequest } from '../model';

describe('DriverManagementLockService', () => {
  let mockBackend: HttpTestingController;
  let driverManagementLockService: DriverManagementLockService;
  let translateServiceMock: TranslateServiceMock;
  let toastrServiceMock: ToastrMessageServiceMock;
  let userServiceMock: UserServiceMock;
  let loadingServiceMock: LoadingDialogServiceMock;
  let envServiceMock: EnvServiceMock;
  const dialogLoaderRef = {
    close: jasmine.createSpy('close')
  };
  const mockDialogRef = {
    afterClosed: function() {
      return observableOf({ data: 'test' });
    },
    close: function() {
      return 'closed';
    }
  };
  const mockMatDialog = {
    open: function() {
      return mockDialogRef;
    },
    closeAll: function() {
      return mockDialogRef.close() + ' all';
    }
  };
  beforeEach(async(() => {
    translateServiceMock = new TranslateServiceMock();
    toastrServiceMock = new ToastrMessageServiceMock();
    userServiceMock = new UserServiceMock();
    loadingServiceMock = new LoadingDialogServiceMock();
    envServiceMock = new EnvServiceMock();
    TestBed.configureTestingModule({
      providers: [
        DriverManagementLockService,
        { provide: ToastrService, useValue: toastrServiceMock },
        { provide: TranslateService, useValue: translateServiceMock },
        { provide: EnvService, useValue: envServiceMock },
        { provide: UserService, useValue: userServiceMock },
        { provide: LoadingDialogService, useValue: loadingServiceMock },
        { provide: MatDialog, useValue: mockMatDialog }
      ],
      imports: [HttpClientTestingModule]
    });
    mockBackend = getTestBed().get(HttpTestingController);
    driverManagementLockService = getTestBed().get(DriverManagementLockService);
    (driverManagementLockService as any)['dialogLoader'] = dialogLoaderRef;
  }));
  it('should be created', () => {
    expect(driverManagementLockService).toBeTruthy();
  });
  describe('success response in  driver profile management lock service', () => {
    it('should lock screen, if service success', async(() => {
      const url =
        envServiceMock.marketPrefix.toLowerCase() + DRIVER_LOCK_URL + seperator + 'Driver';
      const lock: Lock = {
        lockType: 'Driver',
        versionId: '2012',
        lockTimeStamp: moment(new Date()).format(),
        lockId: '79',
        userId: 'vn501vx'
      };
      const lockRequest: LockRequest = {
        locks: [lock]
      };
      driverManagementLockService
        .driverProfileLock(lockRequest, 'Driver')
        .subscribe((successResult: any) => {
          expect(successResult).toEqual(true);
        });
      mockBackend
        .expectOne({
          url: url,
          method: 'POST'
        })
        .flush(observableOf(true));
    }));
    it('should release lock, if success.', async(() => {
      const url =
        envServiceMock.marketPrefix.toLowerCase() +
        DRIVER_LOCK_URL +
        seperator +
        'Driver' +
        questionare +
        lockId +
        equalOperator +
        79;
      driverManagementLockService.releaseLock(79, 'Driver').subscribe((successResult: any) => {
        expect(successResult.status).toEqual(200);
      });
      mockBackend
        .expectOne({
          url: url,
          method: 'DELETE'
        })
        .flush({
          status: 200
        });
    }));
  });
  describe('success response in all lock service', () => {
    it('should give error response if driver is locked by other user', async(() => {
      const url = envServiceMock.marketPrefix.toLowerCase() + DRIVER_ALL_LOCK_URL;
      const lock: Lock = {
        lockType: 'Driver',
        versionId: '2012',
        lockTimeStamp: moment(new Date()).format(),
        lockId: '79',
        userId: 'vn500eo'
      };
      const lockRequest: LockRequest = {
        locks: [lock]
      };
      const lockResponse = { error: [], lock: [lock] };
      driverManagementLockService.allDriversLock(lockRequest).subscribe((successResult: any) => {
        expect(successResult.lock[0].userId).toEqual('vn500eo');
      });
      mockBackend
        .expectOne({
          url: url,
          method: 'POST'
        })
        .flush(lockResponse);
    }));
    it('should give success on driver lock', async(() => {
      const url = envServiceMock.marketPrefix.toLowerCase() + DRIVER_ALL_LOCK_URL;
      const lock: Lock = {
        lockType: 'Driver',
        versionId: '2012',
        lockTimeStamp: moment(new Date()).format(),
        lockId: '79',
        userId: 'vn500eo'
      };
      const lockRequest: LockRequest = {
        locks: [lock]
      };
      driverManagementLockService.allDriversLock(lockRequest).subscribe((successResult: any) => {
        expect(successResult.status).toEqual(200);
      });
      mockBackend
        .expectOne({
          url: url,
          method: 'POST'
        })
        .flush({
          status: 200
        });
    }));
  });
  describe('success response in remove lock service', () => {
    it('should release the locked driver, if service success', async(() => {
      const url = envServiceMock.marketPrefix.toLowerCase() + DRIVER_RELEASE_ALL_LOCK_URL;
      const lock: Lock = {
        lockType: 'Driver',
        versionId: null,
        lockTimeStamp: moment(new Date()).format(),
        lockId: '79',
        userId: 'vn500eo'
      };
      const lockRequest: LockRequest = {
        locks: [lock]
      };
      driverManagementLockService.releaseAllLock(lockRequest).subscribe((successResult: any) => {
        expect(successResult.status).toEqual(200);
      });
      mockBackend
        .expectOne({
          url: url,
          method: 'PUT'
        })
        .flush({
          status: 200
        });
    }));
  });
  describe('failure response in release all lock service', () => {
    it('should show custom error message if response status 500', async(() => {
      const customErrorMessage = 'Internal server error occurred.';
      spyOn(translateServiceMock, 'instant').and.returnValue(customErrorMessage);
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const url = '/us/lockMgmt/v1/locksJson/remove';
      const lock: Lock = {
        lockType: 'Driver',
        versionId: '2012',
        lockTimeStamp: moment(new Date()).format(),
        lockId: '79',
        userId: 'vn501vx'
      };
      const lockRequest: LockRequest = {
        locks: [lock]
      };
      driverManagementLockService
        .releaseAllLock(lockRequest)
        .subscribe(
          () => fail('ObservableOf should not reach failure path'),
          () => expect(toastrServiceMock.error).toHaveBeenCalledWith(customErrorMessage)
        );
      mockBackend
        .expectOne({
          url: url,
          method: 'PUT'
        })
        .flush({ message: 'Error' }, { status: 500, statusText: customErrorMessage });
    }));
  });
  describe('failure response in all lock service', () => {
    it('should show custom error message if response status 500', async(() => {
      const customErrorMessage = 'Internal server error occurred.';
      spyOn(translateServiceMock, 'instant').and.returnValue(customErrorMessage);
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const url = '/us' + DRIVER_ALL_LOCK_URL;
      const lock: Lock = {
        lockType: 'Driver',
        versionId: '2012',
        lockTimeStamp: moment(new Date()).format(),
        lockId: '79',
        userId: 'vn501vx'
      };
      const lockRequest: LockRequest = {
        locks: [lock]
      };
      driverManagementLockService
        .allDriversLock(lockRequest)
        .subscribe(
          () => fail('ObservableOf should not reach failure path'),
          () => expect(toastrServiceMock.error).toHaveBeenCalledWith(customErrorMessage)
        );
      mockBackend
        .expectOne({
          url: url,
          method: 'POST'
        })
        .flush({ message: 'Error' }, { status: 500, statusText: customErrorMessage });
    }));
  });
  describe('failure response in driver management lock service', () => {
    it('should show custom error message if response status 500', async(() => {
      const customErrorMessage = 'Internal server error occurred.';
      spyOn(translateServiceMock, 'instant').and.returnValue(customErrorMessage);
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const url =
        envServiceMock.marketPrefix.toLowerCase() + DRIVER_LOCK_URL + seperator + 'Driver';
      const lock: Lock = {
        lockType: 'Driver',
        versionId: '2012',
        lockTimeStamp: moment(new Date()).format(),
        lockId: '79',
        userId: 'vn501vx'
      };
      const lockRequest: LockRequest = {
        locks: [lock]
      };
      driverManagementLockService
        .driverProfileLock(lockRequest, 'Driver')
        .subscribe(() => expect(toastrServiceMock.error).toHaveBeenCalledWith(customErrorMessage));
      mockBackend
        .expectOne({
          url: url,
          method: 'POST'
        })
        .flush({ message: 'Error' }, { status: 500, statusText: customErrorMessage });
    }));
    it('should show custom error message if response status 404', async(() => {
      const customErrorMessage = 'Service Not Found';
      spyOn(translateServiceMock, 'instant').and.returnValue(customErrorMessage);
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const url =
        envServiceMock.marketPrefix.toLowerCase() + DRIVER_LOCK_URL + seperator + 'Driver';
      const lock: Lock = {
        lockType: 'Driver',
        versionId: '2012',
        lockTimeStamp: moment(new Date()).format(),
        lockId: '79',
        userId: 'vn501vx'
      };
      const lockRequest: LockRequest = {
        locks: [lock]
      };
      driverManagementLockService
        .driverProfileLock(lockRequest, 'Driver')
        .subscribe(() => expect(toastrServiceMock.error).toHaveBeenCalledWith(customErrorMessage));
      mockBackend
        .expectOne({
          url: url,
          method: 'POST'
        })
        .flush({ message: 'Error' }, { status: 404, statusText: customErrorMessage });
    }));
    it('should show custom error message if response status 409 and error status as conflict', async(() => {
      const customErrorMessage = 'Conflict occurred.';
      spyOn(translateServiceMock, 'instant').and.returnValue(customErrorMessage);
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const url =
        envServiceMock.marketPrefix.toLowerCase() + DRIVER_LOCK_URL + seperator + 'Driver';
      const lock: Lock = {
        lockType: 'Driver',
        versionId: '2012',
        lockTimeStamp: moment(new Date()).format(),
        lockId: '79',
        userId: 'vn501vx'
      };
      const lockRequest: LockRequest = {
        locks: [lock]
      };
      const errorConflict = {
        errors: [
          {
            message: 'Conflict occurred.',
            status: 'CONFLICT'
          }
        ]
      };
      driverManagementLockService
        .driverProfileLock(lockRequest, 'Driver')
        .subscribe(() => expect(toastrServiceMock.error).toHaveBeenCalledWith(customErrorMessage));
      mockBackend
        .expectOne({
          url: url,
          method: 'POST'
        })
        .flush(errorConflict, {
          status: 409,
          statusText: customErrorMessage
        });
    }));
    it('should show custom error message if response status 409 and error status as Error', async(() => {
      const customErrorMessage = 'Error occurred.';
      spyOn(translateServiceMock, 'instant').and.returnValue(customErrorMessage);
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const url =
        envServiceMock.marketPrefix.toLowerCase() + DRIVER_LOCK_URL + seperator + 'Driver';
      const lock: Lock = {
        lockType: 'Driver',
        versionId: '2012',
        lockTimeStamp: moment(new Date()).format(),
        lockId: '79',
        userId: 'vn501vx'
      };
      const lockRequest: LockRequest = {
        locks: [lock]
      };
      const errorConflict = {
        errors: [
          {
            message: customErrorMessage,
            status: 'ERROR'
          }
        ]
      };
      driverManagementLockService
        .driverProfileLock(lockRequest, 'Driver')
        .subscribe(() => expect(toastrServiceMock.error).toHaveBeenCalledWith(customErrorMessage));
      mockBackend
        .expectOne({
          url: url,
          method: 'POST'
        })
        .flush(errorConflict, {
          status: 409,
          statusText: customErrorMessage
        });
    }));
  });
  describe('failure response in driver management release lock service', () => {
    it('should show custom error message if response status 500', async(() => {
      const customErrorMessage = 'Internal server error occurred.';
      spyOn(translateServiceMock, 'instant').and.returnValue(customErrorMessage);
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const url =
        envServiceMock.marketPrefix.toLowerCase() +
        DRIVER_LOCK_URL +
        seperator +
        'Driver' +
        questionare +
        lockId +
        equalOperator +
        79;
      driverManagementLockService
        .releaseLock(79, 'Driver')
        .subscribe(
          () => fail('ObservableOf should not reach failure path'),
          () => expect(toastrServiceMock.error).toHaveBeenCalledWith(customErrorMessage)
        );
      mockBackend
        .expectOne({
          url: url,
          method: 'DELETE'
        })
        .flush({ message: 'Error' }, { status: 500, statusText: customErrorMessage });
    }));
    it('should show custom error message if response status 404', async(() => {
      const customErrorMessage = 'Service Not Found';
      spyOn(translateServiceMock, 'instant').and.returnValue(customErrorMessage);
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const url =
        envServiceMock.marketPrefix.toLowerCase() +
        DRIVER_LOCK_URL +
        seperator +
        'Driver' +
        questionare +
        lockId +
        equalOperator +
        79;
      driverManagementLockService
        .releaseLock(79, 'Driver')
        .subscribe(
          () => fail('ObservableOf should not reach failure path'),
          () => expect(toastrServiceMock.error).toHaveBeenCalledWith(customErrorMessage)
        );
      mockBackend
        .expectOne({
          url: url,
          method: 'DELETE'
        })
        .flush({ message: 'Error' }, { status: 404, statusText: customErrorMessage });
    }));
    it('should show custom error message if response status 409 and error status as conflict', async(() => {
      const customErrorMessage = 'Conflict occurred.';
      spyOn(translateServiceMock, 'instant').and.returnValue(customErrorMessage);
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const errorConflict = {
        errors: [
          {
            message: 'Conflict occurred.',
            status: 'CONFLICT'
          }
        ]
      };
      const url =
        envServiceMock.marketPrefix.toLowerCase() +
        DRIVER_LOCK_URL +
        seperator +
        'Driver' +
        questionare +
        lockId +
        equalOperator +
        79;
      driverManagementLockService
        .releaseLock(79, 'Driver')
        .subscribe(
          () => fail('ObservableOf should not reach failure path'),
          () => expect(toastrServiceMock.error).toHaveBeenCalledWith(customErrorMessage)
        );
      mockBackend
        .expectOne({
          url: url,
          method: 'DELETE'
        })
        .flush(errorConflict, {
          status: 409,
          statusText: customErrorMessage
        });
    }));
    it('should show custom error message if response status 409 and error status as Error', async(() => {
      const customErrorMessage = 'Error occurred.';
      spyOn(translateServiceMock, 'instant').and.returnValue(customErrorMessage);
      spyOn(toastrServiceMock, 'error').and.callThrough();
      const errorConflict = {
        errors: [
          {
            message: customErrorMessage,
            status: 'ERROR'
          }
        ]
      };
      const url =
        envServiceMock.marketPrefix.toLowerCase() +
        DRIVER_LOCK_URL +
        seperator +
        'Driver' +
        questionare +
        lockId +
        equalOperator +
        79;
      driverManagementLockService
        .releaseLock(79, 'Driver')
        .subscribe(
          () => fail('ObservableOf should not reach failure path'),
          () => expect(toastrServiceMock.error).toHaveBeenCalledWith(customErrorMessage)
        );
      mockBackend
        .expectOne({
          url: url,
          method: 'DELETE'
        })
        .flush(errorConflict, {
          status: 409,
          statusText: customErrorMessage
        });
    }));
  });
});