import { DriverQueryRequestMapper } from './driver-query-request-mapper';
describe('DriverProfileQueryRequestMapper', () => {
  let requestMapper: DriverQueryRequestMapper;
  beforeEach(() => {
    requestMapper = new DriverQueryRequestMapper();
  });
  describe('Driver Profile Query Request Mapper', () => {
    it('should set domicile name  on domicile selection', () => {
      const driverQueryFormValue = {
        company: null,
        coordinatorBoard: null,
        departDay: null,
        departTime: null,
        domicile: [{ id: null, name: '6197' }, { id: null, name: '6801' }],
        driverStatus: null,
        driverTypes: null,
        scheduleTypes: null
      };
      requestMapper.validateDriverQueryCriteria(driverQueryFormValue);
      const driverQueryRequest = requestMapper.validateDriverQueryCriteria(driverQueryFormValue);
      expect(driverQueryRequest.domiciles[0]).toEqual(driverQueryFormValue.domicile[0].name);
    });
    it('should set driver type  on driver type selection', () => {
      const driverQueryFormValue = {
        company: null,
        coordinatorBoard: null,
        departDay: null,
        departTime: null,
        domicile: [{ id: null, name: '6197' }, { id: null, name: '6801' }],
        driverStatus: null,
        driverTypes: [{ id: 'L', name: 'LOCAL' }, { id: 'R', name: 'Regional' }],
        scheduleTypes: null
      };
      requestMapper.validateDriverQueryCriteria(driverQueryFormValue);
      const driverQueryRequest = requestMapper.validateDriverQueryCriteria(driverQueryFormValue);
      expect(driverQueryRequest.driverTypes[0]).toEqual(driverQueryFormValue.driverTypes[0].id);
    });
    it('should set driver status on driver status selection', () => {
      const driverQueryFormValue = {
        company: null,
        coordinatorBoard: null,
        departDay: null,
        departTime: null,
        domicile: [{ id: null, name: '6197' }, { id: null, name: '6801' }],
        driverStatus: [{ id: '1', name: 'Active' }, { id: '2', name: 'InActive' }],
        driverTypes: [{ id: 'L', name: 'LOCAL' }, { id: 'R', name: 'Regional' }],
        scheduleTypes: null
      };
      requestMapper.validateDriverQueryCriteria(driverQueryFormValue);
      const driverQueryRequest = requestMapper.validateDriverQueryCriteria(driverQueryFormValue);
      expect(driverQueryRequest.status[0]).toEqual(driverQueryFormValue.driverStatus[0].name);
    });

    it('should set company name  on company selection', () => {
      const driverQueryFormValue = {
        company: [{ id: 'WM', name: 'Walmart' }, { id: 'Dedicated', name: 'Dedicated' }],
        coordinatorBoard: null,
        departDay: null,
        departTime: null,
        domicile: [{ id: '6197', name: '6197' }, { id: '6801', name: '6801' }],
        driverStatus: null,
        driverTypes: null,
        scheduleTypes: null
      };
      requestMapper.validateDriverQueryCriteria(driverQueryFormValue);
      const driverQueryRequest = requestMapper.validateDriverQueryCriteria(driverQueryFormValue);
      expect(driverQueryRequest.serviceCoCodes[1]).toEqual(driverQueryFormValue.company[1].name);
    });
    it('should set coordinator board on coordinatorboard selection', () => {
      const driverQueryFormValue = {
        company: [{ id: 'WM', name: 'Walmart' }, { id: 'Dedicated', name: 'Dedicated' }],
        coordinatorBoard: [{ id: 'A', name: 'A' }, { id: 'B', name: 'B' }, { id: 'C', name: 'C' }],
        departDay: null,
        departTime: null,
        domicile: [{ id: '6197', name: '6197' }, { id: '6801', name: '6801' }],
        driverStatus: null,
        driverTypes: null,
        scheduleTypes: null
      };
      requestMapper.validateDriverQueryCriteria(driverQueryFormValue);
      const driverQueryRequest = requestMapper.validateDriverQueryCriteria(driverQueryFormValue);
      expect(driverQueryRequest.coordinatorBoards[2]).toEqual(
        driverQueryFormValue.coordinatorBoard[2].name
      );
    });
    it('should set schedule type on schedule type selection', () => {
      const driverQueryFormValue = {
        company: [{ id: 'WM', name: 'Walmart' }, { id: 'Dedicated', name: 'Dedicated' }],
        coordinatorBoard: [{ id: 'A', name: 'A' }, { id: 'B', name: 'B' }, { id: 'C', name: 'C' }],
        departDay: null,
        departTime: null,
        domicile: [{ id: '6197', name: '6197' }, { id: '6801', name: '6801' }],
        driverStatus: null,
        driverTypes: null,
        scheduleTypes: [{ id: '1', name: 'Regular Full Time' }]
      };
      requestMapper.validateDriverQueryCriteria(driverQueryFormValue);
      const driverQueryRequest = requestMapper.validateDriverQueryCriteria(driverQueryFormValue);
      expect(driverQueryRequest.scheduleTypes[0]).toEqual(driverQueryFormValue.scheduleTypes[0].id);
    });
    it('should set depart day on depart day selection', () => {
      const driverQueryFormValue = {
        company: [{ id: 'WM', name: 'Walmart' }, { id: 'Dedicated', name: 'Dedicated' }],
        coordinatorBoard: [{ id: 'A', name: 'A' }, { id: 'B', name: 'B' }, { id: 'C', name: 'C' }],
        departDay: 4,
        departTime: null,
        domicile: [{ id: '6197', name: '6197' }, { id: '6801', name: '6801' }],
        driverStatus: null,
        driverTypes: null,
        scheduleTypes: [{ id: '1', name: 'Regular Full Time' }]
      };
      requestMapper.validateDriverQueryCriteria(driverQueryFormValue);
      const driverQueryRequest = requestMapper.validateDriverQueryCriteria(driverQueryFormValue);
      expect(driverQueryRequest.departDayCode).toEqual(driverQueryFormValue.departDay);
    });
    it('should set depart time on depart time selection', () => {
      const driverQueryFormValue = {
        company: [{ id: 'WM', name: 'Walmart' }, { id: 'Dedicated', name: 'Dedicated' }],
        coordinatorBoard: [{ id: 'A', name: 'A' }, { id: 'B', name: 'B' }, { id: 'C', name: 'C' }],
        departDay: 4,
        departTime: '02:00',
        domicile: [{ id: '6197', name: '6197' }, { id: '6801', name: '6801' }],
        driverStatus: null,
        driverTypes: null,
        scheduleTypes: [{ id: '1', name: 'Regular Full Time' }]
      };
      requestMapper.validateDriverQueryCriteria(driverQueryFormValue);
      const driverQueryRequest = requestMapper.validateDriverQueryCriteria(driverQueryFormValue);
      expect(driverQueryRequest.departTime).toEqual(driverQueryFormValue.departTime);
    });
  });
});