import { HttpClientTestingModule } from '@angular/common/http/testing';
import { getTestBed, TestBed } from '@angular/core/testing';
import { UserService } from '@transom/services';
import { UserServiceMock } from '../../mock';
import {
  DriverProfileDetails,
  DriverProfileDetailsForm,
  DriverProfileDetailsSaveRequest
} from '../model';
import { DriverProfileRequestMapper } from './driver-profile-request-mapper';

declare var require: any;
const driverProfileDetailsMock = JSON.parse(
  JSON.stringify(require('../../mock/json-files/driver-profile-details.json'))
);
const driverFormMock = JSON.parse(
  JSON.stringify(require('../../mock/json-files/driver-profile-form-value.json'))
);
const driverProfileRequest = JSON.parse(
  JSON.stringify(require('../../mock/json-files/driver-profile-details-request.json'))
);
describe('DriverProfileRequestMapper', () => {
  let requestMapper: DriverProfileRequestMapper;
  let userServiceMock: UserServiceMock;
  beforeEach(() => {
    userServiceMock = new UserServiceMock();
    TestBed.configureTestingModule({
      providers: [DriverProfileRequestMapper, { provide: UserService, useValue: userServiceMock }],
      imports: [HttpClientTestingModule]
    });
    requestMapper = getTestBed().get(DriverProfileRequestMapper);
  });
  it('should set save request with pending details as null, if pending schedule details is not changed.', () => {
    const driverProfileFormValue: DriverProfileDetailsForm = { ...driverFormMock };
    const driverProfileDetails: DriverProfileDetails = {
      ...driverProfileDetailsMock.driverProfileDetails
    };
    const driverDetail = { driverId: 1034, isPendingScheduleChanged: false, confirmation: '' };
    const saveRequest: DriverProfileDetailsSaveRequest = requestMapper.createSaveRequest(
      driverProfileFormValue,
      driverProfileDetails,
      driverDetail
    );
    expect(saveRequest.driverProfileDetails.pendingWorkSchedule).toEqual(null);
  });
  it('should set save request with domicile changed as true, if domicile is changed.', () => {
    const driverProfileFormValue: DriverProfileDetailsForm = { ...driverFormMock };
    const driverProfileDetails: DriverProfileDetails = {
      ...driverProfileDetailsMock.driverProfileDetails
    };
    const driverProfileSaverequest: DriverProfileDetailsSaveRequest = { ...driverProfileRequest };
    driverProfileFormValue.driverDetails.domicile = 79;
    driverProfileSaverequest.driverProfileDetails.operationalProfile.domicile = 79;
    driverProfileSaverequest.driverProfileDetails.domicileChanged = true;
    const driverDetail = { driverId: 1034, isPendingScheduleChanged: false, confirmation: '' };
    requestMapper.createSaveRequest(driverProfileFormValue, driverProfileDetails, driverDetail);
    expect(driverProfileSaverequest.driverProfileDetails.domicileChanged).toEqual(true);
  });
  it('should set save request, if driver is not active.', () => {
    const driverProfileFormValue: DriverProfileDetailsForm = { ...driverFormMock };
    const driverProfileDetails: DriverProfileDetails = {
      ...driverProfileDetailsMock.driverProfileDetails
    };
    const driverProfileSaverequest: DriverProfileDetailsSaveRequest = { ...driverProfileRequest };
    driverProfileFormValue.driverInfo.driverStatus = 'Inactive';
    driverProfileSaverequest.driverProfileDetails.operationalProfile.driverStatusCode = 0;
    const driverDetail = { driverId: 1034, isPendingScheduleChanged: false, confirmation: '' };
    const saveRequest: DriverProfileDetailsSaveRequest = requestMapper.createSaveRequest(
      driverProfileFormValue,
      driverProfileDetails,
      driverDetail
    );
    expect(saveRequest.driverProfileDetails.operationalProfile.driverStatusCode).toEqual(0);
  });
  it('should set save request, if driver is active.', () => {
    const driverProfileFormValue: DriverProfileDetailsForm = { ...driverFormMock };
    const driverProfileDetails: DriverProfileDetails = {
      ...driverProfileDetailsMock.driverProfileDetails
    };
    const driverProfileSaverequest: DriverProfileDetailsSaveRequest = { ...driverProfileRequest };
    driverProfileFormValue.driverInfo.driverStatus = 'Active';
    driverProfileSaverequest.driverProfileDetails.operationalProfile.driverStatusCode = 1;
    const driverDetail = { driverId: 1034, isPendingScheduleChanged: false, confirmation: '' };
    const saveRequest: DriverProfileDetailsSaveRequest = requestMapper.createSaveRequest(
      driverProfileFormValue,
      driverProfileDetails,
      driverDetail
    );
    expect(saveRequest.driverProfileDetails.operationalProfile.driverStatusCode).toEqual(1);
  });
  it('should set save request, if driver has no team.', () => {
    const driverProfileFormValue: DriverProfileDetailsForm = { ...driverFormMock };
    const driverProfileDetails: DriverProfileDetails = {
      ...driverProfileDetailsMock.driverProfileDetails
    };
    const driverProfileSaverequest: DriverProfileDetailsSaveRequest = { ...driverProfileRequest };
    driverProfileSaverequest.driverProfileDetails.operationalProfile.secondaryDriverId = null;
    driverProfileFormValue.driverDetails.teamDriverId = null;
    driverProfileDetails.operationalProfile.secondaryDriverId = null;
    const driverDetail = { driverId: 1034, isPendingScheduleChanged: false, confirmation: '' };
    const saveRequest: DriverProfileDetailsSaveRequest = requestMapper.createSaveRequest(
      driverProfileFormValue,
      driverProfileDetails,
      driverDetail
    );
    expect(saveRequest.driverProfileDetails.operationalProfile.secondaryDriverId).toEqual(null);
  });
  it('should not define annual in save request, if dates are null.', () => {
    const driverProfileFormValue: DriverProfileDetailsForm = { ...driverFormMock };
    const driverProfileDetails: DriverProfileDetails = {
      ...driverProfileDetailsMock.driverProfileDetails
    };
    driverProfileFormValue.benefitStatus.physicalDate = null;
    driverProfileFormValue.benefitStatus.physicalExpirationDate = null;
    driverProfileFormValue.benefitStatus.terminationDate = null;
    driverProfileFormValue.benefitStatus.companyHireDate = null;
    driverProfileFormValue.benefitStatus.cdlIssueDate = null;
    driverProfileFormValue.benefitStatus.cdlExiprationDate = null;
    driverProfileFormValue.benefitStatus.beginDriverDate = null;
    driverProfileFormValue.operationInfo.scWcLtDate = null;
    driverProfileFormValue.safetyInfoGroup.regularStartDate = null;
    driverProfileFormValue.safetyInfoGroup.woDate = null;
    const driverProfileSaverequest: DriverProfileDetailsSaveRequest = { ...driverProfileRequest };
    driverProfileFormValue.driverDetails.company = 'Walmart';
    driverProfileSaverequest.driverProfileDetails.pendingWorkSchedule = null;
    driverProfileSaverequest.driverProfileDetails.operationalProfile.serviceCoCode = 'WM';
    driverProfileSaverequest.driverProfileDetails.benefitProfile.physicalDate.timeStamp = null;
    const driverDetail = { driverId: 1034, isPendingScheduleChanged: false, confirmation: '' };
    const saveRequest: DriverProfileDetailsSaveRequest = requestMapper.createSaveRequest(
      driverProfileFormValue,
      driverProfileDetails,
      driverDetail
    );
    expect(saveRequest.driverProfileDetails.benefitProfile.annual).toEqual(undefined);
  });
  it('should set save request with ignore schedule category validation as true, if invalid schedule category.', () => {
    const driverProfileFormValue: DriverProfileDetailsForm = { ...driverFormMock };
    const driverProfileDetails: DriverProfileDetails = {
      ...driverProfileDetailsMock.driverProfileDetails
    };
    driverProfileDetails.ignoreScheduleCategoryValidation = true;
    const driverDetail = {
      driverId: 1034,
      isPendingScheduleChanged: false,
      confirmation: 'schedule.category.failed'
    };
    const saveRequest: DriverProfileDetailsSaveRequest = requestMapper.createSaveRequest(
      driverProfileFormValue,
      driverProfileDetails,
      driverDetail
    );
    expect(saveRequest.driverProfileDetails.ignoreScheduleCategoryValidation).toEqual(true);
  });
  it('should set save request with ignore departTime grpCreation as true, if invalid depart time.', () => {
    const driverProfileFormValue: DriverProfileDetailsForm = { ...driverFormMock };
    const driverProfileDetails: DriverProfileDetails = {
      ...driverProfileDetailsMock.driverProfileDetails
    };
    driverProfileDetails.ignoreDepartTimeGrpCreation = true;
    const driverDetail = {
      driverId: 1034,
      isPendingScheduleChanged: false,
      confirmation: 'depart.time.group.not.exist'
    };
    const saveRequest: DriverProfileDetailsSaveRequest = requestMapper.createSaveRequest(
      driverProfileFormValue,
      driverProfileDetails,
      driverDetail
    );
    expect(saveRequest.driverProfileDetails.ignoreDepartTimeGrpCreation).toEqual(true);
  });
});