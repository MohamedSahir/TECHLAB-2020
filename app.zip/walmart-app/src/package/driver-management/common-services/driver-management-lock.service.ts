import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { EnvService, UserService } from '@transom/services';
import { ToastrService } from '@transom/ui';
import { Observable, of, throwError as observableThrowError } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { LoadingDialogService } from './../../common/loading-dialog/loading-dialog.service';

import {
  DRIVER_ALL_LOCK_URL,
  DRIVER_LOCK_URL,
  DRIVER_RELEASE_ALL_LOCK_URL
} from '../../common/urls';
import {
  equalOperator,
  errors,
  lockId,
  questionare,
  seperator
} from '../../constants/driver-management-constant';
import { ActivateDedicatedDriverLockResponse, LockRequest } from '../model';

@Injectable()
export class DriverManagementLockService {
  constructor(
    private http: HttpClient,
    private toastrService: ToastrService,
    private translateService: TranslateService,
    private envService: EnvService,
    private userService: UserService,
    private loadingDialogService: LoadingDialogService
  ) {}
  driverProfileLock(lockRequest: LockRequest, locType: string): Observable<Boolean> {
    const url = this.envService.marketPrefix.toLowerCase() + DRIVER_LOCK_URL + seperator + locType;
    const headerData: HttpHeaders = new HttpHeaders({
      userId: this.userService.userId.trim(),
      userPrincipalName: this.userService.userId.trim() + this.userService.userPrincipalName,
      'skip-retry': 'true'
    });
    return this.http.post(url, lockRequest, { headers: headerData }).pipe(
      map(response => {
        return true;
      }),
      catchError((error: HttpErrorResponse) => {
        this.handleLockError(error);
        return of(false);
      })
    );
  }

  allDriversLock(lockRequest: LockRequest): Observable<ActivateDedicatedDriverLockResponse> {
    const url = this.envService.marketPrefix.toLowerCase() + DRIVER_ALL_LOCK_URL;
    const headerData: HttpHeaders = new HttpHeaders({
      userId: this.userService.userId.trim(),
      userPrincipalName: this.userService.userId.trim() + this.userService.userPrincipalName,
      'skip-retry': 'true'
    });
    return this.http
      .post<ActivateDedicatedDriverLockResponse>(url, lockRequest, { headers: headerData })
      .pipe(
        tap((response: ActivateDedicatedDriverLockResponse) => {
          return response;
        }),
        catchError((error: HttpErrorResponse) => this.handleLockError(error))
      );
  }

  releaseLock<T>(id: number, locType: string): Observable<T> {
    const url =
      this.envService.marketPrefix.toLowerCase() +
      DRIVER_LOCK_URL +
      seperator +
      locType +
      questionare +
      lockId +
      equalOperator +
      id;
    const headerData: HttpHeaders = new HttpHeaders({
      userId: this.userService.userId.trim(),
      userPrincipalName: this.userService.userId.trim() + this.userService.userPrincipalName,
      'skip-retry': 'true'
    });
    return this.http
      .delete<T>(url, { headers: headerData })
      .pipe(catchError((error: HttpErrorResponse) => this.handleLockError(error)));
  }

  releaseAllLock<T>(lockRequest: LockRequest): Observable<T> {
    const url = this.envService.marketPrefix.toLowerCase() + DRIVER_RELEASE_ALL_LOCK_URL;
    const headerData: HttpHeaders = new HttpHeaders({
      userId: this.userService.userId.trim(),
      userPrincipalName: this.userService.userId.trim() + this.userService.userPrincipalName,
      'skip-retry': 'true'
    });
    return this.http
      .put<T>(url, lockRequest, { headers: headerData })
      .pipe(catchError((error: HttpErrorResponse) => this.handleLockError(error)));
  }

  private handleLockError(errorResponse): Observable<never> {
    let errorMessage;
    this.loadingDialogService.closeLoader();
    if (
      errorResponse instanceof HttpErrorResponse &&
      errorResponse.status === 409 &&
      errorResponse.error.errors
    )
      errorResponse.error.errors.forEach(err => {
        this.toastrService.error(err.message);
      });
    else if (errorResponse.status === errors.internalServer)
      errorMessage = this.translateService.instant('InternalServerError');
    else errorMessage = this.translateService.instant('ServiceNotFound');
    if (errorMessage) this.toastrService.error(errorMessage);
    return observableThrowError(errorMessage);
  }
}