});
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from '@transom/ui';
import { Observable } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';

import {
  BASE_TERMINAL_SERVICE_URL,
  BULOCATION_SERVICE_URL,
  CALENDAR_EVENT_TYPES_URL,
  DRIVER_BENEFITS_STATUS_URL,
  DRIVER_CLASS_URL,
  DRIVER_COORDINATOR_BOARD_URL,
  DRIVER_DOMICILE_URL,
  DRIVER_DRIVER_STATUS_URL,
  DRIVER_LICENSE_TYPES_URL,
  DRIVER_PAY_TYPE_URL,
  DRIVER_PAYROLL_CATEGORY_URL,
  DRIVER_SAFETY_TYPES_URL,
  DRIVER_SCHEDULE_CATEGORY_URL,
  DRIVER_SCHEDULE_TYPE_URL,
  DRIVER_STATE_URL,
  DRIVER_TYPE_URL
} from '../../common/urls';
import { driverProfileConstants } from '../../constants/driver-management-constant';
import { errors } from '../../constants/obc-constants';
import { DriverSafetyTypes } from '../model';
import {
  BaseTerminals,
  CalendarEventTypes,
  DriverBenefitModel,
  DriverType,
  KeyValueModel,
  QualificationLicenseTypes,
  QualificationState,
  StaticDataModel
} from '../model';
@Injectable()
export class DriverQueryStaticService {
  constructor(
    private http: HttpClient,
    private toastrService: ToastrService,
    private translateService: TranslateService
  ) {}

  private fetchStaticData(url: string, key1: string, key2: string): Observable<KeyValueModel[]> {
    return this.http.get<StaticDataModel[]>(url).pipe(
      map(res => {
        return res.map((item: StaticDataModel) => {
          return this.responseMapper(item[key1], item[key2]);
        });
      }),
      catchError(error => this.handleError(error, this.translateService.instant('Service_Failure')))
    );
  }
  fetchDomicile(): Observable<KeyValueModel[]> {
    return this.fetchStaticData(
      DRIVER_DOMICILE_URL,
      driverProfileConstants.code,
      driverProfileConstants.fieldOfficeId
    );
  }
  fetchDriverBenefitStatus(): Observable<DriverBenefitModel[]> {
    return this.fetchBenefitStaticData(
      DRIVER_BENEFITS_STATUS_URL,
      driverProfileConstants.code,
      driverProfileConstants.description,
      driverProfileConstants.alternateCode
    );
  }
  fetchDriverPayType(): Observable<KeyValueModel[]> {
    return this.fetchStaticData(
      DRIVER_PAY_TYPE_URL,
      driverProfileConstants.code,
      driverProfileConstants.description
    );
  }
  fetchDriverPayrollCategory(): Observable<KeyValueModel[]> {
    return this.fetchStaticData(
      DRIVER_PAYROLL_CATEGORY_URL,
      driverProfileConstants.code,
      driverProfileConstants.description
    );
  }
  fetchDriverType(): Observable<KeyValueModel[]> {
    return this.http.get<StaticDataModel[]>(DRIVER_TYPE_URL).pipe(
      map(res => {
        return res.map((item: DriverType) => {
          return this.responseMapper(item.code, item.description);
        });
      }),
      catchError(error => this.handleError(error, this.translateService.instant('Service_Failure')))
    );
  }

  fetchDriverScheduleCategory(): Observable<KeyValueModel[]> {
    return this.fetchStaticData(
      DRIVER_SCHEDULE_CATEGORY_URL,
      driverProfileConstants.code,
      driverProfileConstants.description
    );
  }
  fetchCoordinatorBoard(): Observable<KeyValueModel[]> {
    return this.fetchStaticData(
      DRIVER_COORDINATOR_BOARD_URL,
      driverProfileConstants.code,
      driverProfileConstants.description
    );
  }
  fetchDriverStatus(): Observable<KeyValueModel[]> {
    return this.http.get<StaticDataModel[]>(DRIVER_DRIVER_STATUS_URL).pipe(
      map(res => {
        return res.map((item: StaticDataModel) => {
          return this.responseMapper(item.driverStatusCode, item.driverStatusDesc);
        });
      }),
      catchError(error => this.handleError(error, this.translateService.instant('Service_Failure')))
    );
  }
  fetchScheduleType(): Observable<KeyValueModel[]> {
    return this.fetchStaticData(
      DRIVER_SCHEDULE_TYPE_URL,
      driverProfileConstants.code,
      driverProfileConstants.description
    );
  }

  fetchBusinessLocation(): Observable<KeyValueModel[]> {
    return this.http.get<StaticDataModel[]>(BULOCATION_SERVICE_URL).pipe(
      map(res => {
        return res.map((item: StaticDataModel) => {
          return this.responseMapper(item.locationTypeCode, item.locationID);
        });
      }),
      catchError(error => this.handleError(error, this.translateService.instant('Service_Failure')))
    );
  }
  fetchDriverSafetyTypes(): Observable<KeyValueModel[]> {
    return this.http.get<DriverSafetyTypes[]>(DRIVER_SAFETY_TYPES_URL).pipe(
      map(res => {
        return res.map((item: DriverSafetyTypes) => {
          return this.responseMapper(item.code, item.description);
        });
      }),
      catchError(error => this.handleError(error, this.translateService.instant('Service_Failure')))
    );
  }

  fetchStates(): Observable<QualificationState[]> {
    return this.http.get<QualificationState[]>(DRIVER_STATE_URL).pipe(
      map(res => res),
      catchError(error => this.handleError(error, this.translateService.instant('Service_Failure')))
    );
  }
  fetchLicenseTypes(): Observable<KeyValueModel[]> {
    return this.http.get<QualificationLicenseTypes[]>(DRIVER_LICENSE_TYPES_URL).pipe(
      map(res => {
        return res.map((item: QualificationLicenseTypes) => {
          return this.responseMapper(item.hazmatLicenseTypeCode, item.hazmatLicenseTypeDesc);
        });
      }),
      catchError(error => this.handleError(error, this.translateService.instant('Service_Failure')))
    );
  }
  fetchDriverClass(): Observable<KeyValueModel[]> {
    return this.fetchStaticData(
      DRIVER_CLASS_URL,
      driverProfileConstants.driverCode,
      driverProfileConstants.driverDescription
    );
  }
  private handleError(errorResponse: HttpErrorResponse, failureMsg: string): Observable<never> {
    if (errorResponse.status === errors.conflict && errorResponse.statusText)
      this.toastrService.error(errorResponse.statusText);
    else this.toastrService.error(failureMsg);
    return new Observable<never>();
  }
  private responseMapper(code, description): KeyValueModel {
    return { id: code, name: description };
  }
  fetchBaseTerminals(): Observable<BaseTerminals[]> {
    return this.http.get<BaseTerminals[]>(BASE_TERMINAL_SERVICE_URL).pipe(
      tap(response => response),
      catchError(error => this.handleError(error, this.translateService.instant('Service_Failure')))
    );
  }
  fetchCalendarEventTypes(): Observable<CalendarEventTypes[]> {
    return this.http.get<CalendarEventTypes[]>(CALENDAR_EVENT_TYPES_URL).pipe(
      tap(response => {
        if (!response)
          this.toastrService.info(this.translateService.instant('Message_No_Records_Found'));
        else return response;
      }),
      catchError(error => this.handleError(error, this.translateService.instant('Service_Failure')))
    );
  }
  private fetchBenefitStaticData(
    url: string,
    key1: string,
    key2: string,
    key3: string
  ): Observable<DriverBenefitModel[]> {
    return this.http.get<StaticDataModel[]>(url).pipe(
      map(res => {
        return res.map((item: StaticDataModel) => {
          return { id: item.code, name: item.description, alternateCode: item.alternateCode };
        });
      }),
      catchError(error => this.handleError(error, this.translateService.instant('Service_Failure')))
    );
  }
}