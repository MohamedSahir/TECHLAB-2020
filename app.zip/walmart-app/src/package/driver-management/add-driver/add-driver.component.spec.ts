import { ViewEncapsulation } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder } from '@angular/forms';
import { MatDatepickerInputEvent, MatDialog } from '@angular/material';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from '@transom/ui';
import * as moment from 'moment-timezone';
import { of as observableOf } from 'rxjs';

import { driverProfileQueryConstants } from '../../../constants/driver-management-constant';
import {
  AddDriverServiceMock,
  DriverManagementServiceMock,
  DriverQueryStaticServiceMock,
  MatDialogConfirmationMock,
  ToastrMessageServiceMock,
  TranslateServiceMock
} from '../../../mock';
import { DriverManagementService, DriverQueryStaticService } from '../../common-services';
import { AddDriverComponent } from './add-driver.component';
import { AddDriverFormGroupService } from './service/add-driver-form-group.service';
import { AddDriverService } from './service/add-driver.service';

declare var require: any;
const driverProfileStaticMockData = require('../../../mock/json-files/driver-profile-static-data.json');
const driverDetailsMock = require('../../../mock/json-files/add-driver-data.json');
const scheduleTypeMockData = require('../../../mock/json-files/scheduleType.json');
describe('AddDriverComponent', () => {
  let component: AddDriverComponent;
  let fixture: ComponentFixture<AddDriverComponent>;
  let driverQueryStaticServiceMock: DriverQueryStaticServiceMock;
  let driverManagementServiceMock: DriverManagementServiceMock;
  let addDriverServiceMock: AddDriverServiceMock;
  let translateServiceMock: TranslateServiceMock;
  let matDialogRefMock: MatDialogConfirmationMock;
  let toastrServiceMock: ToastrMessageServiceMock;
  beforeEach(async(() => {
    driverQueryStaticServiceMock = new DriverQueryStaticServiceMock();
    driverManagementServiceMock = new DriverManagementServiceMock();
    addDriverServiceMock = new AddDriverServiceMock();
    translateServiceMock = new TranslateServiceMock();
    matDialogRefMock = new MatDialogConfirmationMock();
    toastrServiceMock = new ToastrMessageServiceMock();
    TestBed.configureTestingModule({
      declarations: [AddDriverComponent]
    })
      .overrideComponent(AddDriverComponent, {
        set: {
          template: '<div></div>',
          encapsulation: ViewEncapsulation.Emulated,
          providers: [
            { provide: AddDriverService, useValue: addDriverServiceMock },
            { provide: DriverQueryStaticService, useValue: driverQueryStaticServiceMock },
            { provide: DriverManagementService, useValue: driverManagementServiceMock },
            { provide: TranslateService, useValue: translateServiceMock },
            { provide: MatDialog, useValue: matDialogRefMock },
            { provide: ToastrService, useValue: toastrServiceMock },
            AddDriverFormGroupService,
            FormBuilder
          ]
        }
      })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddDriverComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create add driver component', () => {
    expect(component).toBeDefined();
  });
  it('should get driver type list', () => {
    let driverType;
    component.driverType$.subscribe(response => (driverType = response));
    expect(driverType).toEqual(driverProfileStaticMockData.driverTypeMockData);
  });
  it('should get scheduleType list', () => {
    let scheduleType;
    component.driverScheduleType$.subscribe(response => (scheduleType = response));
    expect(scheduleType).toEqual(scheduleTypeMockData);
  });
  it('should get payroll category list', () => {
    let payrollCategory;
    component.driverPayrollCategory$.subscribe(response => (payrollCategory = response));
    expect(payrollCategory).toEqual([]);
  });
  it('should get driver smoker list data', () => {
    expect(component.driverSmoker.length).toEqual(2);
  });
  it('should initialize form', () => {
    expect(component.addDriverFormGroup).toBeDefined();
  });
  it('should get import data for valid WIN no', async(() => {
    component.addDriverFormGroup.controls.driverInfo.get('winNo').setValue(123);
    spyOn(addDriverServiceMock, 'importDriverDetails').and.returnValue(
      observableOf(driverDetailsMock)
    );
    component.importWinNo();
    expect(component.hireDate).toEqual('03/10/2008');
  }));
  it('should not get import data for invalid WIN no', () => {
    component.importWinNo();
    expect(component.hireDate).toEqual(undefined);
  });
  it('should if the user select wm fleet in payroll then payType is set to wm fleet', () => {
    component.addDriverFormGroup.controls.driverInfo
      .get('payRollCategory')
      .setValue(driverProfileQueryConstants.payRollCategory_Fleet);
    expect(component.addDriverFormGroup.controls.driverInfo.get('payType').value).toEqual(
      driverProfileQueryConstants.payRollCategory_Fleet
    );
  });
  it('should enable vendorId if the user select pay category #2 in payroll', () => {
    component.addDriverFormGroup.controls.driverInfo
      .get('payRollCategory')
      .setValue(driverProfileQueryConstants.payRollCategory_Pay);
    expect(component.addDriverFormGroup.controls.driverInfo.get('vendorId').enabled).toEqual(true);
  });
  it('should not enable vendorId if the user did not select pay category #2 in payroll', () => {
    component.addDriverFormGroup.controls.driverInfo.get('payRollCategory').setValue('5');
    expect(component.addDriverFormGroup.controls.driverInfo.get('vendorId').enabled).toEqual(false);
  });
  it('should disable vendorId if user select hourly pay type', () => {
    component.addDriverFormGroup.controls.driverInfo
      .get('payType')
      .setValue(driverProfileQueryConstants.payTypeHour);
    expect(component.addDriverFormGroup.controls.driverInfo.get('vendorId').disabled).toEqual(true);
  });
  it('should not disable vendorId if user not selected hourly pay type', () => {
    component.addDriverFormGroup.controls.driverInfo.get('payType').setValue('7');
    expect(component.addDriverFormGroup.controls.driverInfo.get('vendorId').disabled).toEqual(
      false
    );
  });
  it('should get domicile Start Date null if user click clear button', () => {
    component.resetAddDriverForm();
    expect(component.domicileStartDate).toEqual(null);
  });
  it('should get null if user select a invalid date in date picker', async(() => {
    let dateThen = new Date(Date.now());
    dateThen = new Date(
      moment(new Date()).add(driverProfileQueryConstants.minimumScheduleFromDates, 'days')
    );
    const dateFuture: MatDatepickerInputEvent<Date> = {
      value: dateThen,
      target: null,
      targetElement: null
    };
    component.addDriverFormGroup.controls.scheduleInfo.get('scheduleStartDate').setValue(dateThen);
    component.scheduleDateChange(dateFuture);
    expect(component.domicileStartDate).toEqual(null);
  }));
  it('should return to driver info tab and set selectedTabIndex is 0 if save successful', async(() => {
    component.domicileStartDate = new Date();
    component.hireDate = '12/10/2019';
    component.scheduleStartDay = 'Sunday';
    spyOn(addDriverServiceMock, 'saveAddDriver').and.callThrough();
    component.saveAddDriverData();
    expect(component.selectedTabIndex).toEqual(0);
  }));
  it('should show confirmation box to create a new depart time group', async(() => {
    component.domicileStartDate = new Date();
    component.hireDate = '12/10/2019';
    component.scheduleStartDay = 'Sunday';
    const matDialogMock = spyOn(matDialogRefMock, 'open').and.callFake(() => {
      return {
        afterClosed: () => observableOf(false)
      };
    });
    spyOn(addDriverServiceMock, 'saveAddDriver').and.returnValue(
      observableOf({
        isSuccess: false,
        errors: [
          {
            status: 'depart.time.group.not.exist',
            statusText:
              'Depart time selected does not exist. Do you want to create a new depart time group?'
          }
        ]
      })
    );
    component.saveAddDriverData();
    expect(matDialogMock).toHaveBeenCalled();
  }));

  it('should get toaster message Error conflict if add driver service fail.', async(() => {
    component.domicileStartDate = new Date();
    component.hireDate = '12/10/2019';
    component.scheduleStartDay = 'Monday';
    spyOn(addDriverServiceMock, 'saveAddDriver').and.returnValue(
      observableOf({
        isSuccess: false,
        errors: [
          {
            status: 'depart.conflict',
            message: 'Error conflict'
          }
        ]
      })
    );
    const toastrSpy = spyOn(toastrServiceMock, 'error').and.returnValue(false);
    component.saveAddDriverData();
    expect(toastrSpy).toHaveBeenCalledWith('Error conflict');
  }));
  it('should get scheduleStartDay  if user click No to create a new depart time group', async(() => {
    component.domicileStartDate = new Date();
    component.hireDate = '12/10/2019';
    component.scheduleStartDay = 'Sunday';
    spyOn(addDriverServiceMock, 'saveAddDriver').and.returnValue(
      observableOf({
        isSuccess: false,
        errors: [
          {
            status: 'depart.time.group.not.exist',
            statusText:
              'Depart time selected does not exist. Do you want to create a new depart time group?'
          }
        ]
      })
    );
    spyOn(matDialogRefMock, 'open').and.callFake(() => {
      return {
        afterClosed: () => observableOf(false)
      };
    });
    component.saveAddDriverData();
    expect(component.scheduleStartDay).toEqual('Sunday');
  }));
});
