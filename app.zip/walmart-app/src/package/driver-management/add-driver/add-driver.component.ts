import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { MatDatepickerInputEvent, MatDialog, MatTabChangeEvent } from '@angular/material';
import { TranslateService } from '@ngx-translate/core';
import { ConfirmDialogComponent, ToastrService } from '@transom/ui';
import * as moment from 'moment-timezone';
import { Observable, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';

import {
  driverProfileConstants,
  driverProfileQueryConstants,
  weekdays,
  yesOrNoConstants
} from '../../../constants/driver-management-constant';
import { DriverManagementService, DriverQueryStaticService } from '../../common-services';
import {
  AddDriverRequest,
  DriverProfileBenefitRequest,
  DriverProfileDateRequest,
  DriverProfileDetailsSaveRequest,
  DriverProfileOperationalProfileRequest,
  DriverProfileSaveResponse,
  DriverProfileScheduleRequest,
  DriverQueryPreviewResponse,
  KeyValueModel
} from '../../model';
import { AddDriverFormGroupService } from './service/add-driver-form-group.service';
import { AddDriverService } from './service/add-driver.service';

@Component({
  selector: 'driver-add-driver',
  templateUrl: './add-driver.component.html',
  styleUrls: ['./add-driver.component.scss'],
  providers: [AddDriverService, AddDriverFormGroupService]
})
export class AddDriverComponent implements OnInit, OnDestroy {
  addDriverFormGroup: FormGroup;
  firstName: string;
  middleName: string;
  lastName: string;
  importSuccess = true;
  hireDate: string;
  domicileStartDate: Date;
  driverPayType$: Observable<KeyValueModel[]>;
  driverDomicile$: Observable<KeyValueModel[]>;
  driverType$: Observable<KeyValueModel[]>;
  driverCoordinatorBoard$: Observable<KeyValueModel[]>;
  driverPayrollCategory$: Observable<KeyValueModel[]>;
  driverScheduleType$: Observable<KeyValueModel[]>;
  driverSmoker: KeyValueModel[];
  departTime: string[];
  scheduleStartMaxDate: Date;
  scheduleStartMinDate: Date;
  scheduleStartDay: string;
  selectedTabIndex: number;
  private importWinNoSubscription: Subscription;
  private dialogRef;
  constructor(
    private addDriverFormGroupService: AddDriverFormGroupService,
    private driverQueryStaticService: DriverQueryStaticService,
    private driverManagementService: DriverManagementService,
    private addDriverService: AddDriverService,
    private translate: TranslateService,
    private dialog: MatDialog,
    private toastrService: ToastrService
  ) {}

  ngOnInit() {
    this.fetchStaticData();
    this.initializeAddDriverForm();
  }
  ngOnDestroy() {
    if (this.importWinNoSubscription) this.importWinNoSubscription.unsubscribe();
  }
  initializeAddDriverForm(): void {
    this.addDriverFormGroup = this.addDriverFormGroupService.initializeAddDriverFormGroup();
    this.addDriverFormGroup.disable({ emitEvent: false, onlySelf: true });
    this.addDriverFormGroup.controls.driverInfo
      .get('winNo')
      .enable({ emitEvent: false, onlySelf: true });
    this.scheduleStartMaxDate = new Date();
    this.scheduleStartMinDate = new Date(
      moment(new Date()).subtract(driverProfileQueryConstants.minimumScheduleFromDates, 'days')
    );
    this.payRollCategoryChange();
    this.payTypeCategoryChange();
    this.initializeWinNoValidation();
  }
  resetAddDriverForm(): void {
    this.addDriverFormGroup.reset({ emitEvent: false, onlySelf: true });
    this.firstName = this.middleName = this.lastName = this.hireDate = this.scheduleStartDay = '';
    this.domicileStartDate = null;
    this.addDriverFormGroup.disable({ emitEvent: false, onlySelf: true });
    this.addDriverFormGroup.controls.driverInfo
      .get('winNo')
      .enable({ emitEvent: false, onlySelf: true });
    this.addDriverFormGroup.controls.driverInfo
      .get('payType')
      .setValue(driverProfileQueryConstants.payRollCategory_Fleet, {
        emitEvent: false,
        onlySelf: true
      });
    this.addDriverFormGroup.controls.driverInfo
      .get('payRollCategory')
      .setValue(driverProfileQueryConstants.payRollCategory_Fleet, {
        emitEvent: false,
        onlySelf: true
      });
    this.addDriverFormGroup.controls.driverInfo
      .get('vendorId')
      .disable({ emitEvent: false, onlySelf: true });
    this.selectedTabIndex = 0;
  }
  scheduleDateChange(event: MatDatepickerInputEvent<Date>): void {
    if (
      event.value &&
      this.addDriverFormGroup.controls.scheduleInfo.get('scheduleStartDate').valid
    ) {
      this.domicileStartDate = moment(event.value).format(driverProfileQueryConstants.dateFormat);
      this.scheduleStartDay = moment(event.value).format(driverProfileQueryConstants.dayFormat);
    } else this.domicileStartDate = this.scheduleStartDay = null;
  }
  importWinNo(): void {
    if (this.addDriverFormGroup.controls.driverInfo.get('winNo').value)
      this.importWinNoSubscription = this.addDriverService
        .importDriverDetails(this.addDriverFormGroup.controls.driverInfo.get('winNo').value)
        .subscribe(this.importWinNoSuccess);
  }
  getTabChangeEvent(event: MatTabChangeEvent): void {
    this.selectedTabIndex = event.index;
  }
  saveAddDriverData(departTimeGrpCreation?: boolean): void {
    this.addDriverService
      .saveAddDriver(this.getAddDriverRequestCriteria(departTimeGrpCreation))
      .subscribe(this.saveAddDriverSuccess);
  }
  hintMessageDriverInfo(): boolean {
    if (
      this.addDriverFormGroup.controls.driverInfo.invalid &&
      this.addDriverFormGroup.controls.driverInfo.touched &&
      this.addDriverFormGroup.controls.driverInfo.get('winNo').disabled &&
      this.selectedTabIndex === 1
    )
      return true;
  }
  hintMessageScheduleInfo(): boolean {
    if (
      this.addDriverFormGroup.controls.scheduleInfo.invalid &&
      this.addDriverFormGroup.controls.scheduleInfo.touched &&
      this.selectedTabIndex === 0
    )
      return true;
  }

  private saveAddDriverSuccess = (response: DriverProfileSaveResponse): void => {
    if (response && response.isSuccess) this.resetAddDriverForm();
    else if (
      response.errors &&
      response.errors[0].status === driverProfileConstants.depart_time_not_exist
    )
      this.openConfirmationBox(
        this.translate.instant('DepartTime_Create_Confirm_Message_Add_Driver')
      );
    else if (response.errors.length > 0) this.toastrService.error(response.errors[0].message);
  };
  private openConfirmationBox(message: string): void {
    this.dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        confirmText: message,
        title: this.translate.instant('Confirmation')
      },
      disableClose: true
    });
    this.dialogRef.afterClosed().subscribe((confirm: boolean) => {
      if (confirm) this.saveAddDriverData(true);
    });
  }
  private getAddDriverRequestCriteria(
    departTimeGrpCreation?: boolean
  ): DriverProfileDetailsSaveRequest {
    const addDriverFormData: AddDriverRequest = this.addDriverFormGroup.getRawValue();
    return {
      driverProfileDetails: {
        pendingWorkSchedule: this.createPendingWorkScheduleDetails(addDriverFormData),
        operationalProfile: this.createOperationalRequest(addDriverFormData),
        benefitProfile: this.createBenefitProfileRequest(addDriverFormData),
        ignoreDepartTimeGrpCreation: departTimeGrpCreation ? true : false,
        ignorependingSchedDeleteValidation: false,
        ignoreFLWPreferenceSave: true,
        domicileChanged: false,
        ignoreScheduleCategoryValidation: false
      }
    };
  }
  private createPendingWorkScheduleDetails(
    addDriverFormData: AddDriverRequest
  ): DriverProfileScheduleRequest {
    const scheduleStartDate = this.domicileStartDate
      ? moment(this.domicileStartDate).format(driverProfileConstants.scheduleStartDate_DateFormat)
      : '';
    return {
      departTimeGroup: {
        departTimeStr: addDriverFormData.scheduleInfo.departTime,
        departDayCode: weekdays.find(item => item.value === this.scheduleStartDay).key
      },
      driverId: addDriverFormData.driverInfo.driverId,
      drivingScheduleCode: +addDriverFormData.scheduleInfo.scheduleType,
      effectiveDate: scheduleStartDate + driverProfileConstants.pendingScheduleDateFromat
    };
  }
  private createOperationalRequest(
    addDriverFormData: AddDriverRequest
  ): DriverProfileOperationalProfileRequest {
    return {
      driverId: addDriverFormData.driverInfo.driverId,
      firstName: this.firstName,
      middleName: this.middleName,
      lastName: this.lastName,
      driverStatusCode: 0,
      driverType: addDriverFormData.driverInfo.driverType,
      serviceCoCode: driverProfileQueryConstants.serviceCoCode,
      coordinatorBoard: addDriverFormData.driverInfo.coordinatorBoard,
      payrollCode: +addDriverFormData.driverInfo.payRollCategory,
      domicile: +addDriverFormData.driverInfo.domicileId,
      domicileStartDate: this.domicileStartDate
        ? this.createDateRequest(this.domicileStartDate)
        : null,
      vendorNbr: +addDriverFormData.driverInfo.vendorId,
      smokerInd: addDriverFormData.driverInfo.smoker,
      winNbr: +addDriverFormData.driverInfo.winNo
    };
  }
  private createBenefitProfileRequest(
    addDriverFormData: AddDriverRequest
  ): DriverProfileBenefitRequest {
    return {
      driverId: 0,
      payType: addDriverFormData.driverInfo.payType,
      daysEarnedSick: 0.0,
      vacation: 0,
      personalSick: 0.0,
      safeDays: 0,
      personalTime: 0,
      deferredHolidays: 0,
      licenseDate: this.createDateRequest(null),
      licenseExpiry: this.createDateRequest(null),
      physicalDate: this.createDateRequest(null),
      physicalExpiry: this.createDateRequest(null),
      annual: this.createDateRequest(new Date(this.hireDate)),
      hireDate: this.createDateRequest(new Date(this.domicileStartDate)),
      vacationPayCount: 0
    };
  }
  private createDateRequest(value: Date): DriverProfileDateRequest {
    return {
      timeStamp: value ? moment(value).format(driverProfileQueryConstants.dateFormat) : null
    };
  }
  private importWinNoSuccess = (importResponseData: DriverQueryPreviewResponse): void => {
    const importData = importResponseData.driverProfilePreviewResponse[0];
    this.firstName = importData.firstName;
    this.middleName = importData.middleInitial;
    this.lastName = importData.lastName;
    this.hireDate = importData.hireDate.timeStamp;
    this.domicileStartDate = moment(new Date()).format(driverProfileQueryConstants.dateFormat);
    this.addDriverFormGroup.enable({ emitEvent: false, onlySelf: true });
    this.addDriverFormGroup.controls.driverInfo
      .get('winNo')
      .disable({ emitEvent: false, onlySelf: true });
    this.importSuccess = true;
  };
  private fetchStaticData(): void {
    this.driverPayType$ = this.fetchDriverPayType();
    this.driverDomicile$ = this.driverQueryStaticService.fetchDomicile().pipe(
      map((response: KeyValueModel[]) => {
        return response
          ? response.sort((domicileA, domicileB) => +domicileA.name - +domicileB.name)
          : [];
      })
    );
    this.driverType$ = this.fetchDriverType();
    this.driverCoordinatorBoard$ = this.driverQueryStaticService.fetchCoordinatorBoard();
    this.driverPayrollCategory$ = this.fetchDriverPayrollCategory();
    this.driverScheduleType$ = this.fetchScheduleType();
    this.departTime = this.driverManagementService.getDepartTime();
    this.driverSmoker = yesOrNoConstants;
  }
  private fetchDriverPayType(): Observable<KeyValueModel[]> {
    return this.driverQueryStaticService.fetchDriverPayType().pipe(
      map((response: KeyValueModel[]) => {
        return response.filter(
          payType =>
            (payType != null && payType.id === driverProfileQueryConstants.payRollCategory_Fleet) ||
            payType.id === driverProfileQueryConstants.payTypeHour
        );
      })
    );
  }
  private fetchDriverType(): Observable<KeyValueModel[]> {
    return this.driverQueryStaticService.fetchDriverType().pipe(
      map((response: KeyValueModel[]) => {
        return response.filter(
          driverType =>
            driverType != null &&
            driverType.name &&
            !driverType.name
              .trim()
              .startsWith(driverProfileQueryConstants.driverTypeDescription_ORDS)
        );
      })
    );
  }
  private fetchDriverPayrollCategory(): Observable<KeyValueModel[]> {
    return this.driverQueryStaticService.fetchDriverPayrollCategory().pipe(
      map((response: KeyValueModel[]) => {
        return response.filter(
          payRoll =>
            (payRoll != null && payRoll.id === driverProfileQueryConstants.payRollCategory_Fleet) ||
            payRoll.id === driverProfileQueryConstants.payRollCategory_Pay
        );
      })
    );
  }
  private fetchScheduleType(): Observable<KeyValueModel[]> {
    return this.driverQueryStaticService
      .fetchScheduleType()
      .pipe(map(response => (response ? this.scheduleTypeSort(response) : response)));
  }
  private scheduleTypeSort(scheduleType: KeyValueModel[]): KeyValueModel[] {
    return scheduleType.sort((a, b) => {
      if (Number(a.id) < Number(b.id)) return 1;
      if (Number(b.id) < Number(a.id)) return -1;
    });
  }
  private initializeWinNoValidation(): void {
    this.addDriverFormGroup.controls.driverInfo.get('winNo').valueChanges.forEach(() => {
      if (this.addDriverFormGroup.controls.driverInfo.get('winNo').value)
        if (
          this.addDriverFormGroup.controls.driverInfo.get('winNo').value.length === 0 ||
          this.addDriverFormGroup.controls.driverInfo.get('winNo').errors
        )
          this.importSuccess = true;
        else this.importSuccess = false;
      else this.importSuccess = true;
    });
  }
  private payRollCategoryChange(): void {
    this.addDriverFormGroup.controls.driverInfo
      .get('payRollCategory')
      .valueChanges.forEach(value => {
        if (
          value === driverProfileQueryConstants.payRollCategory_Fleet ||
          value === driverProfileQueryConstants.payRollCategory_Pay
        ) {
          this.addDriverFormGroup.controls.driverInfo
            .get('payType')
            .setValue(driverProfileQueryConstants.payRollCategory_Fleet, {
              emitEvent: false,
              onlySelf: true
            });
          this.addDriverFormGroup.controls.driverInfo.get('vendorId').reset();
          this.addDriverFormGroup.controls.driverInfo
            .get('vendorId')
            .enable({ emitEvent: false, onlySelf: true });
        }
      });
  }
  private payTypeCategoryChange(): void {
    this.addDriverFormGroup.controls.driverInfo.get('payType').valueChanges.forEach(value => {
      if (value === driverProfileQueryConstants.payTypeHour) {
        this.addDriverFormGroup.controls.driverInfo
          .get('vendorId')
          .setValue(driverProfileQueryConstants.wmVendor, { emitEvent: false, onlySelf: true });
        this.addDriverFormGroup.controls.driverInfo
          .get('vendorId')
          .disable({ emitEvent: false, onlySelf: true });
      } else {
        this.addDriverFormGroup.controls.driverInfo.get('vendorId').reset();
        this.addDriverFormGroup.controls.driverInfo
          .get('vendorId')
          .enable({ emitEvent: false, onlySelf: true });
      }
    });
  }
}
