import { CommonModule } from '@angular/common';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDatepicker, MatDialogModule } from '@angular/material';
import { TranslateLoader, TranslateModule, TranslateService } from '@ngx-translate/core';
import { DefaultInterceptor } from '@transom/core';
import { NotProdGuard } from '@transom/guards';
import {
  TransomDialogModule,
  TransomFormComponentsModule,
  TransomNavMenuModule
} from '@transom/ui';
import { DriverTranslationLoader } from './common/driver-translation-loader';
import {
  AddDriverGuard,
  DQDriverQueryViewGuard,
  DriverCalendarGuard,
  DriverProfileQueryGuard,
  NotCertGuard,
  OBCMessageQueryGuard,
  OBCSendMessageGuard,
  OfficeCalendarGuard
} from './common/guards';
import { DriverManagementModule } from './driver-management/driver-management.module';
import { DriverRootComponent } from './driver-root/driver-root.component';
import { DriverRouting } from './driver.routing';
import { MessagingModule } from './messaging/messaging.module';

@NgModule({
  imports: [
    CommonModule,
    DriverManagementModule,
    DriverRouting,
    FormsModule,
    HttpClientModule,
    MatDialogModule,
    MessagingModule,
    ReactiveFormsModule,
    TransomDialogModule,
    TransomFormComponentsModule,
    TransomNavMenuModule,
    TranslateModule.forChild({
      loader: { provide: TranslateLoader, useClass: DriverTranslationLoader },
      isolate: true
    })
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: DefaultInterceptor, multi: true },
    DriverCalendarGuard,
    DriverProfileQueryGuard,
    MatDatepicker,
    NotCertGuard,
    NotProdGuard,
    OBCMessageQueryGuard,
    OBCSendMessageGuard,
    DQDriverQueryViewGuard,
    OfficeCalendarGuard, 
    AddDriverGuard
  ],
  declarations: [DriverRootComponent],
  entryComponents: []
})
export class DriverModule {
  constructor(public translate: TranslateService) {
    this.setLanguagePreferences();
  }
  setLanguagePreferences() {
    this.translate.addLangs(['en']);
    this.translate.setDefaultLang('en');
    const browserLang = this.translate.getBrowserLang();
    this.translate.use(browserLang);
  }
}