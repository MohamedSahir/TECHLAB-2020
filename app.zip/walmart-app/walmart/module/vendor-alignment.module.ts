import { CommonModule, DatePipe } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatButtonModule,
  MatDialogModule,
  MatExpansionModule,
  MatFormFieldModule,
  MatInputModule,
  MatListModule,
  MatProgressSpinnerModule,
  MatSelectModule,
  MatTableModule
} from '@angular/material';
import {CdkTableModule} from '@angular/cdk/table';
import { VendorAlignmentComponent } from '../components/vendor-alignment.component';

// import { TranslateModule, TranslateService } from '@ngx-translate/core';
// import {
//   TransomCascadingSearchModule,
//   TransomGridModule,
//   TransomListViewModule,
//   TransomMultiInputModule,
//   TransomSearchPanelModule
// } from '@transom/ui';

// import { LocationCommonModule } from '../location-common';
// import { VendorAlignemntReadGuard, VendorAlignmentWriteGuard } from '../location-common';
// import { VendorAlignmentComponent } from './vendor-alignment.component';
// import { VendorAlignmentService } from './vendor-alignment.service';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatListModule,
    MatDialogModule,
    MatExpansionModule,
    MatFormFieldModule,
    MatProgressSpinnerModule,
    // TransomMultiInputModule,
    MatInputModule,
    // TransomSearchPanelModule,
    // TransomCascadingSearchModule,
    // TransomGridModule,
    MatSelectModule,
    MatTableModule,
    CdkTableModule
    // TransomListViewModule,
    // LocationCommonModule,
    // TranslateModule
  ],
 providers: [DatePipe, 
  // VendorAlignmentService, VendorAlignemntReadGuard, VendorAlignmentWriteGuard
],
  declarations: [VendorAlignmentComponent]
})
export class VendorAlignmentModule {
//   constructor(public translate: TranslateService) { }
constructor(){

}
}
