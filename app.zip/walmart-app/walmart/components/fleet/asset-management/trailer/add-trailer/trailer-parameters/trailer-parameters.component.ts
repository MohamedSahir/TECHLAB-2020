import {
    ChangeDetectionStrategy,
    Component,
    EventEmitter,
    Input,
    OnChanges,
    OnInit,
    Output,
    SimpleChanges
  } from '@angular/core';
  import { FormBuilder, FormGroup, Validators } from '@angular/forms';
  import { ToastrService } from '@transom/ui';
  
  import { fleetConstants } from '../../../../common/fleet-constants';
  import { addTrailerConst } from '../../../../constants/trailer-constants';
  import { TrailerProfile, TrailerStaicData } from '../../../../model';
  @Component({
    changeDetection: ChangeDetectionStrategy.OnPush,
    selector: 'fleet-trailer-parameters',
    templateUrl: './trailer-parameters.component.html',
    styleUrls: ['./trailer-parameters.component.scss']
  })
  export class TrailerParametersComponent implements OnInit, OnChanges {
    newTrailerGroup: FormGroup;
    trailerProfileData: TrailerProfile;
    years: number[];
    trailerStaticData: TrailerStaicData = new TrailerStaicData();
    private companyCode: string = addTrailerConst.serviceCompany;
    private mfgYear: number;
    pintleData = [{ value: 'Y', desc: 'Y' }, { value: 'N', desc: 'N' }];
    @Input()
    enableEdit: boolean;
    @Input()
    trailerStatus;
    @Input()
    trailerProfile;
    @Input()
    trailerData;
    @Output()
    trailerParamValues = new EventEmitter();
  
    constructor(public toastrService: ToastrService, private formBuilder: FormBuilder) {}
  
    ngOnInit() {
      this.getManufacturingYears();
      this.initializeFormControls();
      if (
        this.trailerProfileData &&
        this.trailerProfileData.trailer &&
        this.trailerProfileData.trailer.trailerId
      )
        this.setFormValues(this.trailerProfileData);
    }
  
    getManufacturingYears() {
      const currentDate = new Date();
      const currentYear = currentDate.getFullYear();
      let yearStart = currentYear + fleetConstants.mfgYearIncrementor;
      const yearEnd = currentYear - fleetConstants.yearEndLimit;
      return (this.years = Array(yearStart - yearEnd)
        .fill(undefined)
        .map(() => yearStart--));
    }
    ngOnChanges(changes: SimpleChanges) {
      if (changes.hasOwnProperty('trailerData') && changes.trailerData.currentValue !== undefined)
        this.trailerStaticData = changes['trailerData'].currentValue;
      if (
        changes.hasOwnProperty('trailerProfile') &&
        changes.trailerProfile.currentValue !== undefined
      )
        this.trailerProfileData = changes['trailerProfile'].currentValue;
      if (
        changes.hasOwnProperty('trailerStatus') &&
        changes.trailerStatus.currentValue !== undefined &&
        this.newTrailerGroup
      )
        this.newTrailerGroup.patchValue({
          statusCode: changes.trailerStatus.currentValue.toString()
        });
    }
    initializeFormControls() {
      this.mfgYear = new Date().getFullYear();
      this.newTrailerGroup = this.formBuilder.group({
        trailerId: [
          '',
          [Validators.required, Validators.pattern(fleetConstants.regExpressions.alphaNumeric)]
        ],
        serviceCompanyCode: [this.companyCode],
        trailerHeightCode: [''],
        equipSourceCode: [''],
        trailerWidthCode: [''],
        statusCode: ['', Validators.required],
        pintleHookInd: ['', Validators.required],
        trailerLengthQty: ['', Validators.required],
        mfgNameCode: [''],
        trailerType: ['', Validators.required],
        trailerYearNbr: [this.mfgYear]
      });
      this.newTrailerGroup.valueChanges.subscribe(form => {
        const trailerParamValues = {
          values: this.newTrailerGroup.value,
          status: this.newTrailerGroup.status
        };
        trailerParamValues.values.trailerTypeCode = this.newTrailerGroup.value.trailerType;
        this.trailerParamValues.emit(trailerParamValues);
      });
    }
  
    // tslint:disable-next-line:cyclomatic-complexity
    setFormValues(trailerDetails: TrailerProfile) {
      this.newTrailerGroup.patchValue({
        trailerId: trailerDetails.trailer.trailerId ? trailerDetails.trailer.trailerId.trim() : '',
        serviceCompanyCode: trailerDetails.trailer.serviceCompanyCode
          ? trailerDetails.trailer.serviceCompanyCode
          : 'WM',
        trailerHeightCode: trailerDetails.trailer.trailerHeightCode
          ? String(trailerDetails.trailer.trailerHeightCode)
          : '',
        equipSourceCode: trailerDetails.trailer.equipSourceCode
          ? String(trailerDetails.trailer.equipSourceCode)
          : '',
        trailerWidthCode: trailerDetails.trailer.trailerWidthCode
          ? String(trailerDetails.trailer.trailerWidthCode)
          : '',
        statusCode: trailerDetails.trailer.statusCode
          ? String(trailerDetails.trailer.statusCode)
          : '',
        pintleHookInd:
          trailerDetails.trailer.pintleHookInd || trailerDetails.trailer.pintleHookInd !== ' '
            ? trailerDetails.trailer.pintleHookInd
            : '',
        trailerLengthQty: trailerDetails.trailer.trailerLengthQty
          ? String(trailerDetails.trailer.trailerLengthQty)
          : '',
        mfgNameCode: trailerDetails.trailer.mfgNameCode ? trailerDetails.trailer.mfgNameCode : '',
        trailerType: trailerDetails.trailer.trailerTypeCode
          ? trailerDetails.trailer.trailerTypeCode
          : '',
        trailerYearNbr: trailerDetails.trailer.trailerYearNbr
          ? trailerDetails.trailer.trailerYearNbr
          : ''
      });
    }
  }
  