import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { async, getTestBed } from '@angular/core/testing';
import { EnvService } from '@transom/services';
import { EnvMock } from '../../../mock/env-service.mock';
import { TrailerDetailsMockService } from '../../../mock/trailer-details-service.mock';
import { AddTrailerServices } from './add-trailer.services';
// Complete
describe('AddTrailerServices', () => {
  let mockBackend: HttpTestingController;
  let envMock: EnvMock;
  beforeEach(async(() => {
    envMock = new EnvMock();
    TestBed.configureTestingModule({
      providers: [{ provide: EnvService, useValue: envMock }, AddTrailerServices],
      imports: [HttpClientTestingModule]
    });
    mockBackend = getTestBed().get(HttpTestingController);
  }));

  it('should create the new trailer on 200 status', async(() => {
    const trailerServices: AddTrailerServices = getTestBed().get(AddTrailerServices);
    const newTrailerRequest = TrailerDetailsMockService.getTrailerDetailsResponse();
    trailerServices.createNewTrailer(newTrailerRequest).subscribe(successResult => {
      expect(successResult).toBeDefined();
    });
    mockBackend
      .expectOne({
        method: 'POST'
      })
      .flush({ status: 200 });
  }));
});
