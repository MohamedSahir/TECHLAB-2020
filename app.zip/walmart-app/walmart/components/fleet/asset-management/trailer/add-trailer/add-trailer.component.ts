import { AfterViewInit, ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from '@transom/ui';
import { LoadingDialogComponent } from '@transom/ui';
import { addTrailerConst, errors } from '../../../constants/trailer-constants';
import { AddTrailer } from '../../../model/trailer-data.request';
import { TrailerStaicData } from '../../../model/trailer-static-data.response';
import { TrailerStaticDataCache } from '../../../services';
import { AddTrailerServices } from './add-trailer.services';
import { TrailerOthersComponent } from './trailer-others/trailer-others.component';
import { TrailerParametersComponent } from './trailer-parameters/trailer-parameters.component';
@Component({
  selector: 'fleet-add-trailer',
  templateUrl: './add-trailer.component.html',
  styleUrls: ['./add-trailer.component.scss']
})
export class AddTrailerComponent implements OnInit, AfterViewInit {
  trailerData: TrailerStaicData;
  newTrailer: AddTrailer;
  enableEdit = false;
  @ViewChild('parameters')
  trailerParameters: TrailerParametersComponent;
  @ViewChild('others')
  trailerOthers: TrailerOthersComponent;
  @ViewChild('stepper')
  stepper;
  isLinear = false;
  dialogRefLoader: any;
  constructor(
    private cd: ChangeDetectorRef,
    private translate: TranslateService,
    private toastrService: ToastrService,
    private addTrailerServices: AddTrailerServices,
    public dialog: MatDialog,
    private trailerStaticDataCache: TrailerStaticDataCache
  ) {}

  ngAfterViewInit() {
    this.cd.detectChanges();
  }
  ngOnInit() {
    this.loadTrailerStaticData();
  }

  loadTrailerStaticData() {
    this.trailerStaticDataCache.trailerStaticData$.subscribe(
      this.trailerStaticdataSuccess,
      this.staticdataFailure
    );
  }

  private trailerStaticdataSuccess = (response: TrailerStaicData): void => {
    if (response) this.trailerData = response;
  };

  private staticdataFailure = (response): void => {
    this.toastrService.error(this.translate.instant('ServiceFailureforStatic'));
  };

  addTrailerSave() {
    this.openLoaderDialog();
    this.createSaveRequestObject();
    this.addTrailerServices
      .createNewTrailer(this.newTrailer)
      .subscribe(this.onAddTrailerSuccess, this.onAddTrailerFailure);
  }

  private createSaveRequestObject() {
    this.newTrailer = new AddTrailer();
    this.mapTrailerParams(this.newTrailer);
    this.mapTrailerOthers(this.newTrailer);
  }

  /**
   * function to map the trailer parameters information and constants for creating request
   */
  private mapTrailerParams(newTrailerDtls: AddTrailer): any {
    newTrailerDtls.trailer = this.trailerParameters.newTrailerGroup.value;
    newTrailerDtls.trailer.trailerId = this.trailerParameters.newTrailerGroup.value.trailerId.toUpperCase();
    newTrailerDtls.trailer.licCountryCode = addTrailerConst.licCountryCode;
    newTrailerDtls.trailer.licStateCode = addTrailerConst.licStateCode;
    newTrailerDtls.trailer.airRideInd = addTrailerConst.airRideInd;
    return newTrailerDtls;
  }
  /**
   * function to map the trailer others information for creating request
   */
  private mapTrailerOthers(newTrailerDtls: AddTrailer): any {
    newTrailerDtls.trailer.inInventoryDate = this.trailerOthers.newTrailerGroupOthers.value.inInventoryDate;
    newTrailerDtls.trailer.doorTypeCode = this.trailerOthers.newTrailerGroupOthers.value.doorTypeCode;
    newTrailerDtls.trailer.trailerSerialNbr = this.trailerOthers.newTrailerGroupOthers.value.trailerSerialNbr.toUpperCase();
    newTrailerDtls.trailer.licensePlateNbr = this.trailerOthers.newTrailerGroupOthers.value.licensePlateNbr.toUpperCase();
    newTrailerDtls.trailer.trailerBarCode = this.trailerOthers.newTrailerGroupOthers.value
      .trailerBarCode
      ? this.trailerOthers.newTrailerGroupOthers.value.trailerBarCode
      : '';
    newTrailerDtls.trailer.outInventoryDate = null;
    return newTrailerDtls;
  }

  private onAddTrailerSuccess = (response): void => {
    this.closeLoader();
    if (response.Trailer)
      this.toastrService.persistentSuccess(
        'Trailer Id: ' + response.Trailer.trailerId + ' is successfully added.',
        'Success'
      );
    this.stepper.selectedIndex = 0;
  };

  private onAddTrailerFailure = (response): void => {
    this.closeLoader();
    let errorMessages: string = undefined;
    if (
      response.status &&
      (response.status === errors.internalServer ||
        (response.status === errors.badGateWay ||
          response.status === errors.notFound ||
          response.status === errors.unavailable))
    )
      this.toastrService.error(this.translate.instant('NewTrailerCreation'));
    else if (response.status === errors.conflict && response.error) {
      const errorBody = response.error;
      errorMessages = errorBody.Errors[0].message;
      this.toastrService.error(errorMessages);
    }
  };

  private openLoaderDialog = () => {
    this.dialogRefLoader = this.dialog.open(LoadingDialogComponent, {
      data: 'Processing',
      disableClose: true,
      panelClass: 'transom-loading-dialog'
    });
  };
  resetFormValues() {
    this.stepper.reset();
    this.trailerParameters.initializeFormControls();
    this.trailerOthers.initializeFormControls();
  }

  closeLoader = () => {
    if (this.dialogRefLoader && this.dialogRefLoader.close) this.dialogRefLoader.close();
  };
}
