import { SimpleChange, ViewEncapsulation } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material';

import { UserService } from '@transom/services';

import { FleetUtils } from '../../../../common/fleet-utils';
import { AddTrailerGuard } from '../../../../common/guards/asset-add-trailer.guard';
import {
  AddTrailerGuardMock,
  MatDialogRefMock,
  TrailerStaticDataMockService,
  UserServiceMock
} from '../../../../mock';
import { TrailerOthersComponent } from './trailer-others.component';

declare var require: any;
const trailerProfileDetails = require('../../../../mock/trailer-profile-mock.data.json');
describe('TrailerOthersComponent', () => {
  let component: TrailerOthersComponent;
  let fixture: ComponentFixture<TrailerOthersComponent>;
  const trailerStaticDataMockService: TrailerStaticDataMockService = new TrailerStaticDataMockService();
  const matDialogMock: MatDialogRefMock = new MatDialogRefMock();

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [],
      declarations: [TrailerOthersComponent]
    })
      .overrideComponent(TrailerOthersComponent, {
        set: {
          template: '<div></div>',
          providers: [
            { provide: AddTrailerGuard, useClass: AddTrailerGuardMock },
            FormBuilder,
            FleetUtils,
            { provide: UserService, useClass: UserServiceMock },
            { provide: MatDialog, useValue: matDialogMock }
          ],
          encapsulation: ViewEncapsulation.Emulated
        }
      })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrailerOthersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  afterAll(() => {
    component = null;
    fixture.destroy();
  });
  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should call the initializeFormControls on init  ', () => {
    spyOn(component as any, 'initializeFormControls').and.callThrough();
    component.ngOnInit();
    expect((component as any).initializeFormControls).toHaveBeenCalled();
  });
  it(' should call the setFormValues when trailerProfile is not empty on init ', () => {
    component.trailerProfileData = trailerProfileDetails.trailerProfile;
    spyOn(component as any, 'setFormValues').and.callThrough();
    component.ngOnInit();
    expect((component as any).setFormValues).toHaveBeenCalled();
  });
  it(' should set the trailerbar code as touched when trailerProfileData has an invalid barcode value ', () => {
    component.trailerProfileData = trailerProfileDetails.trailerProfile;
    component.trailerProfileData.trailer.trailerBarCode = '@wer';
    component.ngOnInit();
    expect(component.newTrailerGroupOthers.controls.trailerBarCode.touched).toBe(true);
  });
  describe('Date validation', () => {
    it(' should set errors when outInventory date is less than in invetory date ', () => {
      component.newTrailerGroupOthers.patchValue({
        outInventoryDate: '1993-11-30T00:00:00.000-06:00',
        inInventoryDate: '2018-09-28T00:00:00.000-05:00'
      });
      (component as any).outInventoryDateValidator();
      expect(component.newTrailerGroupOthers.errors.isIdentical).toBe(true);
    });
    it(' should reset errors to null  outInventory date is greater than in invetory date ', () => {
      component.newTrailerGroupOthers.patchValue({
        outInventoryDate: '2018-09-28T00:00:00.000-05:00',
        inInventoryDate: '1993-11-30T00:00:00.000-06:00'
      });
      (component as any).outInventoryDateValidator();
      expect(component.newTrailerGroupOthers.controls.outInventoryDate.errors).toBe(null);
    });
  });
  it('should set the trailerStaticData on ngOnChanges', () => {
    component.trailerData = trailerStaticDataMockService.getTrailerStaticData();
    component.ngOnChanges({
      trailerData: new SimpleChange(undefined, component.trailerData, false)
    });
    fixture.detectChanges();
    expect(component.trailerStaticData).toBeDefined();
  });
  it('should set the trailerProfileData on ngOnChanges', () => {
    component.trailerProfile = trailerProfileDetails.trailerProfile;
    component.ngOnChanges({
      trailerProfile: new SimpleChange(undefined, component.trailerProfile, false)
    });
    fixture.detectChanges();
    expect(component.trailerProfileData).toBeDefined();
  });
  it('should clear entered data on reset call', () => {
    component.newTrailerGroupOthers.controls['licensePlateNbr'].setValue('55ee');
    component.newTrailerGroupOthers.controls['trailerSerialNbr'].setValue('a123ed');
    component.resetTrailerOthers();
    expect(component.newTrailerGroupOthers.controls['licensePlateNbr'].value).toEqual('');
  });
  it('should set objectId when openCommentDialog funtions have a defined result', () => {
    spyOn(matDialogMock, 'open').and.callThrough();
    component.trailerProfileData = trailerProfileDetails.trailerProfile;
    component.openCommentDialog();
    expect(component.objectId).toEqual(1108399296);
  });
  describe('set Form Values', () => {
    it('should set doorTypeCode on setFormValues ', () => {
      const profile = trailerProfileDetails.trailerProfile;
      component.setFormValues(profile);
      expect(component.newTrailerGroupOthers.controls['doorTypeCode'].value).toEqual('2');
    });

    it('should set trailerBarCode to be empty if the response data doesnt have trailerBarCode value', () => {
      const trailerData = trailerProfileDetails.trailerProfileNullResponse;
      component.setFormValues(trailerData);
      expect(component.newTrailerGroupOthers.controls['trailerBarCode'].value).toEqual('');
    });
  });
});
