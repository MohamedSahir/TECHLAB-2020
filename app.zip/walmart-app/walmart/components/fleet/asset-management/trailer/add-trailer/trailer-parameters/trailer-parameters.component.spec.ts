import { SimpleChange } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from '@transom/ui';

import {
  AddTrailerMockDataConstant,
  AddTrailerMockServices,
  ToastrMessagesServiceMock,
  TrailerStaticDataMockService,
  TranslateServiceMock
} from '../../../../mock';
import { AddTrailerServices } from '../add-trailer.services';
import { TrailerParametersComponent } from './trailer-parameters.component';
declare var require: any;
const trailerProfileDetails = require('../../../../mock/trailer-profile-mock.data.json');
describe('TrailerParametersComponent', () => {
  let component: TrailerParametersComponent;
  let fixture: ComponentFixture<TrailerParametersComponent>;
  let nonBlockingMessageMock: ToastrMessagesServiceMock;
  const trailerStaticDataMockService: TrailerStaticDataMockService = new TrailerStaticDataMockService();

  beforeEach(async(() => {
    nonBlockingMessageMock = new ToastrMessagesServiceMock();
    TestBed.configureTestingModule({
      declarations: [TrailerParametersComponent]
    })
      .overrideComponent(TrailerParametersComponent, {
        set: {
          template: '<div></div>',
          providers: [
            FormBuilder,
            { provide: TranslateService, useClass: TranslateServiceMock },
            { provide: ToastrService, useValue: nonBlockingMessageMock },
            { provide: AddTrailerServices, useClass: AddTrailerMockServices }
          ]
        }
      })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrailerParametersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  afterAll(() => {
    component = null;
    fixture.destroy();
  });
  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should call the getManufacturingYears on init  ', () => {
    spyOn(component as any, 'getManufacturingYears').and.callThrough();
    component.ngOnInit();
    expect((component as any).getManufacturingYears).toHaveBeenCalled();
  });
  it('should create an array of years with length equal to 52', async(() => {
    component.years = AddTrailerMockDataConstant.getYears();
    const output = component.getManufacturingYears();
    expect(output.length).toEqual(52);
  }));
  it('should call the initializeFormControls on init  ', () => {
    spyOn(component as any, 'initializeFormControls').and.callThrough();
    component.ngOnInit();
    expect((component as any).initializeFormControls).toHaveBeenCalled();
  });
  it('should set the trailerStaticData on ngOnChanges', () => {
    component.trailerData = trailerStaticDataMockService.getTrailerStaticData();
    component.ngOnChanges({
      trailerData: new SimpleChange(undefined, component.trailerData, false)
    });
    fixture.detectChanges();
    expect(component.trailerStaticData).toBeDefined();
  });
  it('should set the trailerProfileData on ngOnChanges', () => {
    component.trailerProfile = trailerProfileDetails.trailerProfile;
    component.ngOnChanges({
      trailerProfile: new SimpleChange(undefined, component.trailerProfile, false)
    });
    fixture.detectChanges();
    expect(component.trailerProfileData).toBeDefined();
  });
  it('should set the statusCode of formGroup to 2 on ngOnChanges', () => {
    component.trailerProfile = trailerProfileDetails.trailerProfile;
    component.ngOnChanges({
      trailerStatus: new SimpleChange(undefined, 2, false)
    });
    fixture.detectChanges();
    expect(component.newTrailerGroup.controls['statusCode'].value).toEqual('2');
  });
  describe('set Form Values', () => {
    it('should set trailerId on setFormValues ', () => {
      const profile = trailerProfileDetails.trailerProfile;
      component.setFormValues(profile);
      expect(component.newTrailerGroup.controls['trailerId'].value).toEqual('55555');
    });

    it('should set pintleHookInd to be empty , if response doesnt have pintleHookInd value', () => {
      const trailerData = trailerProfileDetails.trailerProfileNullResponse;
      component.setFormValues(trailerData);
      expect(component.newTrailerGroup.controls['pintleHookInd'].value).toEqual('');
    });
  });
});
