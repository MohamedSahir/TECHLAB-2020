import {
    ChangeDetectionStrategy,
    Component,
    EventEmitter,
    Input,
    OnChanges,
    OnInit,
    Output,
    SimpleChanges
  } from '@angular/core';
  import { FormBuilder, FormGroup, Validators } from '@angular/forms';
  import { MatDialog } from '@angular/material';
  import { UserService } from '@transom/services';
  
  import { FormControlStateMatcher } from '../../../../common/error-state.validator';
  import { fleetConstants } from '../../../../common/fleet-constants';
  import { FleetUtils } from '../../../../common/fleet-utils';
  import { AddTrailerGuard } from '../../../../common/guards/asset-add-trailer.guard';
  import { CommentWindowComponent } from '../../../../common/ui/comment-window/comment-window.component';
  import { CommentWindowRequestOption, TrailerProfile, TrailerStaicData } from '../../../../model';
  @Component({
    changeDetection: ChangeDetectionStrategy.OnPush,
    selector: 'fleet-trailer-others',
    templateUrl: './trailer-others.component.html',
    styleUrls: ['./trailer-others.component.scss']
  })
  export class TrailerOthersComponent implements OnInit, OnChanges {
    newTrailerGroupOthers: FormGroup;
    trailerProfileData: TrailerProfile;
    isEditMode: boolean;
    inventoryDate: string;
    objectId;
    trailerStaticData: TrailerStaicData = new TrailerStaicData();
    hasAddtrailerCapability: boolean;
    matcher = new FormControlStateMatcher();
    dialogRef;
    requestOptions: CommentWindowRequestOption;
    @Output()
    trailerOthersMode = new EventEmitter();
    @Output()
    commentDetails = new EventEmitter();
    @Input()
    enableEdit: boolean;
    @Input()
    trailerData: TrailerStaicData;
    @Input()
    trailerProfile: TrailerProfile;
    constructor(
      private addTrailerGuard: AddTrailerGuard,
      public fb: FormBuilder,
      public fleetUtils: FleetUtils,
      private dialog: MatDialog,
      private userService: UserService
    ) {
      this.hasCommentingCapability();
    }
  
    hasCommentingCapability() {
      this.addTrailerGuard.canActivate(null, null).subscribe(response => {
        this.hasAddtrailerCapability = response;
      });
    }
  
    ngOnInit() {
      this.initializeFormControls();
      if (
        this.trailerProfileData &&
        this.trailerProfileData.trailer &&
        this.trailerProfileData.trailer.trailerId
      )
        this.editModeValidations();
    }
    private editModeValidations() {
      this.newTrailerGroupOthers
        .get('trailerBarCode')
        .setValidators([
          Validators.required,
          Validators.pattern(fleetConstants.regExpressions.alphaNumeric)
        ]);
      this.newTrailerGroupOthers.get('outInventoryDate').valueChanges.subscribe(form => {
        this.newTrailerGroupOthers
          .get('outInventoryDate')
          .setValidators([this.outInventoryDateValidator]);
        this.newTrailerGroupOthers.updateValueAndValidity({ emitEvent: false });
      });
      this.newTrailerGroupOthers.get('inInventoryDate').valueChanges.subscribe(form => {
        this.newTrailerGroupOthers
          .get('inInventoryDate')
          .setValidators([this.outInventoryDateValidator]);
        this.newTrailerGroupOthers.updateValueAndValidity({ emitEvent: false });
      });
      this.setFormValues(this.trailerProfileData);
      if (this.newTrailerGroupOthers.controls.trailerBarCode.invalid)
        this.newTrailerGroupOthers.get('trailerBarCode').markAsTouched();
    }
  
    initializeFormControls() {
      this.newTrailerGroupOthers = this.fb.group(
        {
          inInventoryDate: [new Date()],
          outInventoryDate: [''],
          changeUserIdCtrl: [''],
          changeTsCtrl: [''],
          doorTypeCode: [''],
          trailerSerialNbr: [
            '',
            [Validators.required, Validators.pattern(fleetConstants.regExpressions.alphaNumeric)]
          ],
          licensePlateNbr: [
            '',
            [Validators.required, Validators.pattern(fleetConstants.regExpressions.alphaNumeric)]
          ],
          trailerBarCode: ['']
        },
        { validator: this.fleetUtils.licenseValidator }
      );
      this.newTrailerGroupOthers.valueChanges.subscribe(form => {
        const trailerOtherValues = {
          values: this.newTrailerGroupOthers.value,
          status: this.newTrailerGroupOthers.status
        };
        this.trailerOthersMode.emit(trailerOtherValues);
      });
    }
    private outInventoryDateValidator = () => {
      if (this.newTrailerGroupOthers) {
        const inInventoryDate = this.newTrailerGroupOthers.get('inInventoryDate');
        const outInventoryDate = this.newTrailerGroupOthers.get('outInventoryDate');
        const inDate = new Date(inInventoryDate.value);
        const outDate = new Date(outInventoryDate.value);
        if (outDate <= inDate) {
          const trailerOtherValues = {
            values: this.newTrailerGroupOthers.value,
            status: this.newTrailerGroupOthers.status
          };
          this.trailerOthersMode.emit(trailerOtherValues);
          return { outDateValidation: true };
        } else {
          this.newTrailerGroupOthers.get('inInventoryDate').setErrors(null);
          this.newTrailerGroupOthers.get('outInventoryDate').setErrors(null);
          return null;
        }
      }
    };
    setFormValues(trailerDetails: TrailerProfile) {
      this.newTrailerGroupOthers.patchValue(
        {
          inInventoryDate: trailerDetails.trailer.inInventoryDate
            ? new Date(trailerDetails.trailer.inInventoryDate)
            : '',
          doorTypeCode: trailerDetails.trailer.doorTypeCode
            ? String(trailerDetails.trailer.doorTypeCode)
            : '',
          trailerSerialNbr: trailerDetails.trailer.trailerSerialNbr
            ? trailerDetails.trailer.trailerSerialNbr.trim()
            : '',
          licensePlateNbr: trailerDetails.trailer.licensePlateNbr
            ? trailerDetails.trailer.licensePlateNbr.trim()
            : '',
          trailerBarCode: trailerDetails.trailer.trailerBarCode
            ? trailerDetails.trailer.trailerBarCode.trim()
            : '',
          outInventoryDate: trailerDetails.trailer.outInventoryDate
            ? new Date(trailerDetails.trailer.outInventoryDate)
            : '',
          changeUserIdCtrl: trailerDetails.trailer.lastChangeUserId
            ? trailerDetails.trailer.lastChangeUserId.trim()
            : '',
          changeTsCtrl: trailerDetails.trailer.lastChangeTs
            ? new Date(trailerDetails.trailer.lastChangeTs)
            : ''
        },
        { emitEvent: true }
      );
  
      this.outInventoryDateValidator();
    }
    ngOnChanges(changes: SimpleChanges) {
      if (changes.hasOwnProperty('trailerData') && changes.trailerData.currentValue !== undefined)
        this.trailerStaticData = changes['trailerData'].currentValue;
      if (
        changes.hasOwnProperty('trailerProfile') &&
        changes.trailerProfile.currentValue !== undefined
      )
        this.trailerProfileData = changes['trailerProfile'].currentValue;
    }
    resetTrailerOthers() {
      this.newTrailerGroupOthers.reset();
      this.initializeFormControls();
    }
    openCommentDialog() {
      this.requestOptions = new CommentWindowRequestOption();
      this.requestOptions.commentType = fleetConstants.commentType;
      this.requestOptions.id = this.trailerProfileData.trailer.trailerId;
      this.requestOptions.lastChangeUserId = this.userService.userId;
      this.requestOptions.pageType = fleetConstants.pageType;
      this.requestOptions.objectName = fleetConstants.objectName;
      this.requestOptions.objectId = this.objectId
        ? this.objectId
        : this.trailerProfileData.trailer.trailerCommentId;
      this.dialogRef = this.dialog.open(CommentWindowComponent, {
        data: this.requestOptions,
        panelClass: 'comment-modal'
      });
  
      this.dialogRef.afterClosed().subscribe(result => {
        if (result) {
          this.objectId = result.comments[0].commentId;
          this.commentDetails.emit(result);
        }
      });
    }
  }
  