import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EnvService } from '@transom/services';

import * as URLS from '../../../common/urls';

import { FleetUtils } from '../../../common/fleet-utils';
import { AddTrailer } from '../../../model/trailer-data.request';

@Injectable()
export class AddTrailerServices {
  constructor(private http: HttpClient, private envService: EnvService) {}

  /**
   * create new carrier
   */
  createNewTrailer(trailerData: AddTrailer): any {
    const requestOptions = { headers: FleetUtils.getJsonHeaders(this.envService) };
    const url = URLS.ADD_TRAILER_URL;
    return this.http.post(url, trailerData, requestOptions);
  }
}
