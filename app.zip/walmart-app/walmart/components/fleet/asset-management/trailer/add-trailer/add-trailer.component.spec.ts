import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { AuthZService, EnvService, UserService } from '@transom/services';
import { ToastrService } from '@transom/ui';
import { of as ObservableOf } from 'rxjs';

import { MatDialog } from '@angular/material';
import { FleetUtils } from '../../../common/fleet-utils';
import { AddTrailerGuard } from '../../../common/guards/asset-add-trailer.guard';
import {
  AddTrailerMockDataConstant,
  AddTrailerMockServices,
  MatDialogRefMock,
  ToastrMessagesServiceMock,
  TrailerStaticDataMockService,
  TranslateServiceMock,
  UserServiceMock
} from '../../../mock';
import { AddTrailer } from '../../../model/trailer-data.request';
import { Trailer } from '../../../model/trailer-dataSO';
import { TrailerStaticDataCache } from '../../../services';
import { AddTrailerComponent } from './add-trailer.component';
import { AddTrailerServices } from './add-trailer.services';
import { TrailerOthersComponent } from './trailer-others/trailer-others.component';
import { TrailerParametersComponent } from './trailer-parameters/trailer-parameters.component';
describe('AddTrailerComponent', () => {
  const mockAuth = {
    hasSendCapability() {
      return ObservableOf(true);
    }
  };
  let component: AddTrailerComponent;
  let fixture: ComponentFixture<AddTrailerComponent>;
  let newTrailerMock: AddTrailerMockServices;
  let toasterMock: ToastrMessagesServiceMock;
  let translateServiceMock: TranslateServiceMock;
  let trailerStaticDataMockService: TrailerStaticDataMockService;

  beforeEach(() => {
    newTrailerMock = new AddTrailerMockServices();
    trailerStaticDataMockService = new TrailerStaticDataMockService();
    toasterMock = new ToastrMessagesServiceMock();
    translateServiceMock = new TranslateServiceMock();
    TestBed.configureTestingModule({
      imports: [],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      declarations: [TrailerParametersComponent, TrailerOthersComponent, AddTrailerComponent],
      providers: [{ provide: TranslateService, useValue: translateServiceMock }]
    })
      .overrideComponent(TrailerOthersComponent, {
        set: {
          template: '<div></div>',
          providers: [
            FormBuilder,
            FleetUtils,
            AddTrailerGuard,
            { provide: UserService, useClass: UserServiceMock }
          ]
        }
      })
      .overrideComponent(TrailerParametersComponent, {
        set: {
          template: '<div></div>',
          providers: [FormBuilder]
        }
      })
      .overrideComponent(AddTrailerComponent, {
        set: {
          providers: [
            EnvService,
            { provide: AddTrailerServices, useClass: AddTrailerMockServices },
            { provide: AuthZService, useValue: mockAuth },
            { provide: ToastrService, useValue: toasterMock },
            { provide: TrailerStaticDataCache, useValue: trailerStaticDataMockService },
            { provide: MatDialog, useClass: MatDialogRefMock }
          ],
          template:
            '<div #stepper><fleet-trailer-others #others></fleet-trailer-others><fleet-trailer-parameters #parameters></fleet-trailer-parameters></div>'
        }
      })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddTrailerComponent);
    component = fixture.componentInstance;

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should call the loadStaticData on init  ', () => {
    spyOn(component as any, 'loadTrailerStaticData').and.callThrough();
    component.ngOnInit();
    expect((component as any).loadTrailerStaticData).toHaveBeenCalled();
  });
  it('should call the translate message service for staticdatafailure', () => {
    spyOn(toasterMock, 'error').and.callThrough();
    const messageSpy = spyOn(translateServiceMock, 'instant').and.returnValue(
      'We could not fetch trailer static data due to service issues.'
    );
    const response = {
      status: 500
    };
    component['staticdataFailure'](response);
    expect(messageSpy).toHaveBeenCalledWith('ServiceFailureforStatic');
  });
  it('should  call toaster service with translated message on staticdatafailure', () => {
    const tostMsgSpy = spyOn(toasterMock, 'error').and.callThrough();
    spyOn(translateServiceMock, 'instant').and.returnValue(
      'We could not fetch trailer static data due to service issues.'
    );
    const response = {
      status: 500
    };
    component['staticdataFailure'](response);
    expect(tostMsgSpy).toHaveBeenCalledWith(
      'We could not fetch trailer static data due to service issues.'
    );
  });

  it('should set the values on trailerStaticdataSuccess   ', () => {
    const app = fixture.componentInstance;
    spyOn(trailerStaticDataMockService, 'trailerStaticData$').and.returnValue(
      trailerStaticDataMockService.getTrailerStaticData()
    );
    (app as any).ngOnInit();
    expect(component.trailerData).toBeDefined();
  });

  describe('addTrailerSave', () => {
    it('should call the createSaveRequestObject function on addTrailersave', () => {
      const app = fixture.componentInstance;
      spyOn(newTrailerMock, 'createNewTrailer').and.returnValue(ObservableOf({ status: 200 }));
      spyOn(app as any, 'createSaveRequestObject').and.callThrough();
      app.addTrailerSave();
      fixture.detectChanges();
      expect((app as any).createSaveRequestObject).toHaveBeenCalled();
    });
    it('should call the toaster service with message on save success', () => {
      const responce = AddTrailerMockDataConstant.response;
      const tostMsgSpy = spyOn(toasterMock, 'persistentSuccess').and.callThrough();
      (component as any).onAddTrailerSuccess(responce);
      expect(tostMsgSpy).toHaveBeenCalledWith(
        'Trailer Id: 12563 is successfully added.',
        'Success'
      );
    });
    it(' should call the toaster message for 500 status', () => {
      const responce = { status: 500, error: 'Service unavailable' };
      const spy = spyOn(toasterMock, 'error').and.callThrough();
      (component as any).onAddTrailerFailure(responce);
      expect(spy).toHaveBeenCalled();
    });

    it('should call the toaster message service for 409 status', () => {
      const errorMessage = AddTrailerMockDataConstant.VALIDATION_MESSAGE;
      const tostMsgSpy = spyOn(toasterMock, 'error').and.callThrough();
      (component as any).onAddTrailerFailure(errorMessage);
      expect(tostMsgSpy).toHaveBeenCalledWith(
        'Trailer Id already exist. Please enter unique Trailer Id.Trailer Serial Number already exist. Please enter unique Serial Number.'
      );
    });
  });

  it('should map the assigned trailerId, when we call mapTrailerParams from saveclick', () => {
    const newTrailer = new AddTrailer();
    newTrailer.trailer = new Trailer();
    component.trailerParameters.newTrailerGroup.controls['trailerId'].setValue('55');
    const testVal = component.trailerParameters.newTrailerGroup.controls['trailerId'].value;
    (component as any).mapTrailerParams(newTrailer);
    expect(newTrailer.trailer.trailerId).toBe(testVal);
  });

  it('should map assigned licensePlateNbr when we call mapTrailerOthers from saveclick ', () => {
    const trailerData = new AddTrailer();
    trailerData.trailer = new Trailer();
    component.trailerOthers.newTrailerGroupOthers.controls['licensePlateNbr'].setValue('5545');
    const testValue =
      component.trailerOthers.newTrailerGroupOthers.controls['licensePlateNbr'].value;
    (component as any).mapTrailerOthers(trailerData);
    expect(trailerData.trailer.licensePlateNbr).toEqual(testValue);
  });
});
