import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatAutocompleteModule,
  MatButtonModule,
  MatCardModule,
  MatDatepickerModule,
  MatExpansionModule,
  MatFormFieldModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatSelectModule,
  MatSlideToggleModule,
  MatStepperModule,
  MatTabsModule,
  MatTooltipModule
} from '@angular/material';
import { MatDialogModule } from '@angular/material/dialog';
import { TranslateModule } from '@ngx-translate/core';
import {
  MultiInputSplitPipe,
  MultiSelectComponent,
  TransomCascadingSearchModule,
  TransomDialogModule,
  TransomEditInsertModule,
  TransomEditMenuModule,
  TransomGridModule,
  TransomListViewModule,
  TransomMultiInputModule,
  TransomMultiSelectModule,
  TransomNavMenuModule,
  TransomSearchPanelModule
} from '@transom/ui';
import { CommonFleetDirectivesModule } from '../../common/common-fleet-directives.module';
import { TrailerProfileReadGuard, TrailerProfileWriteGuard } from '../../common/guards';
import { TrailerActivityWindowComponent } from '../trailer-profile/trailer-activity/trailer-activity.component';
import { PingWindowComponent } from '../trailer-profile/trailer-ping/trailer-ping.component';
import { AddTrailerComponent } from './../trailer/add-trailer/add-trailer.component';
import { AddTrailerServices } from './../trailer/add-trailer/add-trailer.services';
import { TrailerOthersComponent } from './../trailer/add-trailer/trailer-others/trailer-others.component';
import { TrailerParametersComponent } from './../trailer/add-trailer/trailer-parameters/trailer-parameters.component';
import { EditTrailerComponent } from './../trailer/edit-trailer/edit-trailer.component';
import { TrailerDetailsComponent } from './../trailer/edit-trailer/trailer-details/trailer-details.component';
import { MoveTrailerDialogComponent } from './../trailer/move-trailer-dialog/move-trailer-dialog.component';
import { MoveTrailerServices } from './move-trailer-dialog/move-trailer.service';
import { TrailerManagementQueryComponent } from './trailer-management/trailer-management-query/trailer-management-query.component';
@NgModule({
  imports: [
    TransomMultiSelectModule,
    MatMenuModule,
    CommonModule,
    MatTooltipModule,
    MatFormFieldModule,
    TransomNavMenuModule,
    MatSelectModule,
    MatInputModule,
    MatTabsModule,
    MatDatepickerModule,
    MatAutocompleteModule,
    MatSlideToggleModule,
    TransomGridModule,
    TransomDialogModule,
    TransomCascadingSearchModule,
    FormsModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    TransomSearchPanelModule,
    TransomListViewModule,
    TransomEditInsertModule,
    TransomMultiInputModule,
    TransomEditMenuModule,
    MatIconModule,
    MatButtonModule,
    MatExpansionModule,
    MatListModule,
    MatCardModule,
    MatStepperModule,
    MatNativeDateModule,
    MatExpansionModule,
    MatDatepickerModule,
    TranslateModule,
    CommonFleetDirectivesModule,
    TransomDialogModule,
    MatDialogModule
  ],
  declarations: [
    AddTrailerComponent,
    TrailerParametersComponent,
    TrailerOthersComponent,
    MoveTrailerDialogComponent,
    EditTrailerComponent,
    TrailerDetailsComponent,
    PingWindowComponent,
    TrailerActivityWindowComponent,
    TrailerManagementQueryComponent
  ],
  providers: [
    AddTrailerServices,
    MoveTrailerServices,
    MultiInputSplitPipe,
    TransomDialogModule,
    MultiSelectComponent, MatTooltipModule, MatFormFieldModule, TrailerProfileReadGuard, TrailerProfileWriteGuard
  ],
  entryComponents: [MoveTrailerDialogComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AssetTrailerModule { }