import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material';
import { TranslateService } from '@ngx-translate/core';
import { EnvService } from '@transom/services';
import { ToastrService } from '@transom/ui';
import { Observable, throwError as observableThrowError } from 'rxjs';
import { catchError, finalize, tap } from 'rxjs/operators';

import { TRAILER_PROFILE_URL, TRAILER_UPDATE_URL } from '../../../../common/urls';
import { errors } from '../../../../constants/trailer-constants';
import {
  AddTrailer,
  TrailerProfile,
  TrailerStatusUpdateModel,
  TrailerUpdateResponse
} from '../../../../model';
import { TrailerUtils } from '../../../../utils/trailer-utils';
@Injectable()
export class TrailerProfileServices {
  trailerProfile: TrailerProfile;
  constructor(
    private http: HttpClient,
    private envService: EnvService,
    private toastrService: ToastrService,
    private translate: TranslateService,
    public dialog: MatDialog
  ) {}

  fetchTrailerDetails(trailerId: string): Observable<TrailerProfile> {
    TrailerUtils.openLoaderDialog(this.dialog);
    return this.http
      .get<TrailerProfile>(this.envService.marketPrefix + TRAILER_PROFILE_URL + trailerId)
      .pipe(
        tap(response => this.trailerProfileRes(response)),
        catchError(err => this.handleError(err)),
        finalize(() => TrailerUtils.closeLoader())
      );
  }

  private trailerProfileRes(result?: TrailerProfile): TrailerProfile {
    if (result) return result;
    else {
      this.toastrService.warning(this.translate.instant('ErrorMessage.noRecord'));
      return result;
    }
  }
  updateTrailerDetails(
    trailerData: AddTrailer,
    trailerId: string
  ): Observable<TrailerUpdateResponse> {
    TrailerUtils.openLoaderDialog(this.dialog);
    return this.http
      .put<TrailerUpdateResponse>(
        this.envService.marketPrefix + TRAILER_PROFILE_URL + trailerId,
        trailerData
      )
      .pipe(
        tap(response => this.saveUpdateResponse(response)),
        catchError(err => this.handleError(err)),
        finalize(() => TrailerUtils.closeLoader())
      );
  }
  private saveUpdateResponse(result?: TrailerUpdateResponse): TrailerUpdateResponse {
    TrailerUtils.closeLoader();
    this.toastrService.persistentSuccess(
      this.translate.instant('Service.NewTrailerUpdate'),
      'Success'
    );
    return result;
  }
  private statusUpdateResponse(result) {
    return result;
  }
  private handleError(error: any): Observable<never> {
    let errMsg;
    if (error instanceof HttpErrorResponse && error.status === errors.conflict)
      errMsg = error.error[0].errorText;
    else errMsg = this.translate.instant('ServiceNotFound');
    this.toastrService.error(errMsg);
    return observableThrowError(errMsg);
  }

  updateTrailerStatusDetails(trailerData): Observable<TrailerStatusUpdateModel> {
    return this.http
      .put<TrailerStatusUpdateModel>(this.envService.marketPrefix + TRAILER_UPDATE_URL, trailerData)
      .pipe(
        tap(response => this.statusUpdateResponse(response)),
        catchError(err => this.handleError(err)),
        finalize(() => TrailerUtils.closeLoader())
      );
  }
}
