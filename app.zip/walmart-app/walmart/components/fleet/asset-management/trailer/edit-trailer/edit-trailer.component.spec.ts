import { DatePipe } from '@angular/common';
import { SimpleChange, ViewEncapsulation } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { TranslateService } from '@ngx-translate/core';
import { AuthZService, EnvService, UserService } from '@transom/services';
import { ToastrService } from '@transom/ui';
import { Observable, of as ObservableOf } from 'rxjs';
import { FleetUtils } from '../../../common/fleet-utils';
import { MoveTrailerWriteGuard, TrailerProfileWriteGuard } from '../../../common/guards';
import { AddTrailerGuard } from '../../../common/guards/asset-add-trailer.guard';
import { TrailerStatusWriteGuard } from '../../../common/guards/trailer-status.guard';
import {
  MoveTrailerGuardMock,
  ToastrMessagesServiceMock,
  TrailerProfileServicesMock,
  TrailerProfileWriteGuardMock,
  TrailerStaticDataMockService,
  TranslateServiceMock,
  UserServiceMock
} from '../../../mock';
import { ProfileDetails, TrailerProfile } from '../../../model';
import { TrailerOthersComponent } from '../add-trailer/trailer-others/trailer-others.component';
import { TrailerParametersComponent } from '../add-trailer/trailer-parameters/trailer-parameters.component';
import { EditTrailerComponent } from './edit-trailer.component';
import { TrailerProfileServices } from './trailer-details/trailer-details.service';
declare var require: any;
const trailerProfileDetails = require('../../../mock/trailer-profile-mock.data.json');
const editTrailerDetails = require('../../../mock/edit-trailer-mock.data.json');
const moveTrailerData = require('../../../mock/json-files/comment-details-mock.data.json');
describe('EditTrailerComponent', () => {
  let component: EditTrailerComponent;
  let fixture: ComponentFixture<EditTrailerComponent>;
  let toasterMock: ToastrMessagesServiceMock;
  let translateServiceMock: TranslateServiceMock;
  let trailerStaticDataMockService: TrailerStaticDataMockService;
  let trailerEditMock: TrailerProfileServicesMock;
  let moveTrailerGuardMock: MoveTrailerGuardMock;
  let trailerProfileWriteMock: TrailerProfileWriteGuardMock;
  const mockAuth = {
    hasSendCapability() {
      return ObservableOf(true);
    }
  };
  const refMock = {
    open() {
      return {
        data: { confirmText: 'activate' },
        afterClosed: () => ObservableOf(moveTrailerData.moveTrailerResponse)
      };
    },
    afterClosed(): Observable<any> {
      return ObservableOf();
    },
    close(dialogResult?: any): void {
      //
    }
  };
  beforeEach(() => {
    trailerEditMock = new TrailerProfileServicesMock();
    trailerStaticDataMockService = new TrailerStaticDataMockService();
    toasterMock = new ToastrMessagesServiceMock();
    translateServiceMock = new TranslateServiceMock();
    moveTrailerGuardMock = new MoveTrailerGuardMock();
    trailerProfileWriteMock = new TrailerProfileWriteGuardMock();
    TestBed.configureTestingModule({
      imports: [],
      schemas: [],
      declarations: [TrailerParametersComponent, TrailerOthersComponent, EditTrailerComponent]
    })

      .overrideComponent(TrailerOthersComponent, {
        set: {
          template: '<div></div>',
          providers: [
            FormBuilder,
            FleetUtils,
            AddTrailerGuard,
            { provide: UserService, useClass: UserServiceMock }
          ]
        }
      })
      .overrideComponent(TrailerParametersComponent, {
        set: {
          template: '<div></div>',
          providers: [FormBuilder]
        }
      })
      .overrideComponent(EditTrailerComponent, {
        set: {
          providers: [
            DatePipe,
            EnvService,
            { provide: MatDialog, useValue: refMock },
            { provide: TranslateService, useValue: translateServiceMock },
            { provide: TrailerStatusWriteGuard, useClass: TrailerStatusWriteGuard },
            { provide: MoveTrailerWriteGuard, useValue: moveTrailerGuardMock },
            { provide: TrailerProfileWriteGuard, useValue: trailerProfileWriteMock },
            { provide: TrailerProfileServices, useValue: trailerEditMock },
            { provide: ToastrService, useValue: toasterMock },
            { provide: AuthZService, useValue: mockAuth }
          ],
          template:
            '<fleet-trailer-others #others></fleet-trailer-others><fleet-trailer-parameters #parameters></fleet-trailer-parameters>',
          encapsulation: ViewEncapsulation.Emulated
        }
      })

      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditTrailerComponent);
    component = fixture.componentInstance;
    jasmine.createSpyObj('component.dialogRef', ['close']);
    fixture.detectChanges();
  });
  afterAll(() => {
    component = null;
    fixture.destroy();
  });
  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set the comment list when comments are not null', () => {
    const response = trailerProfileDetails.trailerProfile;
    spyOn(trailerEditMock, 'fetchTrailerDetails').and.returnValue(ObservableOf(response));
    component.fetchTrailerProfile();
    expect(component.commentList).toBeDefined();
    expect(component.commentList.length).toBe(2);
  });
  it('comment list length should be zero when comments are empty', () => {
    const resp = trailerProfileDetails.trailerProfileNullResponse;
    spyOn(trailerEditMock, 'fetchTrailerDetails').and.returnValue(ObservableOf(resp));
    component.fetchTrailerProfile();
    expect(component.commentList.length).toEqual(0);
  });
  it('should call updateTrailerStatus function when confirmation result is true', () => {
    spyOn(component as any, 'updateTrailerStatus').and.callThrough();
    const result = true;
    (component as any).confirmStatusUpdate(result, 2);
    expect((component as any).updateTrailerStatus).toHaveBeenCalled();
  });
  it('should not call updateTrailerStatus function when result is false', () => {
    spyOn(component as any, 'updateTrailerStatus').and.callThrough();
    const result = false;
    (component as any).confirmStatusUpdate(result, 2);
    expect((component as any).updateTrailerStatus).not.toHaveBeenCalled();
  });
  it('shoud change the readOnly status to false on changeStatus', () => {
    component.changeStatus();
    expect(component.isReadOnly).toBe(false);
  });
  it(' openActivateTrailerDialog data should contain activate when boolean parameter is true', () => {
    spyOn(translateServiceMock, 'instant').and.returnValue('activate');
    spyOn(component as any, 'openActivateTrailerDialog').and.callThrough();
    (component as any).openActivateTrailerDialog(true, 1);
    expect((component as any).dialogRef.data.confirmText).toContain('activate');
  });
  it('should call confirmstatusUpdate on openActivateTrailerDialog', () => {
    spyOn(component as any, 'confirmStatusUpdate').and.callThrough();
    (component as any).openActivateTrailerDialog(false, 2);
    expect((component as any).confirmStatusUpdate).toHaveBeenCalled();
  });
  it('should set the selectedId on ngOnChanges', () => {
    component.trailerStaticData = trailerStaticDataMockService.getTrailerStaticData();
    component.trailerEssentials = { id: '55555', readOnly: true, locId: '1000' };
    component.ngOnChanges({
      trailerEssentials: new SimpleChange(undefined, component.trailerEssentials, false)
    });
    fixture.detectChanges();
    expect((component as any).selectedId).toEqual('55555');
  });
  it('should set the trailerData on ngOnChanges', () => {
    component.trailerStaticData = trailerStaticDataMockService.getTrailerStaticData();
    component.ngOnChanges({
      trailerStaticData: new SimpleChange(undefined, component.trailerStaticData, false)
    });
    fixture.detectChanges();
    expect((component as any).selectedId).not.toBeDefined();
    expect(component.trailerData).toBeDefined();
  });
  it('should not set the selectedId if the trailerEssentials current value is undefined ngOnChanges', () => {
    component.trailerEssentials = { id: undefined, readOnly: undefined, locId: '1000' };
    component.ngOnChanges({
      trailerStaticData: new SimpleChange(undefined, component.trailerEssentials, false)
    });
    fixture.detectChanges();
    expect((component as any).selectedId).not.toBeDefined();
  });
  it('should set trailerParameters when calling trailerParamValueChange', () => {
    const paramValues = {
      values: {
        trailerId: '55555',
        serviceCompanyCode: 'WM',
        trailerHeightCode: '2',
        equipSourceCode: '1',
        trailerWidthCode: '2'
      },
      status: 'VALID'
    };
    component.trailerParamValueChange(paramValues);
    expect(component.trailerParameters).toBeDefined();
  });
  it('should set the trailerOthers form values', () => {
    const othersValues = {
      values: {
        licensePlateNbr: 'OK3809BJ',
        outInventoryCtrl: '',
        trailerBarCode: 'test1',
        trailerSerialNbr: 'NV532B5XH216274'
      },
      status: 'VALID'
    };
    component.trailerOtherValueChange(othersValues);
    expect(component.trailerOthers).toBeDefined();
  });
  it('should call the fetchTrailerProfile on updateTrailerProfileSucsess', () => {
    spyOn(component, 'fetchTrailerProfile');
    spyOn(trailerEditMock, 'updateTrailerDetails').and.callThrough();
    component.trailerOthers.values = trailerProfileDetails.trailerProfile;
    component.updateTrailerProfile();
    expect(component.fetchTrailerProfile).toHaveBeenCalled();
  });
  it('should set the trailerStatus to ACTIVE on updateTrailerStatusSuccess if status is 1', () => {
    const response = editTrailerDetails.statusUpdate;
    component.trailerProfile = {} as TrailerProfile;
    component.trailerProfile.trailer = {} as ProfileDetails;
    (component as any).updateTrailerStatusSuccess(response);
    expect(component.trailerProfile.trailer.trailerStatus).toBe('ACTIVE');
  });
  it('should set the trailerStatus to INACTIVE on updateTrailerStatusSuccess if status is 2', () => {
    const response = editTrailerDetails.statusUpdateInactive;
    component.trailerProfile = {} as TrailerProfile;
    component.trailerProfile.trailer = {} as ProfileDetails;
    (component as any).updateTrailerStatusSuccess(response);
    expect(component.trailerProfile.trailer.trailerStatus).toBe('INACTIVE');
  });
  it('should set trailerProfile values with both child form values, when we call setTrailerProfileData', () => {
    component.trailerOthers.values = trailerProfileDetails.trailerProfile;
    const testValParams = trailerProfileDetails.trailerProfile;
    (component as any).setTrailerProfileData();
    expect((component as any).trailerProfileValues).toEqual(testValParams);
  });
  it('should set newStatusCode value to 1 on setStatusModel ', () => {
    (component as any).selectedId = '55555';
    (component as any).setStatusModel(1);
    expect(component.statusData.updateTrailerStatusCriteria.newStatusCode).toEqual(1);
  });

  it('should set locId when movetrailer funtions have a defined result', () => {
    component.trailerProfile = trailerProfileDetails.trailerProfile;
    component.trailerActivityArray = [];
    spyOn(refMock, 'open').and.callThrough();
    component.openMovetrailerDialog();
    expect((component as any).locId).toEqual(1030);
  });
  it('loadMoreComments should return true on setting the corresponding flag to true ', () => {
    (component as any).showMore = true;
    component.loadMoreComments();
    expect((component as any).loadMoreComments()).toEqual(true);
  });
});
