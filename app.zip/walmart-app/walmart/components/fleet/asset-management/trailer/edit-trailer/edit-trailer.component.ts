import { DatePipe } from '@angular/common';
import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges
} from '@angular/core';

import { MatDialog } from '@angular/material';
import { TranslateService } from '@ngx-translate/core';
import { ConfirmDialogComponent } from '@transom/ui';
import omit = require('lodash/omit');
import orderBy = require('lodash/orderBy');
import { fleetConstants } from '../../../common/fleet-constants';
import { MoveTrailerWriteGuard, TrailerProfileWriteGuard } from '../../../common/guards';
import { TrailerStatusWriteGuard } from '../../../common/guards/trailer-status.guard';
import { tractorConstant } from '../../../constants/tractor-constants';
import {
  ActivityResult,
  CommentResponse,
  OfficeIdle,
  Trailer,
  TrailerActivity,
  TrailerByStatusCriteria,
  TrailerParams,
  TrailerProfile,
  TrailerStaicData,
  UpdateTrailerStatusResponse
} from '../../../model';
import { MoveTrailerDialogComponent } from '../move-trailer-dialog/move-trailer-dialog.component';
import { TrailerProfileServices } from './trailer-details/trailer-details.service';
@Component({
  selector: 'edit-trailer',
  templateUrl: './edit-trailer.component.html',
  styleUrls: ['./edit-trailer.component.scss'],
  providers: [TrailerProfileServices]
})
export class EditTrailerComponent implements OnInit, OnChanges {
  trailerStatus: number;
  trailerData: TrailerStaicData;
  statusData: UpdateTrailerStatusResponse;
  trailerProfile: TrailerProfile;
  commentList: CommentResponse[];
  isReadOnly = true;
  trailerParameters: TrailerParams;
  trailerOthers: TrailerParams;
  statusWriteCapability: boolean;
  private trailerProfileValues: Trailer;
  private trailerQueryModel: TrailerByStatusCriteria;
  private dialogRef: any;
  private showMore = false;
  private selectedId: string;
  private locId: string;
  trailerActivityValues: ActivityResult[] = new Array<ActivityResult>();
  moveTraileCapability: boolean;
  hasTrailerWrite: boolean;
  trailerActivityArray: ActivityResult[];
  officeidle: OfficeIdle[];
  @Input()
  trailerEssentials;
  @Input()
  trailerStaticData;
  @Output()
  trailerStatusChange = new EventEmitter();
  constructor(
    public dialog: MatDialog,
    private trailerProfileServices: TrailerProfileServices,
    private translate: TranslateService,
    private datePipe: DatePipe,
    public statusWriteGuard: TrailerStatusWriteGuard,
    private profileWriteGuard: TrailerProfileWriteGuard,
    private moveTrailerGuard: MoveTrailerWriteGuard
  ) {
    this.trailerParameters = new TrailerParams();
    this.trailerOthers = new TrailerParams();
    this.hasStatusWriteCapability();
    this.hasMoveTrailerCapability();
    this.editTrailerCapability();
    this.commentList = [];
  }
  hasMoveTrailerCapability() {
    this.moveTrailerGuard.canWrite().subscribe(response => {
      this.moveTraileCapability = response;
    });
  }
  editTrailerCapability() {
    this.profileWriteGuard.canWrite().subscribe(response => {
      this.hasTrailerWrite = response;
    });
  }
  hasStatusWriteCapability() {
    this.statusWriteGuard.canWrite().subscribe(response => {
      this.statusWriteCapability = response;
    });
  }

  ngOnInit() {
    this.initializeModels();
  }
  initializeModels() {
    this.trailerQueryModel = {
      newStatusCode: undefined,
      trailerIDs: undefined
    };
    this.statusData = {
      updateTrailerStatusCriteria: undefined
    };
  }
  ngOnChanges(changes: SimpleChanges) {
    if (changes.hasOwnProperty('trailerEssentials'))
      if (
        changes.trailerEssentials.currentValue.id !== undefined &&
        changes.trailerEssentials.currentValue.readOnly !== undefined
      ) {
        this.selectedId = changes.trailerEssentials.currentValue.id;
        this.isReadOnly = changes['trailerEssentials'].currentValue.readOnly;
        this.locId = changes.trailerEssentials.currentValue.locId;
        this.fetchTrailerProfile();
      }
    if (
      changes.hasOwnProperty('trailerStaticData') &&
      changes.trailerStaticData.currentValue !== undefined
    )
      this.trailerData = changes.trailerStaticData.currentValue;
  }
  fetchTrailerProfile() {
    this.trailerProfileServices
      .fetchTrailerDetails(this.selectedId)
      .subscribe(this.fetchTrailerDetailSuccess);
  }

  private fetchTrailerDetailSuccess = (response): void => {
    this.trailerProfile = response;
    this.trailerStatus = response.trailer.statusCode;
    const lenghtElem = this.trailerProfile.trailer.trailerActivity.length;
    this.locId =
      this.trailerProfile.trailer.trailerActivity.length > 0
        ? this.trailerProfile.trailer.trailerActivity[lenghtElem - 1].locationId
        : this.locId;
    this.trailerActivityArray = this.trailerProfile.trailer.trailerActivity
      ? this.trailerProfile.trailer.trailerActivity
      : this.trailerActivityValues;
    this.officeidle = this.trailerProfile.trailer.officeIdle;
    if (response.hasOwnProperty('trailer') && response.trailer.comments)
      this.commentList = orderBy(response.trailer.comments, ['lastChangeTs'], ['desc']);
    else this.commentList = [];
  };
  trailerOtherValueChange(formvalue) {
    this.trailerOthers = formvalue;
  }
  trailerParamValueChange(formvalue) {
    this.trailerParameters = formvalue;
  }
  newTrailerComments(data) {
    if (data) this.commentList = orderBy(data.comments, ['lastChangeTs'], ['desc']);
  }
  updateTrailerProfile = () => {
    this.setTrailerProfileData();
    this.trailerProfileServices
      .updateTrailerDetails({ trailer: this.trailerProfileValues }, this.selectedId)
      .subscribe(this.updateTrailerSuccess);
  };
  private updateTrailerSuccess = response => {
    this.fetchTrailerProfile();
    this.isReadOnly = true;
  };
  private setTrailerProfileData = (): Trailer => {
    const inDate = this.datePipe.transform(
      this.trailerOthers.values.inInventoryDate,
      tractorConstant.datePickerFormat
    );
    this.trailerOthers.values.inInventoryDate = inDate;
    this.trailerOthers.values.outInventoryDate = this.datePipe.transform(
      this.trailerOthers.values.outInventoryDate,
      tractorConstant.datePickerFormat
    );

    this.trailerProfileValues = {
      ...this.trailerParameters.values,
      ...this.trailerOthers.values
    };
    return this.trailerProfileValues;
  };
  changeStatus = (): boolean => {
    this.isReadOnly = !this.isReadOnly;
    return this.isReadOnly;
  };
  openActivateTrailerDialog(activeStatus: boolean, statusCode: number) {
    let descr: string;
    let confirmMsg: string;
    if (activeStatus) descr = this.translate.instant('activate');
    else descr = this.translate.instant('deactivate');
    confirmMsg =
      this.translate.instant('StatusChangeMessage.firstSection') +
      descr +
      this.translate.instant('StatusChangeMessage.lastSection');

    this.dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: { confirmText: confirmMsg }
    });
    this.dialogAfterclose(statusCode);
  }
  private dialogAfterclose = statusCode => {
    this.dialogRef.afterClosed().subscribe(result => {
      this.confirmStatusUpdate(result, statusCode);
    });
  };
  private confirmStatusUpdate = (result: boolean, statusCode) => {
    if (result) this.updateTrailerStatus(statusCode, this.statusData);
  };
  openMovetrailerDialog() {
    const moveTrailerData = new TrailerActivity();
    moveTrailerData.serviceCoCode = this.trailerProfile.trailer.serviceCompanyCode;
    moveTrailerData.trailerId = this.selectedId;
    moveTrailerData.locationId = this.locId ? this.locId.toString() : null;
    this.dialogRef = this.dialog.open(MoveTrailerDialogComponent, {
      data: moveTrailerData
    });
    this.dialogRef.afterClosed().subscribe(result => {
      if (result) {
        let moveResponse = result.TrailerMoveCriteria.trailerActivity;
        moveResponse = omit(moveResponse, ['isReadOnly', 'lockUserId', 'userTracker']);
        this.trailerActivityArray = [...this.trailerActivityArray, moveResponse];
        this.locId = result.TrailerMoveCriteria.trailerActivity.locationId;
      }
    });
  }
  loadMoreComments = (): boolean => {
    return this.showMore;
  };

  private updateTrailerStatus(statusCode: number, values: UpdateTrailerStatusResponse): void {
    this.setStatusModel(statusCode);
    this.trailerProfileServices
      .updateTrailerStatusDetails(this.statusData)
      .subscribe(this.updateTrailerStatusSuccess);
  }
  private setStatusModel = (statusCode: number) => {
    this.trailerQueryModel.newStatusCode = statusCode;
    this.trailerQueryModel.trailerIDs = [this.selectedId];
    this.statusData.updateTrailerStatusCriteria = this.trailerQueryModel;
  };
  private updateTrailerStatusSuccess = (response): void => {
    if (response.updateTrailerStatusCriteria) {
      const statusValue = parseInt(
        response.updateTrailerStatusCriteria.newStatusCode,
        fleetConstants.radix
      );
      this.trailerProfile.trailer.statusCode = statusValue;
      this.trailerProfile.trailer.trailerStatus =
        statusValue === 1 ? fleetConstants.active : fleetConstants.inactive;
      this.trailerStatus = statusValue;
    }
  };
}
