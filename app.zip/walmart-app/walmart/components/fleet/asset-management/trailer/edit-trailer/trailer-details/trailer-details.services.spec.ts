import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { async, getTestBed } from '@angular/core/testing';
import { MatDialog } from '@angular/material';
import { TranslateService } from '@ngx-translate/core';
import { EnvService } from '@transom/services';
import { ToastrService } from '@transom/ui';
import { TRAILER_PROFILE_URL, TRAILER_UPDATE_URL } from '../../../../common/urls';
import {
  EnvMock,
  MatDialogRefMock,
  ToastrMessagesServiceMock,
  TranslateServiceMock
} from '../../../../mock';
import { AddTrailer, Trailer, TrailerStatusUpdateModel } from '../../../../model';
import { TrailerProfileServices } from './trailer-details.service';
declare var require: any;
const editTrailerDetails = require('../../../../mock/edit-trailer-mock.data.json');
describe('TrailerProfileServices', () => {
  let mockBackend: HttpTestingController;
  let service: TrailerProfileServices;
  let envMock: EnvMock;
  let toastrMessagesServiceMock: ToastrMessagesServiceMock;
  let translateServiceMock: TranslateServiceMock;

  beforeEach(async(() => {
    translateServiceMock = new TranslateServiceMock();
    toastrMessagesServiceMock = new ToastrMessagesServiceMock();
    envMock = new EnvMock();

    TestBed.configureTestingModule({
      providers: [
        TrailerProfileServices,
        { provide: MatDialog, useClass: MatDialogRefMock },
        { provide: ToastrService, useValue: toastrMessagesServiceMock },
        { provide: EnvService, useValue: envMock },
        { provide: TranslateService, useValue: translateServiceMock }
      ],
      imports: [HttpClientTestingModule]
    });
    mockBackend = getTestBed().get(HttpTestingController);
    service = getTestBed().get(TrailerProfileServices);
  }));
  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  describe('fetch Trailer Details', () => {
    it('with market specific url, should call the service url for US market', async(() => {
      const url = envMock.marketPrefix.toLowerCase() + TRAILER_PROFILE_URL;
      const trailerId = '55555';
      service.fetchTrailerDetails(trailerId).subscribe();
      mockBackend.expectOne({
        url: url + '55555',
        method: 'GET'
      });
    }));

    it('should call the service url for Mexico market if the market is set as mx', async(() => {
      envMock.market = 'mx';
      const trailerId = '55555';
      service.fetchTrailerDetails(trailerId).subscribe();
      mockBackend.expectOne(envMock.marketPrefix.toLowerCase() + TRAILER_PROFILE_URL + '55555');
    }));
    afterEach(() => {
      mockBackend.verify();
    });
    it('with success service response, result should be defined', async(() => {
      const url = envMock.marketPrefix.toLowerCase() + TRAILER_PROFILE_URL;
      const trailerId = '55555';
      service.fetchTrailerDetails(trailerId).subscribe(result => {
        expect(result).toBeDefined();
      });
      mockBackend
        .expectOne({
          url: url + '55555',
          method: 'GET'
        })
        .flush({ status: 200, response: 'success' });
    }));
    it('should call the toastr message service, for fetchTrailerDetails 500 response', async(() => {
      const url = envMock.marketPrefix.toLowerCase() + TRAILER_PROFILE_URL;
      const customErrorMessage = 'test';
      const trailerId = '55555';
      spyOn(toastrMessagesServiceMock, 'error').and.callThrough();
      service
        .fetchTrailerDetails(trailerId)
        .subscribe(
          () => fail('ObservableOf should not reach failure path'),
          () => expect(toastrMessagesServiceMock.error).toHaveBeenCalledWith(customErrorMessage)
        );

      mockBackend
        .expectOne({
          url: url + '55555',
          method: 'GET'
        })
        .flush({ errorMessage: 'Error' }, { status: 500, statusText: 'Server Error' });
    }));

    it('should call the toastr message service, for fetchTrailerDetails 502 response', async(() => {
      const url = envMock.marketPrefix.toLowerCase() + TRAILER_PROFILE_URL;
      const customErrorMessage = 'test';
      const trailerId = '55555';
      spyOn(toastrMessagesServiceMock, 'error').and.callThrough();
      service
        .fetchTrailerDetails(trailerId)
        .subscribe(
          () => fail('ObservableOf should not reach failure path'),
          () => expect(toastrMessagesServiceMock.error).toHaveBeenCalledWith(customErrorMessage)
        );
      mockBackend
        .expectOne({
          url: url + '55555',
          method: 'GET'
        })
        .flush({ errorMessage: 'Error' }, { status: 502, statusText: 'Server Error' });
    }));
    it('should call the toastr message service, for null response', async(() => {
      const url = envMock.marketPrefix.toLowerCase() + TRAILER_PROFILE_URL;
      const customErrorMessage = 'test';
      spyOn(toastrMessagesServiceMock, 'warning').and.callThrough();
      const trailerId = '55555';
      service.fetchTrailerDetails(trailerId).subscribe(result => {
        expect(toastrMessagesServiceMock.warning).toHaveBeenCalledWith(customErrorMessage);
      });
      mockBackend
        .expectOne({
          url: url + '55555',
          method: 'GET'
        })
        .flush(null);
    }));
  });
  describe('Update trailer Details', () => {
    it('with market specific url, should call the service url for US market', async(() => {
      const trailerReq = {} as Trailer;
      const trailerId = '55555';
      service.updateTrailerDetails({ trailer: trailerReq }, trailerId).subscribe();
      mockBackend.expectOne({
        url: envMock.marketPrefix.toLowerCase() + TRAILER_PROFILE_URL + trailerId,
        method: 'PUT'
      });
    }));

    it('should call the service url for Mexico market if the market is set as mx', async(() => {
      envMock.market = 'mx';
      const trailerReq = {} as Trailer;
      const trailerId = '55555';
      service.updateTrailerDetails({ trailer: trailerReq }, trailerId).subscribe();
      mockBackend.expectOne(envMock.marketPrefix.toLowerCase() + TRAILER_PROFILE_URL + trailerId);
    }));
    afterEach(() => {
      mockBackend.verify();
    });
    it('with success service response, result should be defined', async(() => {
      const url = envMock.marketPrefix.toLowerCase() + TRAILER_PROFILE_URL;
      const trailerReq = {} as Trailer;
      const trailerId = '55555';
      service.updateTrailerDetails({ trailer: trailerReq }, trailerId).subscribe(result => {
        expect(result).toBeDefined();
      });
      mockBackend
        .expectOne({
          url: url + trailerId,
          method: 'put'
        })
        .flush('');
    }));
    it('should call the toastr message service for updateTrailerDetails 500 response', async(() => {
      const customErrorMessage = 'test';
      const trailerReq = {} as Trailer;
      const trailerId = '55555';
      spyOn(toastrMessagesServiceMock, 'error').and.callThrough();
      service
        .updateTrailerDetails({ trailer: trailerReq }, trailerId)
        .subscribe(
          () => fail('ObservableOf should not reach failure path'),
          () => expect(toastrMessagesServiceMock.error).toHaveBeenCalledWith(customErrorMessage)
        );
      mockBackend
        .expectOne({
          method: 'put'
        })
        .flush({ errorMessage: 'Error' }, { status: 500, statusText: 'Server Error' });
    }));

    it('should call the toastr message service for updateTrailerDetails 200 response', async(() => {
      const customErrorMessage = 'test';
      const trailerReq = new AddTrailer();
      const trailerId = '55555';
      spyOn(toastrMessagesServiceMock, 'persistentSuccess').and.callThrough();
      service.updateTrailerDetails(trailerReq, trailerId).subscribe(result => {
        expect(toastrMessagesServiceMock.persistentSuccess).toHaveBeenCalledWith(
          customErrorMessage,
          'Success'
        );
      });
      mockBackend
        .expectOne({
          method: 'PUT'
        })
        .flush({ success: 'Success' });
    }));
    it('should call the toastr message service, for updateTrailerDetails 409 response', async(() => {
      spyOn(toastrMessagesServiceMock, 'error').and.callThrough();
      const customErrorMessage =
        'Input provided to update trailer is missing one or more mandatory fields.';
      const errorMessage = editTrailerDetails.EDIT_TRAILER_CONFLICT;
      const trailerReq = new AddTrailer();
      const trailerId = '55555';
      service
        .updateTrailerDetails(trailerReq, trailerId)
        .subscribe(
          () => fail('ObservableOf should not reach failure path'),
          () => expect(toastrMessagesServiceMock.error).toHaveBeenCalledWith(customErrorMessage)
        );
      mockBackend
        .expectOne({
          method: 'PUT'
        })
        .flush(errorMessage.error, { status: 409, statusText: 'Conflict' });
    }));
  });
  describe('Update trailerstatus', () => {
    it('with market specific url, should call the service url for US market', async(() => {
      const trailerReq = {} as TrailerStatusUpdateModel;
      service.updateTrailerStatusDetails(trailerReq).subscribe();
      mockBackend.expectOne({
        url: envMock.marketPrefix.toLowerCase() + TRAILER_UPDATE_URL,
        method: 'PUT'
      });
    }));

    it('should call the service url for Mexico market if the market is set as mx', async(() => {
      envMock.market = 'mx';
      const trailerReq = {} as TrailerStatusUpdateModel;
      service.updateTrailerStatusDetails(trailerReq).subscribe();
      mockBackend.expectOne(envMock.marketPrefix.toLowerCase() + TRAILER_UPDATE_URL);
    }));
    afterEach(() => {
      mockBackend.verify();
    });
    it('with success service response, result should be defined', async(() => {
      const url = envMock.marketPrefix.toLowerCase() + TRAILER_UPDATE_URL;
      const trailerReq = {} as TrailerStatusUpdateModel;
      service.updateTrailerStatusDetails(trailerReq).subscribe(result => {
        expect(result).toBeDefined();
      });
      mockBackend
        .expectOne({
          url: url,
          method: 'put'
        })
        .flush('');
    }));
    it('should call the toastr message service for updateTrailerStatusDetails 500 response', async(() => {
      const customErrorMessage = 'test';
      const trailerReq = {} as TrailerStatusUpdateModel;
      spyOn(toastrMessagesServiceMock, 'error').and.callThrough();
      service
        .updateTrailerStatusDetails(trailerReq)
        .subscribe(
          () => fail('ObservableOf should not reach failure path'),
          () => expect(toastrMessagesServiceMock.error).toHaveBeenCalledWith(customErrorMessage)
        );
      mockBackend
        .expectOne({
          method: 'put'
        })
        .flush({ errorMessage: 'Error' }, { status: 500, statusText: 'Server Error' });
    }));

    it('should call the toastr message service for updateTrailerStatusDetails 200 response', async(() => {
      const trailerReq = {} as TrailerStatusUpdateModel;
      spyOn(toastrMessagesServiceMock, 'persistentSuccess').and.callThrough();
      service.updateTrailerStatusDetails(trailerReq).subscribe(result => {
        expect(result).toBeDefined();
      });
      mockBackend
        .expectOne({
          method: 'PUT'
        })
        .flush({ success: 'success' });
    }));
  });
});
