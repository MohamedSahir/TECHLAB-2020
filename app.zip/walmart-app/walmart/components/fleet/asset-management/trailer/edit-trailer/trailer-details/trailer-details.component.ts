import { Component, Input, OnInit } from '@angular/core';
import { TrailerProfile } from '../../../../model';

@Component({
  selector: 'trailer-details',
  templateUrl: './trailer-details.component.html',
  styleUrls: ['./trailer-details.component.scss']
})
export class TrailerDetailsComponent implements OnInit {
  trailerProfileDetails: TrailerProfile;

  @Input()
  set trailerProfile(value) {
    if (value) this.trailerProfileDetails = value;
  }
  get trailerProfile() {
    return this.trailerProfileDetails;
  }

  // tslint:disable-next-line:no-empty
  ngOnInit() { }

}