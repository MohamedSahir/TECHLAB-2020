import { ViewEncapsulation } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrailerDetailsComponent } from './trailer-details.component';
declare var require: any;
const trailerProfileDetails = require('../../../../mock/trailer-profile-mock.data.json');

describe('TrailerDetailsComponent', () => {
  let component: TrailerDetailsComponent;
  let fixture: ComponentFixture<TrailerDetailsComponent>;
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TrailerDetailsComponent],
      schemas: [],
    })
      .overrideComponent(TrailerDetailsComponent, {
        set: {
          template: '<div></div>',
          encapsulation: ViewEncapsulation.Emulated
        }
      })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TrailerDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  afterAll(() => {
    component = null;
    fixture.destroy();
  });
  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should set the profiledata', () => {
    component.trailerProfile = trailerProfileDetails.trailerProfile;
    expect(component.trailerProfile).toBe(component.trailerProfileDetails);
  });
  it('should not bind the profile details if its null or undefined', () => {
    component.trailerProfile = undefined;
    expect(component.trailerProfileDetails).toBe(undefined);
  });
});