import { locationCommonConstants } from './../location-common/location-common.constants';
import { VendorAlignmentService } from './../services/vendor-alignement.services';
import { DatePipe } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// import { MatDialog } from '@angular/material';

// import { TranslateService } from '@ngx-translate/core';
// import { EnvService } from '@transom/services';
// import { Columns, SearchPanelComponent } from '@transom/ui';

import {
  VendorPreview,
 VendorResponsePreview,
 VendorStaticData,
  VendorStaticDataLocResponse,
  VendorStaticLocData
} from '../models';
import { DestinationValidator, OriginValidator, VendorNullValidator } from '../validators';
// import { gridColumns } from './vendor-alignment-column/intialize-columns';
import { dateFormat, gridValues } from '../location-common/vendor-alignment.constants';


@Component({
  selector: 'app-vendor-alignment',
  templateUrl: './vendor-alignment.component.html',
  styleUrls: ['./vendor-alignment.component.scss']
})
export class VendorAlignmentComponent implements OnInit {
  vendorFormGroup: FormGroup;
//  vendorPreviewData: VendorPreview;
  dateFormat: string;
 originLocTypes: VendorStaticData[];
   destinationLocTypes: VendorStaticData[];
   vendorStaticDataResponse: VendorStaticData[];
  countries: VendorStaticLocData[];
   states: VendorStaticDataLocResponse[];
   originStates: string[];
   destinationStates: string[];
  //  columns: Columns[];
   rows: VendorResponsePreview[];
   responseDataHandler: VendorResponsePreview[];
   vendorPreviewData: VendorPreview;
   displayedColumns: string[] = ['originLocationType'];
  constructor(
    // public dialog: MatDialog,
    // private translate: TranslateService,
     private vendorAlignmentService: VendorAlignmentService,
    // private envService: EnvService,
     private fb: FormBuilder,
    private datePipe: DatePipe
  ) {
    this.dateFormat = dateFormat.timeStamp;
  }

  private _market: any = 'us';
  get market(): any {
    return this._market;
  }
  set market(market: any) {
    this._market = market;
    this._marketPrefix = '/' + market;
  }

  private _marketPrefix = '/us';
  get marketPrefix(): string {
    return this._marketPrefix;
  }


  // OnInit method
  ngOnInit() {
    this.initializeForm();
     this.fetchStaticData();
    // this.setVendorGridProperties();
  }


 initializeForm() {
    this.vendorFormGroup = this.fb.group(
      {
        orLocType: [''],
        orLocId: ['', Validators.pattern('^[0-9]*$')],
        orLocState: [''],
        orLocCity: [''],
        deLocType: [''],
        deLocId: ['', Validators.pattern('^[0-9]*$')],
        deLocCity: [''],
        deLocState: [''],
        venderNumber: ['', Validators.pattern('^[0-9]*$')],
        venderAgreement: ['', Validators.pattern('^[0-9]*$')]
      },
      {
        validator: [
          VendorNullValidator.isVendorCriteriaNull,
          OriginValidator.originValidation,
          OriginValidator.originStateValidation,
          OriginValidator.originCityValidation,
          DestinationValidator.destinationValidation,
          DestinationValidator.destinationStateValidation,
          DestinationValidator.destinationCityValidation
        ]
      }
    );
  }




 mapValueToVendorPreviewModel(): void {
    this.vendorPreviewData = {
      oloctype: this.vendorFormGroup.value.orLocType,
      olocid: this.vendorFormGroup.value.orLocId,
      oloccity: this.vendorFormGroup.value.orLocCity,
      olocstate: this.vendorFormGroup.value.orLocState,
      dloctype: this.vendorFormGroup.value.deLocType,
      dlocid: this.vendorFormGroup.value.deLocId,
      dloccity: this.vendorFormGroup.value.deLocCity,
      dlocstate: this.vendorFormGroup.value.deLocState,
      vndrno: this.vendorFormGroup.value.venderNumber,
      vano: this.vendorFormGroup.value.venderAgreement
    };
  }







 // method to initialize static data
  fetchStaticData() {
    this.fetchVendorStaticData();
     this.fetchVendorLocationStaticData();
  }
//   // method to fetch vendor static data
  fetchVendorStaticData() {
    this.vendorAlignmentService
      .getVendorStaticDataService()
      .subscribe(this.vendorStaticdataSuccess);
  }

   // method to bind origin and destination type static data elements
   private vendorStaticdataSuccess = (response: VendorStaticData[]): void => {
    if (response) {
      console.log(response);
      this.vendorStaticDataResponse = response;
      this.setVendorStaticData();
    }
  };



  // method to fetch vendor location static data
  fetchVendorLocationStaticData() {
    this.vendorAlignmentService
      .getVendorStaticLocationDataService()
      .subscribe(this.locationStaticdataSuccess);
  }
    // method to bind location static data elements
  private locationStaticdataSuccess = (response: VendorStaticLocData[]): void => {
    this.setLocationStaticData(response);
  };
// method to bind location static data elements
  private setLocationStaticData(response: VendorStaticLocData[]): void {
    this.countries = response;
    console.log(response);
    this.loadStates(this._market.toUpperCase());
  }


//   // method to load States based on Country
  private loadStates = (value: string): void => {
    this.destinationStates = [];
    this.originStates = [];
    let selectedStates;
    if (this.countries) {
      selectedStates = this.countries.filter(state => state.countryCode === value)[0];
      if (selectedStates) {
        this.states = selectedStates.stateProvs;
        this.states.map(state => {
          this.destinationStates.push(state.stateProvCode);
          this.originStates.push(state.stateProvCode);
        });
      }
    }
  };

    // Set arrays which is used to populate the location Type dropdowns
  setVendorStaticData() {
    this.originStates = [];
    this.destinationLocTypes = [];
    this.originLocTypes = this.vendorStaticDataResponse.filter(
      item =>
        item.code.trim() === locationCommonConstants.locationTypeCode.vendor ||
        item.code.trim() === locationCommonConstants.locationTypeCode.centerPoint
    );
    this.destinationLocTypes = this.vendorStaticDataResponse.filter(
      item =>
        item.code.trim() === locationCommonConstants.locationTypeCode.centerPoint ||
        item.code.trim() === locationCommonConstants.locationTypeCode.disp ||
        item.code.trim() === locationCommonConstants.locationTypeCode.store ||
        item.code.trim() === locationCommonConstants.locationTypeCode.distributionCenter
    );
  }




  // Grid
//   // Search button click event
  viewVendordata(event: MouseEvent) {
    this.rows = [];
    this.mapValueToVendorPreviewModel();
    this.mapVendorParamsValue(this.vendorPreviewData);
    this.responseDataHandler = [];
  }
  // sets the params data which is used to pass to the fetch service
  mapVendorParamsValue(fetchValue: VendorPreview) {
    const paramObj = {};
    Object.keys(fetchValue).map(function(key) {
      if (fetchValue[key] && fetchValue[key] != null) paramObj[key] = fetchValue[key];
    });
    this.callVendorSearch(paramObj);
  }
  // service call to fetch the data based on search criteria
  callVendorSearch(fetchValue) {
    this.vendorAlignmentService.fetchVendorPreview(fetchValue).subscribe(this.previewDataSuccess);
  }
  // method to bind fetch request response
  private previewDataSuccess = (response: VendorResponsePreview[]): void => {
    if (response) {
      this.responseDataHandler = response;
      this.mapVendorPreview();
    }
  };

    // map vendor preview to bind the response to grid
  mapVendorPreview() {
    let vendorResponse: VendorResponsePreview[];
    vendorResponse = new Array<VendorResponsePreview>();
    let item: VendorResponsePreview;
    const date = this.datePipe;
    const dateFormating = dateFormat;
    this.responseDataHandler.map(function(previewItem) {
      item = new VendorResponsePreview();
      item.destLocCity = previewItem.destLocCity;
      item.destLocState = previewItem.destLocState;
      item.destLocationTypeAbbr = previewItem.destLocationTypeAbbr;
      item.destinationLocationId = previewItem.destinationLocationId;
      item.destinationLocationType = previewItem.destinationLocationType;
      item.effectiveDate = date.transform(previewItem.effectiveDate, dateFormating.date);
      item.expirationDate = date.transform(previewItem.expirationDate, dateFormating.date);
      item.lastChangeUserid = previewItem.lastChangeUserid;
      item.lastChangets = date.transform(previewItem.lastChangets, dateFormating.timeStamp);
      item.locationTypeAbbr = previewItem.locationTypeAbbr;
      item.origLocationTypeAbbr = previewItem.origLocationTypeAbbr;
      item.originLocCity = previewItem.originLocCity;
      item.originLocState = previewItem.originLocState;
      item.originLocationId = previewItem.originLocationId;
      item.originLocationType = previewItem.originLocationType;
      item.vendorNbr = previewItem.vendorNbr;
      item.vndrAgreementNbr = previewItem.vndrAgreementNbr;
      vendorResponse.push(item);
    });
    this.rows = vendorResponse;
    console.log(this.rows);
  }






}











//    method to initialize static data
//   fetchStaticData() {
//     this.fetchVendorStaticData();
//     this.fetchVendorLocationStaticData();
//   }


 // method to fetch vendor location static data
//   fetchVendorLocationStaticData() {
//     this.vendorAlignmentService
//       .getVendorStaticLocationDataService()
//       .subscribe(this.locationStaticdataSuccess);
//   }

   // method to bind location static data elements
//   private locationStaticdataSuccess = (response: VendorStaticLocData[]): void => {
//     this.setLocationStaticData(response);
//   };



