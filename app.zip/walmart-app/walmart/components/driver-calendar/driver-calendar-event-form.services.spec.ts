import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, getTestBed, TestBed } from '@angular/core/testing';
import { FormBuilder, FormGroup } from '@angular/forms';
import * as moment from 'moment-timezone';

import { DriverQueryStaticServiceMock, UserServiceMock } from '../../../../mock';
import { DriverQueryStaticService } from '../../../common-services';
declare var require: any;
import { UserService } from '@transom/services';
import { DriverCalendarEventFormService } from './driver-calendar-event-form.service';
const baseTerminalMockData = require('../../../../mock/json-files/baseTerminal.json');
const calendarEventMockData = require('../../../../mock/json-files/calendar-events.json');
const driverCalendarMockData = require('../../../../mock/json-files/driver-calendar-comment.json');
const driverCalendar = require('../../../../mock/json-files/driver-calendar.json')
\
describe('DriverCalendarEventFormService', () => {
    let driverCalendarEventFormService: DriverCalendarEventFormService;
    let driverQueryStaticServiceMock: DriverQueryStaticServiceMock;
    let userServiceMock: UserServiceMock;
    let form: FormGroup;
    beforeEach(async(() => {
        driverQueryStaticServiceMock = new DriverQueryStaticServiceMock();
        userServiceMock = new UserServiceMock();
        TestBed.configureTestingModule({
            providers: [{
                provide: DriverQueryStaticService, useValue: driverQueryStaticServiceMock
            },
            { provide: UserService, useValue: userServiceMock },
                DriverCalendarEventFormService, FormBuilder],
            imports: [HttpClientTestingModule]
        });
        driverCalendarEventFormService = getTestBed().get(DriverCalendarEventFormService);
    }));
    beforeEach(() => {
        form = driverCalendarEventFormService.intializeCalendarEventForm();
    });
    afterEach(() => {
        form.reset();
    });
    it('should intialize form', () => {
        expect(form).toBeDefined();
    });

    it('should get base terminal data on calling fetchBaseTerminalValues ', () => {
        driverCalendarEventFormService.fetchBaseTerminalValues().subscribe(response => {
            expect(response).toEqual(baseTerminalMockData);
        });

    });
    it('should get calendar event data and return filtered array ', () => {
        driverCalendarEventFormService.fetchCalendarEventTypes().subscribe(response => {
            expect(response.length).toEqual(2);
        });
    });
    it('should set location type to DC on setFormValues ', () => {
        driverCalendarEventFormService.setFormValues(driverCalendar, form, moment());
        expect(form.controls.locationType.value).toEqual("DC");
    })
    it('should set location id to null if dc id is not present ', () => {
        const eventForm = driverCalendarEventFormService.setFormValues(driverCalendar, form, moment());
        expect(eventForm.controls.locationId.value).toEqual(null);
    })
    it('should set location id to 4444 if dc id is present in event details', () => {
        driverCalendar.dcId = 4444;
        form = driverCalendarEventFormService.setFormValues(driverCalendar, form, moment());
        expect(form.controls.locationId.value).toEqual(4444);
    })


    it('should disable location id on set form values ', () => {
        form = driverCalendarEventFormService.setFormValues(driverCalendar, form, moment());
        expect(form.controls.locationId.disabled).toEqual(true);
    })
    it('should enable event type on set form values', () => {
        form = driverCalendarEventFormService.setFormValues(driverCalendar, form, moment());
        expect(form.controls.eventTypeCode.enabled).toEqual(true);
    })

    it('should set physical locationId to 145 on calling mapFormValues', () => {
        form.patchValue({
            beginDate: "Wed Nov 14 2018 00: 00: 00 GMT+0530(India Standard Time)",
            beginTime: "16:00",
            endDate: "Wed Nov 14 2018 00: 00: 00 GMT+0530(India Standard Time)",
            endTime: "16:00",
            eventTypeCode: "3",
            locationId: 145,
            locationType: "STORE",
        })
        const mappedValue = driverCalendarEventFormService.mapFormValues(form, calendarEventMockData, driverCalendar);
        expect(mappedValue.physicalLocation.locationId).toEqual(145);
    })
    it('should set fullDayEvent to true on calling mapFormValues', () => {
        form.patchValue({
            beginDate: "Wed Nov 14 2018 00: 00: 00 GMT+0530(India Standard Time)",
            beginTime: "16:00",
            endDate: "Wed Nov 14 2018 00: 00: 00 GMT+0530(India Standard Time)",
            endTime: "16:00",
            eventTypeCode: "3",
            locationId: 145,
            locationType: "STORE",
        })
        const mappedValue = driverCalendarEventFormService.mapFormValues(form, calendarEventMockData, driverCalendar);
        expect(mappedValue.fullDayEvent).toEqual(true);
    })
    it('should set beginTime to 08:00 on calling bindFormValues', () => {
        const event = driverCalendarMockData.eventDetails;
        driverCalendarEventFormService.bindFormValues(form, event);
        expect(form.controls.beginTime.value).toEqual("08:00 AM");
    });
    it('should set end date to driver calendar form on calling bindFormValues', () => {
        const event = driverCalendarMockData.eventDetails;
        driverCalendarEventFormService.bindFormValues(form, event);
        expect(form.controls.endDate.value).toEqual(moment("2018-11-02").toDate());
    });
    it('should set locationId to 6833 on calling bindFormValues', () => {
        const event = driverCalendarMockData.eventDetails;
        driverCalendarEventFormService.bindFormValues(form, event);
        expect(form.controls.locationId.value).toEqual(6833);
    })
    it('should enable end time  when event is partial day', () => {
        const event = driverCalendarMockData.eventDetails;
        event.CalendarEvent[0].fullDayEvent = false
        driverCalendarEventFormService.bindFormValues(form, event);
        expect(form.controls.endTime.enabled).toEqual(true);
    })
    it('should enable end time  when event is partial day', () => {
        const event = driverCalendarMockData.eventDetails;
        driverCalendarMockData.eventDetails.CalendarEvent[0].beginTs.timeStamp = "2018-11-01 12:00"
        event.CalendarEvent[0].fullDayEvent = false
        driverCalendarEventFormService.bindFormValues(form, event);
        expect(form.controls.beginTime.value).toEqual('00:00 PM');
    })
    it('should enable end time  when event is partial day', () => {
        const event = driverCalendarMockData.eventDetails;
        driverCalendarMockData.eventDetails.CalendarEvent[0].endTs.timeStamp = "2018-11-02 12:00"
        event.CalendarEvent[0].fullDayEvent = false
        driverCalendarEventFormService.bindFormValues(form, event);
        expect(form.controls.endTime.value).toEqual('00:00 PM');
    })
    describe('setValuesOnReasonChange', () => {
        it('should disable begin date if event type is full day  ', () => {
            const selectedDate = '2018-12-31 12:00 AM';
            driverCalendarEventFormService.setValuesOnReasonChange(driverCalendar, form, selectedDate, true);
            expect(form.controls.beginDate.disabled).toEqual(true)
        })
        // it('should set location id to  dc id if  driver has a dc id  ', () => {
        //     const selectedDate = '2018-12-31 12:00 AM';
        //     driverCalendar.dcId = 4444;
        //     driverCalendarEventFormService.setValuesOnReasonChange(driverCalendar, form, selectedDate, true);
        //     expect(form.controls.locationId.value).toEqual(4444)
        // })
        it('should set begin date value as selected date if event is full day', () => {
            const selectedDate = '2018-12-31 12:00 AM';
            driverCalendarEventFormService.setValuesOnReasonChange(driverCalendar, form, selectedDate, true);
            expect(form.controls.beginDate.value).toEqual(new Date("2018-12-31 12:00 AM"))
        })
        it('should set begin time value if event is full day', () => {
            const selectedDate = '2018-12-31 12:00 AM';
            driverCalendarEventFormService.setValuesOnReasonChange(driverCalendar, form, selectedDate, true);
            expect(form.controls.beginTime.value).toEqual('03:30 AM')
        })
        it('should set end time value if event is full day', () => {
            const selectedDate = '2018-12-31 12:00 AM';
            driverCalendarEventFormService.setValuesOnReasonChange(driverCalendar, form, selectedDate, true);
            expect(form.controls.endTime.value).toEqual('03:30 AM')
        })
        it('should set end date enabled  if event is full day', () => {
            const selectedDate = moment('2018-12-31');
            driverCalendarEventFormService.setValuesOnReasonChange(driverCalendar, form, selectedDate, true);
            expect(form.controls.endDate.enabled).toEqual(true);
        })
        it('should set end date  value if event is full day', () => {

            const selectedDate = '2018-12-31 12:00 AM';
            driverCalendarEventFormService.setValuesOnReasonChange(driverCalendar, form, selectedDate, true);
            expect(form.controls.endDate.value).toEqual(new Date("2019-01-01 12:00 AM"))
        })
        it('should set end time if selected date is work week end date', () => {
            const date = moment('2019-01-03 12:00 AM');
            driverCalendarEventFormService.setValuesOnReasonChange(driverCalendar, form, date, true);
            expect(form.controls.endTime.value).toEqual("05:30 PM")
        })

        it('should set end time when selected even type is partial day', () => {
            const selectedDate = moment('2018-12-31');
            driverCalendarEventFormService.setValuesOnReasonChange(driverCalendar, form, selectedDate, false);
            expect(form.controls.endTime.enabled).toEqual(true)
        })
        it('should set end date when selected even type is partial day', () => {
            const selectedDate = '2018-12-31 12:00 AM'
            driverCalendarEventFormService.setValuesOnReasonChange(driverCalendar, form, selectedDate, false);
            expect(form.controls.endDate.value).toEqual(new Date("2019-01-01 12:00 AM"))
        })
        it('should  enable begin time control if reason code is partial day', () => {
            const selectedDate = moment('2018-12-31');
            driverCalendarEventFormService.setValuesOnReasonChange(driverCalendar, form, selectedDate, false);
            expect(form.controls.beginTime.enabled).toEqual(true)
        })
        it('should set begin time to null if reason code is partial day', () => {
            const selectedDate = moment('2018-12-31');
            driverCalendarEventFormService.setValuesOnReasonChange(driverCalendar, form, selectedDate, false);
            expect(form.controls.beginTime.value).toEqual(null)
        })
        it('should set end date to work week end date if reason code is full day and selected date is work week end date', () => {
            const selectedDate = '2019-01-03 17:30'
            driverCalendarEventFormService.setValuesOnReasonChange(driverCalendar, form, selectedDate, true);
            expect(form.controls.endDate.value).toEqual(moment('2019-01-03 17:30').toDate())
        })
        it('should set end date to work week end date if reason code is partial day and selected date is work week end date', () => {
            const selectedDate = '2019-01-03 17:30'
            driverCalendarEventFormService.setValuesOnReasonChange(driverCalendar, form, selectedDate, false);
            expect(form.controls.endDate.value).toEqual(moment('2019-01-03 17:30').toDate())
        })
    })

    it('should return error location id is invalid', () => {
        form.get('locationId').setValue('6');
        form.get('locationType').setValue('DISP');
        driverCalendarEventFormService.checkLocationIdIsValid(form)
        expect(form.controls.locationId.errors).toEqual({ "invalidId": true });
    })

    it('should set error to end time control if total hours is more than 14', () => {
        form.controls.beginDate.setValue(moment("2018-12-12 12:00 AM").toDate())
        form.controls.endDate.setValue(moment("2018-12-13 12:00 AM").toDate());
        form.controls.beginTime.setValue("04:00")
        form.controls.endTime.setValue("04:15")
        driverCalendarEventFormService.partialDayTotalHours(form, driverCalendar.driverWorkWeeks, false);
        expect(form.controls.endTime.errors).toEqual([{ totalTimeError: true }])
    })
    it('should reset error to null if total hour is less than or equal to 14', () => {
        form.controls.beginDate.setValue(moment("2018-12-12 12:00 AM").toDate())
        form.controls.endDate.setValue(moment("2018-12-12 12:00 AM").toDate())
        form.controls.beginTime.setValue("04:00")
        form.controls.endTime.setValue("04:15")
        driverCalendarEventFormService.partialDayTotalHours(form, driverCalendar.driverWorkWeeks, true);
        expect(form.controls.endTime.errors).toEqual(null)
    })
    it('should set error if begin time is greater', () => {
        form.controls.beginDate.setValue(moment("2018-12-12 12:00 AM").toDate())
        form.controls.endDate.setValue(moment("2018-12-12 12:00 AM").toDate())
        form.controls.beginTime.setValue("04:15")
        form.controls.endTime.setValue("04:00")
        driverCalendarEventFormService.partialDayTotalHours(form, driverCalendar.driverWorkWeeks, false);
        expect(form.controls.endTime.errors).toEqual([{ timeGreater: true }])
    })
    it('should reset error to null for the control end time', () => {
        form.controls.beginDate.setValue(moment("2018-12-12 12:00 AM").toDate())
        form.controls.endDate.setValue(moment("2018-12-12 12:00 AM").toDate())
        form.controls.beginTime.setValue("04:00")
        form.controls.endTime.setValue("04:15")
        driverCalendarEventFormService.partialDayTotalHours(form, driverCalendar.driverWorkWeeks, true);
        expect(form.controls.endTime.errors).toEqual(null)
    })
    it('should set error to begin date if it is 12 months behind from current', () => {
        form.controls.beginDate.setValue(moment("2015-10-12 12:00 AM").toDate())
        form.controls.endDate.setValue(moment("2020-12-12 12:00 AM").toDate())
        form.controls.beginTime.setValue("04:00")
        form.controls.endTime.setValue("04:15")
        driverCalendarEventFormService.partialDayTotalHours(form, driverCalendar.driverWorkWeeks, true);
        expect(form.controls.beginDate.errors).toEqual({ monthsAhead: true })
    })
    it('should set error to end date if it is 12 months ahead from current', () => {
        form.controls.beginDate.setValue(moment("2020-12-12 12:00 AM").toDate())
        form.controls.endDate.setValue(moment("2020-12-12 12:00 AM").toDate())
        form.controls.beginTime.setValue("04:00")
        form.controls.endTime.setValue("04:15")
        driverCalendarEventFormService.partialDayTotalHours(form, driverCalendar.driverWorkWeeks, true);
        expect(form.controls.endDate.errors).toEqual([{ "endDateLess": true, "monthsBehind": true, "notInWorkWeek": true }])
    })
    it('should reset error to null for the control begin date', () => {
        form.controls.beginDate.setValue(moment("2018-12-12 12:00 AM").toDate())
        form.controls.endDate.setValue(moment("2018-12-12 12:00 AM").toDate())
        form.controls.beginTime.setValue("04:00")
        form.controls.endTime.setValue("04:15")
        driverCalendarEventFormService.partialDayTotalHours(form, driverCalendar.driverWorkWeeks, true);
        expect(form.controls.beginDate.errors).toEqual(null)
    })
    it('should set error for the control end time if wwk end date and wwk end date is same but time is invalid', () => {
        form.controls.beginDate.setValue(moment("2018-12-31 12:00 AM").toDate())
        form.controls.endDate.setValue(moment("2019-01-03").toDate())
        form.controls.beginTime.setValue("04:00")
        form.controls.endTime.setValue("04:15")
        driverCalendarEventFormService.partialDayTotalHours(form, driverCalendar.driverWorkWeeks, true);
        expect(form.controls.endTime.errors).toEqual([{ "wwkEndTimeErr": true }])
    })
    it('should set error for the control end time if wwk end date and wwk end date is same but time is invalid', () => {
        form.controls.beginDate.setValue(moment("2018-12-31 12:00 AM").toDate())
        form.controls.endDate.setValue(moment("2019-01-03").toDate())
        form.controls.beginTime.setValue("04:00")
        form.controls.endTime.setValue("05:30 PM")
        driverCalendarEventFormService.partialDayTotalHours(form, driverCalendar.driverWorkWeeks, true);
        expect(form.controls.endTime.errors).toEqual(null)
    })
    it('should set error for the control end date if wwk end date and wwk end date is same but time is invalid', () => {
        form.controls.beginDate.setValue(moment("2018-12-31 12:00 AM").toDate())
        form.controls.endDate.setValue(moment("2018-12-31").toDate())
        form.controls.beginTime.setValue("04:00")
        form.controls.endTime.setValue("05:30 PM")
        driverCalendarEventFormService.partialDayTotalHours(form, driverCalendar.driverWorkWeeks, true);
        expect(form.controls.endDate.errors).toEqual([{ 'endDateLess': true }])
    })
})
