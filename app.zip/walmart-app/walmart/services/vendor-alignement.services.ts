import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material';
import { Observable, throwError as observableThrowError } from 'rxjs';
import { catchError, finalize, tap } from 'rxjs/operators';

// import { TranslateService } from '@ngx-translate/core';
// import { EnvService } from '@transom/services';
// import { LoadingDialogComponent, ToastrService } from '@transom/ui';

// import {
//   locationStaticDataUrl,
//   vendorDataFetchUrl,
//   vendorStaticCountryUrl
// } from '../location-common/urls';
import {
  VendorResponsePreview,
  VendorStaticData,
 VendorStaticLocData
} from '../models';
// import { errors } from './vendor-alignment.constants';

@Injectable()
export class VendorAlignmentService {
  private dialogRef;
  constructor(
     private http: HttpClient,
    // private translate: TranslateService,
    // private toastrService: ToastrService,
    private dialog: MatDialog,
    // private envService: EnvService
  ) {}

  // Fetch the data based on the search criteria
  fetchVendorPreview(fetchCriteria): Observable<VendorResponsePreview[]> {
    const requestOptions = { params: fetchCriteria };
    // this.openLoaderDialog();
const  vendorDataFetchUrl = '../../assets/vendor-alignment-search.json'
    return this.http
      .get<VendorResponsePreview[]>(vendorDataFetchUrl,
        // this.envService.marketPrefix + vendorDataFetchUrl,
        requestOptions
      )
      .pipe(
        tap(response => {
          if (!response)
            // this.toastrService.error(this.translate.instant('VendorAlignment.NoRecordFound'));
          return response;
        }),
        catchError(error => this.handleError(error)),
        finalize(this.closeLoader)
      );
  }
  // Fetch the static data on service call
  getVendorStaticDataService(): Observable<VendorStaticData[]> {
    // this.openLoaderDialog();
  const locationStaticDataUrl = '../../assets/vendor-alignment-location.json';
    return this.http.get<VendorStaticData[]>(locationStaticDataUrl).pipe(
      catchError(error => this.handleError(error)),
      finalize(this.closeLoader)
    );
  }
  // Fetch the location specific data on service call
  getVendorStaticLocationDataService(): Observable<VendorStaticLocData[]> {
    // this.openLoaderDialog();
    const vendorStaticCountryUrl = '../../assets/vendor-alignment.json';
    return this.http.get<VendorStaticLocData[]>(vendorStaticCountryUrl).pipe(
      catchError(error => this.handleError(error)),
      finalize(this.closeLoader)
    );
  }


  private closeLoader = () => {
    // if (this.dialogRef && this.dialogRef.close) this.dialogRef.close();
  };


  private handleError(error): Observable<never> {
    let errMsg;
    // if (error instanceof HttpErrorResponse && error.status === errors.conflict)
    //   errMsg = error.statusText;
    // else errMsg = this.translate.instant('VendorAlignment.InternalServerError');
    // this.toastrService.error(errMsg);
    return observableThrowError(errMsg);
  }
//   private openLoaderDialog = () => {
//     setTimeout(() => {
//       this.closeLoader();
//       this.dialogRef = this.dialog.open(LoadingDialogComponent, {
//         data: this.translate.instant('Processing'),
//         disableClose: true,
//         panelClass: 'transom-loading-dialog'
//       })
//     }
//     );

//   };
}
