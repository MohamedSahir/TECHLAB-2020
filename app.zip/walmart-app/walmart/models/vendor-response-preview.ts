export class VendorResponsePreview {
  destLocCity: string;
  destLocState: string;
  destLocationTypeAbbr: string;
  destinationLocationId: number;
  destinationLocationType: string;
  effectiveDate: string;
  expirationDate: string;
  lastChangeUserid: string;
  lastChangets: string;
  locationTypeAbbr: string;
  origLocationTypeAbbr: string;
  originLocCity: string;
  originLocState: string;
  originLocationId: number;
  originLocationType: string;
  vendorNbr: string;
  vndrAgreementNbr: number;
}

