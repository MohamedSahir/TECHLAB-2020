export class VendorStaticStateData {
  stateProvCode: string;
  stateProvDesc: string;
  code: string;
  desc: string;
}
