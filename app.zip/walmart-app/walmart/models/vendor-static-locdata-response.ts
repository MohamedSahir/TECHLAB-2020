export class VendorStaticDataLocResponse {
  stateProvCode: string;
  stateProvDesc: string;
  code: string;
  desc: string;
}
