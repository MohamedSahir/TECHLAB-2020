export class VendorPreview {
  constructor(
    public oloctype: string,
    public olocid: number,
    public oloccity: string,
    public olocstate: string,
    public dloctype: string,
    public dlocid: number,
    public dloccity: string,
    public dlocstate: string,
    public vndrno: number,
    public vano: number
  ) {}
}
