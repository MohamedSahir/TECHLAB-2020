export class VendorStaticData {
  baseTerminalCode: string;
  baseTerminalCodeAbbr: string;
  baseTerminalDesc: string;
  code: string;
  desc: string;
}
