import { VendorStaticStateData } from './vendor-static-state';
export class VendorStaticLocData {
  countryCode: string;
  countryDesc: string;
  stateProvs: VendorStaticStateData[];
}
