
import { AbstractControl } from '@angular/forms';

import { VendorAgreementValidator } from './vendor-alignment.validator';
export class OriginValidator {
  // validating whether the origin type is passed along withorigin state/city
  static originValidation(control: AbstractControl) {
    const vendorObj = control.value;
    if (VendorAgreementValidator.vendorAgreementValidation(control))
      if (vendorObj.orLocType && (!vendorObj.orLocCity && !vendorObj.orLocState))
        if (!(vendorObj.deLocType && (vendorObj.deLocCity || vendorObj.deLocState))
          && VendorAgreementValidator.vendorCityStateValidation(control))
          return { requiredOriginAddionalCritera: true };
  }
  // validating whether the origin state is passed along withorigin type/city
  static originStateValidation(control: AbstractControl) {
    const vendorObj = control.value;
    if (VendorAgreementValidator.vendorAgreementValidation(control))
      if (vendorObj.orLocState && (!vendorObj.orLocCity && !vendorObj.orLocType))
        if (!(vendorObj.deLocType && (vendorObj.deLocCity || vendorObj.deLocState))
          && VendorAgreementValidator.vendorCityStateValidation(control))
          return { requiredOriginAddionalCritera: true };
  }
  // validating whether the origin city is passed along withorigin type/state
  static originCityValidation(control: AbstractControl) {
    const vendorObj = control.value;
    if (VendorAgreementValidator.vendorAgreementValidation(control))
      if (vendorObj.orLocCity && (!vendorObj.orLocState && !vendorObj.orLocType))
        if (!(vendorObj.deLocType && (vendorObj.deLocCity || vendorObj.deLocState))
          && VendorAgreementValidator.vendorCityStateValidation(control))
          return { requiredOriginAddionalCritera: true };
  }

}
