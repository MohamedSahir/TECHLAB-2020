import { AbstractControl } from '@angular/forms';

export class VendorAgreementValidator {
  // validating whether the origin type is passed along withorigin state/city
  static vendorAgreementValidation(control: AbstractControl) {
    const vendorObj = control.value;
    if (
      !vendorObj.deLocId &&
      !vendorObj.orLocId &&
      !vendorObj.venderAgreement &&
      !vendorObj.venderNumber
    ){
      return true;
    }
    else{
      return false;
    }
  }
  static vendorCityStateValidation(control: AbstractControl) {
    const vendorObj = control.value;
    if (
      !(vendorObj.orLocState && vendorObj.orLocCity) &&
      !(vendorObj.deLocState && vendorObj.deLocCity)
    ){
      return true;
    }
    else {
      return false;}

  }
}
