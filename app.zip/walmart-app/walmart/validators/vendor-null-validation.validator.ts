import { AbstractControl } from '@angular/forms';

export class VendorNullValidator {
  // Checking whether atleast one form control has a value
  static isVendorCriteriaNull(control: AbstractControl) {
    const values = Object.keys(control.value).filter(
      value => control.value[value] && control.value[value] != null
    );
    if (!values.length)  {
      return { requiredVendorCriteria: true };
    }
  }
}
