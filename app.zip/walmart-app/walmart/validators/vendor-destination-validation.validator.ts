import { AbstractControl } from '@angular/forms';

import { VendorAgreementValidator } from './vendor-alignment.validator';
export class DestinationValidator {
  // validating whether the destination type is passed along with destination state/city
  static destinationValidation(control: AbstractControl) {
    const vendorObj = control.value;
    if (VendorAgreementValidator.vendorAgreementValidation(control)) {
      if (vendorObj.deLocType && (!vendorObj.deLocCity && !vendorObj.deLocState)) {
        if (!(vendorObj.orLocType && (vendorObj.orLocCity || vendorObj.orLocState))
          && VendorAgreementValidator.vendorCityStateValidation(control)) {
          return { requiredDestinationAddionalCritera: true };
        }
      }
    }
  }
  // validating whether the destination state is passed along with destination type/city
  static destinationStateValidation(control: AbstractControl) {
    const vendorObj = control.value;
    if (VendorAgreementValidator.vendorAgreementValidation(control)) {
      if (vendorObj.deLocState && (!vendorObj.deLocCity && !vendorObj.deLocType)) {
        if (!(vendorObj.orLocType && (vendorObj.orLocCity || vendorObj.orLocState))
          && VendorAgreementValidator.vendorCityStateValidation(control)) {
          return { requiredDestinationAddionalCritera: true };
        }
      }
    }
  }



  // validating whether the destination city is passed along with destination state/type
  static destinationCityValidation(control: AbstractControl) {
  const vendorObj = control.value;
  if (VendorAgreementValidator.vendorAgreementValidation(control)) {
    if (vendorObj.deLocCity && (!vendorObj.deLocState && !vendorObj.deLocType)) {
      if (!(vendorObj.orLocType && (vendorObj.orLocCity || vendorObj.orLocState))
        && VendorAgreementValidator.vendorCityStateValidation(control)) {
        return { requiredDestinationAddionalCritera: true };
      }
    }

  }

}
}
