
export const locationCommonConstants = {
  contactNumberPreceder: '+',
  contactNumberSeparator: '-',
  contactNumberSpace: ' ',
  dateFormat: 'MM/dd/yyyy',
  languageCode: 'en-US',
  serviceRequest: {
    headers: {
      accept: { name: 'Accept', value: 'Application/json' },
      acceptLanguage: { name: 'Accept-Language', value: 'en-US' },
      contentType: { name: 'Content-Type', value: 'application/json' },
      countryCode: { name: 'countryCode', value: 'US' },
      languageCode: { name: 'languageCode', value: 'en-US' },
      userId: { name: 'userId', value: '' },
      userPrincipalName: { name: 'userPrincipalName', value: '' }
    }
  },
  locationTypeCode: {
    vendor: 'VNDR',
    baseVendor: 'BVNDR',
    carrierLocation: 'CRLOC',
    distributionCenter: 'DC',
    centerPoint: 'CP',
    disp: 'DISP',
    store: 'STORE'
  },
  language: {
    Default: 'en',
    English: 'en'
  },
  phoneTypes: {
    regular: 'R',
    speed: 'S',
    mobile: 'M',
    fax: 'F'
  },
  phoneExtensions: {
    extensionAbbr: 'x',
    extensionLiteral: ' Ext. '
  },
  validationRegEx: {
    zip: {
      us: '^\\d{5}$',
      canada: '^[a-zA-Z]\\d[a-zA-Z] [0-9][a-zA-Z][0-9]'
    }
  }
};

// export const readCapability: Capability = {
//   businessCatgDesc: 'Location Management',
//   capabilityDesc: 'Location  Read',
//   capabilityName: 'Location.Read'
// };

// export const writeCapability: Capability = {
//   businessCatgDesc: 'Location Management',
//   capabilityDesc: 'Location Write',
//   capabilityName: 'Location.Write'
// };

export const locationRegionConstants = {
  regionPickerType: 'locationtype',
  dateFormat: 'MM/DD/YYYY'
};
export const locationAlignmentCapability = {
  BussinussCategory: 'Location Alignment View',
  Read: { Name: 'LocationAlignment.Read', Desc: 'Location Alignment Read' },
  Write: { Name: 'LocationAlignment.Write', Desc: 'Location Alignment Write' }
};

export const regionCapability = {
  capabilityName: {
    alignmentView: 'Alignment.Read',
    alignmentWrite: 'Alignment.Write',
    alignmentAdd: 'Alignment.Add'
  },
  capabilityDesc: {
    alignmentView: 'Alignment Read',
    alignmentWrite: 'Alignment Write',
    alignmentAdd: 'Alignment Add'
  },
  businessCategory: 'Location Regional Query Operations'
};

export const DATE = {
  DateFormat: 'dd/mm/yyyy'
};

export const defaultGridProperties = {
  pageSize: 10,
  maxHeight: 500
};

export const errors = {
  internalServer: 500,
  notFound: 404,
  conflict: 409,
  badGateWay: 502,
  unavailable: 503
};
