export const vendorAlignmentCabpability = {
  capabilityName: {
    vendorAlignmentRead: 'Alignment.Read',
    vendorAlignmentWrite: 'Alignment.Write',
    vendorAlignmentAdmin: 'Alignment.Upload'
  },
  capabilityDesc: {
    vendorAlignmentView: 'Vendor Alignment - Read',
    vendorAlignmentWrite: 'Vendor Alignment - Write',
    vendorAlignmentAdmin: 'Vendor Alignment - Upload'
  },
  businessCategory: 'Vendor Alignment'
};
export const errors = {
  internalServer: 500,
  notFound: 404,
  conflict: 409,
  badGateWay: 502,
  unavailable: 503
};
export const gridValues = {
  pageSize: 10,
  gridHeight: 500
};
export const dateFormat = {
  timeStamp: 'MM/dd/yyyy HH:mm:ss',
  date: 'MM/dd/yyyy'
}
