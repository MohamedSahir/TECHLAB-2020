﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WE.PowerMarketing.WebApi.Models
{
    public class PowerBI
    {
        public string PositionGraphKey { get; set; }
        public List<int> PositionGraphValues { get; set;}
        public string DartSpreadKey { get; set; }
        public List<int> DartSpreadValues { get; set; }
        public string DartProfitLossKey { get; set; }
        public List<int> DartProfitLoss { get; set; }
    }
}