﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WE.PowerMarketing.WebApi.Models
{
    public class WidgetModel
    {
        public string EnergyType { get; set; }
        public int Value { get; set; }
    }
}