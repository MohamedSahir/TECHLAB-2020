﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WE.PowerMarketing.WebApi.Models
{
    public class UserPermission
    {
        public string EDSGroup { get; set; }
        public string UserID { get; set; }
        public string DisplayName { get; set; }
        public string Access { get; set; }
        public string Location { get; set; }
        public bool EnergyImbalance { get; set; }
        public bool StartorStopNotification { get; set; }
        public bool DemandBidVolumes { get; set; }
        public bool MarketData { get; set; }
        public bool RenewableEnergy { get; set; }
        public bool SettlementStatements { get; set; }
    }
    public class UserLocation
    {
        public string UserId { get; set; }
        public string Location { get; set; }
        public List<UserTab> UserTabs { get; set; }
    }
    public class UserTab
    {
        public string Node { get; set; }
        public string DisplayName { get; set; }
        public List<UserTag> UserTags { get; set; }
    }
    public class UserTag
    {
        public string Name { get; set; } 
    }
}