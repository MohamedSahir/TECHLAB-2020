﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WE.PowerMarketing.WebApi.Models
{
    public class Pitag
    {
        public string name { get; set; }
        public double? value { get; set; }
    }
}