﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WE.PowerMarketing.WebApi.Models;

namespace WE.PowerMarketing.WebApi.Controllers
{
    public class WidgetsController : ApiController
    {
        public IHttpActionResult GetWidgetData()
        {
            List<WidgetModel> wm = new List<WidgetModel>();
            string[] typeArray = { "Wind Energy", "Total Wind To Date", "Emission Energey" };
            Random r = new Random();
            for (int i = 0; i < 3; i++)
            {                
                WidgetModel wobj = new WidgetModel()
                {
                    EnergyType = typeArray[i],
                    Value = i == 1 ? r.Next(0, 1000) : r.Next(0, 60) 


                };
                wm.Add(wobj);
            }
            return Ok(wm);
        }
    }
}
