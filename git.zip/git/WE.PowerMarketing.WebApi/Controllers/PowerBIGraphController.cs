﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WE.PowerMarketing.DataAccess.DAL;
using WE.PowerMarketing.WebApi.Common;
using WE.PowerMarketing.WebApi.Models;
namespace WE.PowerMarketing.WebApi.Controllers
{
    [RoutePrefix("api/PowerBIGraph")]
    public class PowerBIGraphController : ApiController
    {


        [Route("GetDAData/{locationName}/{nodeName}")]
        public IHttpActionResult GetDAData(string locationName, string NodeName)
        {
            var getDAResponse = PowerBIRepository.GetNodes(locationName, NodeName);
            return Ok(getDAResponse);
        }
        [Route("GetPowerBIGraph")]
        public IHttpActionResult GetPowerBIGraph()
        {
            var getGraphValue = GetGraph();
            return Ok(getGraphValue);
        }

     
        public static PowerBI GetGraph()
        {
            PowerBI bi = new PowerBI();
            bi.PositionGraphValues = new List<int>();
            bi.PositionGraphKey = "Position:DA-RT";
            bi.DartSpreadKey = "DartSpread:RT-DA";
            bi.DartProfitLossKey = "DART:PROFIT/LOSS";
            bi.DartSpreadValues = new List<int>();
            bi.DartProfitLoss = new List<int>();
            try
            {
                bi.PositionGraphValues.Add(0);
                bi.PositionGraphValues.Add(0);
                bi.PositionGraphValues.Add(0);
                bi.PositionGraphValues.Add(0);
                bi.PositionGraphValues.Add(-10);
                bi.PositionGraphValues.Add(-5);
                bi.PositionGraphValues.Add(-10);
                bi.PositionGraphValues.Add(-5);
                bi.PositionGraphValues.Add(0);
                bi.PositionGraphValues.Add(5);
                bi.PositionGraphValues.Add(10);
                bi.PositionGraphValues.Add(10);
                bi.PositionGraphValues.Add(20);
                bi.PositionGraphValues.Add(10);
                bi.PositionGraphValues.Add(0);
                bi.PositionGraphValues.Add(-10);
                bi.PositionGraphValues.Add(-20);
                bi.PositionGraphValues.Add(-40);
                bi.PositionGraphValues.Add(-20);
                bi.PositionGraphValues.Add(-10);
                bi.PositionGraphValues.Add(0);
                bi.PositionGraphValues.Add(20);
                bi.PositionGraphValues.Add(10);
                bi.PositionGraphValues.Add(10);
                //bi.PositionGraphKey.Add("Position:DA-RT");

                bi.DartSpreadValues.Add(-7);
                bi.DartSpreadValues.Add(-7);
                bi.DartSpreadValues.Add(-7);
                bi.DartSpreadValues.Add(-6);
                bi.DartSpreadValues.Add(-6);
                bi.DartSpreadValues.Add(-6);
                bi.DartSpreadValues.Add(-4);
                bi.DartSpreadValues.Add(2);
                bi.DartSpreadValues.Add(5);
                bi.DartSpreadValues.Add(5);
                bi.DartSpreadValues.Add(6);
                bi.DartSpreadValues.Add(-1);
                bi.DartSpreadValues.Add(-5);
                bi.DartSpreadValues.Add(-5);
                bi.DartSpreadValues.Add(0);
                bi.DartSpreadValues.Add(-3);
                bi.DartSpreadValues.Add(4);
                bi.DartSpreadValues.Add(-3);
                bi.DartSpreadValues.Add(-2);
                bi.DartSpreadValues.Add(2);
                bi.DartSpreadValues.Add(0);
                bi.DartSpreadValues.Add(-1);
                bi.DartSpreadValues.Add(-1);
                bi.DartSpreadValues.Add(-1);

                // Dart  profit Loss
                // bi.DatrtSpreadKey.Add("DART:PROFIT/LOSS");

                bi.DartProfitLoss.Add(0);
                bi.DartProfitLoss.Add(0);
                bi.DartProfitLoss.Add(0);
                bi.DartProfitLoss.Add(0);
                bi.DartProfitLoss.Add(60);
                bi.DartProfitLoss.Add(30);
                bi.DartProfitLoss.Add(40);
                bi.DartProfitLoss.Add(-10);

                bi.DartProfitLoss.Add(0);
                bi.DartProfitLoss.Add(25);
                bi.DartProfitLoss.Add(60);
                bi.DartProfitLoss.Add(-10);
                bi.DartProfitLoss.Add(-100);
                bi.DartProfitLoss.Add(-50);
                bi.DartProfitLoss.Add(0);
                bi.DartProfitLoss.Add(30);
                bi.DartProfitLoss.Add(-80);
                bi.DartProfitLoss.Add(120);
                bi.DartProfitLoss.Add(40);
                bi.DartProfitLoss.Add(-20);
                bi.DartProfitLoss.Add(0);
                bi.DartProfitLoss.Add(-20);
                bi.DartProfitLoss.Add(-10);
                bi.DartProfitLoss.Add(-10);
            }

            catch (Exception ex)
            {


            }
            return bi;
        }



        [Route("GetSOAPData")]
        public IHttpActionResult GetSOAPData()
        {
            var soaUrl = "https://soadev.wr.com:443/soa-infra/services/EnergyMarketingServices/CMN_GetGenPISnapshot_ABCS_req/cmn_getgenpisnapshot_abcs_req_client_ep";
            //var soaUrl = "https://soadev.wr.com:443/soa-infra/services/EnergyMarketingServices/CMN_GetGenPISummary_ABCS_req/cmn_getgenpisummary_abcs_req_client_ep?wsdl";
            string isCacheRequired = ConfigurationManager.AppSettings["IsCacheRequired"];
            string requestXml = GetPISnapShot();
            if (!string.IsNullOrEmpty(requestXml))
            {
                var soaRequestXml = requestXml.Replace("{0}", isCacheRequired);
                var x = String.Empty;
                try
                {
                  x  = ServiceRoutine.CallWebService(soaUrl, "GET", null, soaRequestXml);
                }
                catch (Exception ex)
                {

                }
                return Ok(x);
            }
            return Ok();

        }



        [Route("GetPISummary")]
        public IHttpActionResult GetPISummary()
        {
          // var soaUrl = "https://soadev.wr.com:443/soa-infra/services/EnergyMarketingServices/CMN_GetGenPISnapshot_ABCS_req/cmn_getgenpisnapshot_abcs_req_client_ep?wsdl";
            var soaUrl = "https://soadev.wr.com:443/soa-infra/services/EnergyMarketingServices/CMN_GetGenPISummary_ABCS_req/cmn_getgenpisummary_abcs_req_client_ep?wsdl";
            string isCacheRequired = ConfigurationManager.AppSettings["IsCacheRequired"];
            string requestXml = GetPISummaryRequest();
            if (!string.IsNullOrEmpty(requestXml))
            {
                var soaRequestXml = requestXml.Replace("{0}", isCacheRequired);
                var x = String.Empty;
                try
                {
                    x = ServiceRoutine.CallWebService(soaUrl, "GET", null, soaRequestXml);
                }
                catch (Exception ex)
                {

                }
                return Ok(x);
            }
            return Ok();

        }



        public static string GetPISnapShot()
        {
            string requestXml = @"<soapenv:Envelope xmlns:soapenv=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:v1=""http://xmlns.westarenergy.com/CMN_GetPISnapshot/V1.0"" xmlns:v11=""http://xmlns.westarenergy.com/EBO/EnergyMarketing/V1.0"">
               <soapenv:Header/>
                <soapenv:Body>
                <v1:GetPISnapshotRequest>
                    <v1:SourceApplication>SPP</v1:SourceApplication>
                             <v1:UseCache>false</v1:UseCache>            
                                  <v1:DataPoints>                                  
                                        <v11:PIDataPoint>PI:ANALOG:SPA.PBL1______MW</v11:PIDataPoint>
                                              <v11:PIDataPoint>PI:ANALOG:SPA.PBL2______MW</v11:PIDataPoint>
                                                 </v1:DataPoints>
                                               </v1:GetPISnapshotRequest>
                                             </soapenv:Body>
                                           </soapenv:Envelope>";
                    return requestXml;
        }



        public static string GetPISummaryRequest()
        {
        string requestXml = @"<soapenv:Envelope xmlns:soapenv=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:v1=""http://xmlns.westarenergy.com/CMN_GetPISummary/V1.0"">
   <soapenv:Header/>
    <soapenv:Body>
        <v1:GetPISummaryRequest>
            <v1:SourceApplication>SPP</v1:SourceApplication>
                 <v1:UseCache>false</v1:UseCache>
                      <v1:DataPoints>
                            <v1:PISummaryDataRequest>
                                <v1:TimeRange>
                                     <v1:Start>2018-02-07T11:05:00:00-6:00</v1:Start>
                                                  <v1:End>*</v1:End>
                                                   </v1:TimeRange>                                   
                                                    <v1:Path>PI:PARAG_LMP_NP</v1:Path>
                                                         <v1:PISummaryManner Updates = ""false"" SummaryValue = ""Average"" Intervals = ""1""  WeightType = ""TimeWeighted"" UseStart = ""false"">
                                                                   </v1:PISummaryManner>
                                                                 </v1:PISummaryDataRequest>
                                                               </v1:DataPoints>
                                                             </v1:GetPISummaryRequest>
                                                           </soapenv:Body>
                                                         </soapenv:Envelope>";
            return requestXml;
        }








        }
}
