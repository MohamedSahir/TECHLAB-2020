﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web.Http;
using System.Xml;
using WE.PowerMarketing.BusinessLogic.BAL;
using WE.PowerMarketing.WebApi.Common;
using WE.PowerMarketing.WebApi.Models;

namespace WE.PowerMarketing.WebApi.Controllers
{
    [RoutePrefix("api/Dashboard")]
    public class DashboardController : ApiController
    {
        /// <summary>
        /// Gets All Dasboard Url list
        /// </summary>
        /// <returns>List of Dashboard Links</returns>
        public IHttpActionResult GetDashboardLinks(string name = "Priya")
        {
            if (name == "Priya")
                return Ok(DashboardBLL.GetAllLinks());
            else
                return Ok("Unsupported Parameter");
        }

        /// <summary>
        /// Get the Costs for All PRROP
        /// </summary>
        /// <returns>list of Cost</returns>
        public IHttpActionResult GetAllCosts()
        {
            return Ok(DashboardBLL.GetALLCosts());
        }
        public IHttpActionResult GetWindEnergy()
        {
            Random r = new Random();
            int rInt = r.Next(0, 40); //for ints

            return Ok(rInt + "%");
        }


        public IHttpActionResult GetArchive()
        {
            string xml = @"<soapenv:Envelope xmlns:soapenv=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:v1=""http://xmlns.westarenergy.com/CMN_GetPIArchive/V1.0"" xmlns:v11=""http://xmlns.westarenergy.com/EBO/EnergyMarketing/V1.0"" xmlns:pid=""http://xml.osisoft.com/services/PIDataService"">" +
   "<soapenv:Header/>" +
    "<soapenv:Body>" +
        "<v1:GetPIArchiveRequest>" +
               "<v1:SourceApplication >?</v1: SourceApplication>" +
                "<v1:UseCache>?</v1 : UseCache>" +
                   "<v1:DataPoints>" +
                        "<v11:PIDataPoint>" +
                             "<pid:PIArcDataRequest>" +
                                  "<pid:TimeRange>" +
                                       "<pid:Start> *</pid:Start>" +
                                               "<pid:End> *</pid:End>" +
                                                    "</pid:TimeRange>" +
                                                    "<pid:Path > PI:MOPEP_TEST_MW </ pid:Path>" +
                                                    "<pid:PIArcManner Updates = " + "false" + " RetrievalType = " + "Compresse" + "  NumValues = " + "400" + "  Boundaries = " + "Inside" + " >" +
                                                     "<pid:Filter>?</pid : Filter>" +
                                                    "<pid:TimeStep>?</pid : TimeStep>" +
                                                  "</pid:PIArcManner>" +
                                                "</pid:PIArcDataRequest>" +
                                              "</v11:PIDataPoint >" +
                                            "</v1:DataPoints>" +
                                          "</v1:GetPIArchiveRequest>" +
                                        "</soapenv:Body>" +
                                      "</soapenv:Envelope>";
            xml = xml.Trim().Replace("^([\\W]+)<", "<");
            string serviceUrl = "https://soadev.wr.com:443/soa-infra/services/EnergyMarketingServices/CMN_GetGenPIArchive_ABCS_req/cmn_getgenpiarchive_abcs_req_client_ep";
            var result = ServiceRoutine.CallWebService(serviceUrl, "GET", null, xml);

            //Rest Url
            //serviceUrl = "https://soadev.wr.com:443/soa-infra/resources/EnergyMarketingServices/CMN_GetGenPIArchive_ABCS_req/RestService/PI";
            //var data=JsonConvert.DeserializeObject<dynamic>(ServiceRoutine.GetJsonResponse(serviceUrl, "POST", null, null));
            return Ok("");

        }

       
        /// <summary>
      
        public IHttpActionResult GetPIData()
        {
           //return Ok("");
            string requiredkeys = Convert.ToString(ConfigurationManager.AppSettings["RequiredKeys"]);
            string[] keyarr = !string.IsNullOrEmpty(requiredkeys) ? requiredkeys.Split(',') : null;
            var res = ServiceRoutine.GetXmlResponse("http://gmsapp:5000/PIDataService", "GET");
            List<Pitag> pilist = new List<Pitag>();
            XmlDocument xmlDocument = new XmlDocument();
            xmlDocument.LoadXml(res);
            XmlNode node = xmlDocument.GetElementsByTagName("pidata").Item(0);
            //Loop through the child nodes
            foreach (XmlNode item in node.ChildNodes)
            {
                if (item.HasChildNodes)
                {
                    if (item.Name == "pitag")
                    {
                        if (item.ChildNodes.Count > 1)
                        {
                            Pitag tg = new Pitag();
                            tg.name = item.ChildNodes[0].InnerText;
                            tg.value = !string.IsNullOrEmpty(item.ChildNodes[1].InnerText) ? Convert.ToInt32(Math.Round(Convert.ToDouble(item.ChildNodes[1].InnerText.Replace("\r", "")))) : 0;
                            // Console.WriteLine("NodeValue = " + errorField2);
                            pilist.Add(tg);
                        }
                    }
                }
            }
            if (keyarr != null && keyarr.Length > 0)
            {
                pilist = pilist.Where(x => keyarr.Contains(x.name)).ToList();
            }
            return Ok(pilist);
        }
    }

}
