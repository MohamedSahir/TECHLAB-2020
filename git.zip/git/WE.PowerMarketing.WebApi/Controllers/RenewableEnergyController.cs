﻿using NLog;
using System;
using System.Collections.Generic;
using System.Web.Http;
using WE.PowerMarketing.WebApi.Common;
using WE.PowerMarketing.WebApi.Models;


namespace WE.PowerMarketing.WebApi.Controllers
{
   
    [RoutePrefix("api/RenewableEnergy")]
    public class RenewableEnergyController : ApiController
    {
        private static Logger logger = LogManager.GetLogger("LoggerName");
        //public EnergyCaching _getCache = null;
        public CachingService _getCache = null;
        public RenewableEnergyController()
        {
            _getCache = new CachingService();
        }

        #region GetRenewableEnergy
        /// <summary>
        ///For getting Renewable Energy Values 
        /// </summary>
        /// <returns>returns  a list of  Energy value</returns>
        public IHttpActionResult GetRenewableEnergy()
        {
            var getCaching = new List<Pitag>();
            try
            {
                getCaching = _getCache.getCachedData();
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message);
            }
            return Ok(getCaching);
        }
        #endregion   
    }
}