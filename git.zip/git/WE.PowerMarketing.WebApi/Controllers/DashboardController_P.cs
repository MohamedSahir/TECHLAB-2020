﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Http;
using System.Xml;
using WE.PowerMarketing.BusinessLogic.BAL;
using WE.PowerMarketing.WebApi.Common;

namespace WE.PowerMarketing.WebApi.Controllers
{
    public class Dashboard1Controller : ApiController
    {
        /// <summary>
        /// Gets All Dasboard Url list
        /// </summary>
        /// <returns>List of Dashboard Links</returns>
        public IHttpActionResult GetDashboardLinks(string name = "Priya")
        {
            if (name == "Priya")
                return Ok(DashboardBLL.GetAllLinks());
            else
                return Ok("Unsupported Parameter");
        }

        /// <summary>
        /// Get the Costs for All PRROP
        /// </summary>
        /// <returns>list of Cost</returns>
        public IHttpActionResult GetAllCosts()
        {
            return Ok(DashboardBLL.GetALLCosts());
        }
        public IHttpActionResult GetWindEnergy()
        {
            Random r = new Random();
            int rInt = r.Next(0, 40); //for ints

            return Ok(rInt + "%");
        }
        public IHttpActionResult GetArchive()
        {
            string xml = @"<?xml version=""1.0"" encoding=""utf-8""?>
            
            < soap:Envelope xmlns:soap = ""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"">
            < soap:Body >
            < HelloWorld3 xmlns = ""http://tempuri.org/"">
            < parameter1 > test </ parameter1 >
            < parameter2 > 23 </ parameter2 >
            < parameter3 > test </ parameter3 >
            </ HelloWorld3 >
            </ soap:Body >
            </ soap:Envelope > ";

            string serviceUrl = "https://soadev.wr.com:443/soa-infra/services/EnergyMarketingServices/CMN_GetGenPISnapshot_ABCS_req/cmn_getgenpisnapshot_abcs_req_client_ep";
            var result =ServiceRoutine.CallWebService(serviceUrl, "GET", null, null);

            //Rest Url
            serviceUrl = "https://soadev.wr.com:443/soa-infra/resources/EnergyMarketingServices/CMN_GetGenPIArchive_ABCS_req/RestService/PI";
            var data=JsonConvert.DeserializeObject<dynamic>(ServiceRoutine.GetJsonResponse(serviceUrl, "POST", null, null));
            return Ok("");

        }
       
    }
}
