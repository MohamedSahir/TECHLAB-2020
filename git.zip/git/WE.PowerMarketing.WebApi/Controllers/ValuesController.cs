﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Xml.Linq;
using WE.PowerMarketing.DataAccess.Models;
using WE.PowerMarketing.WebApi.Models;

namespace WE.PowerMarketing.WebApi.Controllers
{
    // [Authorize]
    public class ValuesController : ApiController
    {
        // GET api/values
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/values/5
        public string Get(int id)
        {
            return "value";
        }

        // POST api/values
        public void Post([FromBody]string value)
        {
        }

        // PUT api/values/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        public void Delete(int id)
        {
        }
        //GET UserAccess/values
        public UserLocation GetUserAccess(string uid)
        {
            List<UserLocation> ul = GetUserAccessFromDBXml();
            var uobj = ul != null && ul.Count() > 0 && !string.IsNullOrEmpty(uid) ? ul.Where(x => x.UserId == uid).FirstOrDefault() : new UserLocation();
            return uobj;
        }
        //GET UserAccessByLocation/values
        public UserLocation GetUserAccessByLocation(string location)
        {
            List<UserLocation> ul = GetUserAccessFromDBXml();
           // List<UserLocation> ul = GetUserAccessFromDB();
            var uobj = ul != null && ul.Count() > 0 && !string.IsNullOrEmpty(location) ? ul.Where(x => x.Location == location).FirstOrDefault() : new UserLocation();
            return uobj;
        }
        //GET UserAccess by XML 
        private List<UserLocation> GetUserAccessFromDBXml()
        {
            using (GMSEntities1 dbContext = new GMSEntities1())
            {
                var xmldata = dbContext.EMA_ConfigTbl.Where(x => x.Group_Type == "UserAccess").Select(s => s.XML).FirstOrDefault();
                // var maps1 = from c in XElement.Load(System.Web.Hosting.HostingEnvironment.MapPath("~/XmlFile/UserAccess.xml")).Elements("UserAccess")
                //  select c;
                //var xmldata = dbContext.EMA_ConfigTbl.Where(x => x.Group_Type == "UserAccess").Select(s => s.XML).FirstOrDefault();
                var maps1 = from c in XElement.Parse(xmldata).Elements("UserAccess")
                            select c;
                List<UserLocation> ul = new List<UserLocation>();
                foreach (var item in maps1)
                {
                    UserLocation ulobj = new UserLocation();
                    ulobj.UserTabs = new List<UserTab>();
                    //ulobj.UserId = item.Element("UserID").Value;
                    ulobj.Location = item.Element("Location").Value;
                    var tabs = from ch in item.Descendants("Tabs").Descendants("Tab")
                               select ch;
                    foreach (var tab in tabs)
                    {
                        UserTab ut = new UserTab()
                        {
                            Node = tab.Element("Node").Value,
                            DisplayName = tab.Element("DisplayName").Value
                        };
                        var tags = from ch in tab.Descendants("Tags").Descendants("Tag")
                                   select ch;
                        ut.UserTags = new List<UserTag>();
                        foreach (var tag in tags)
                        {
                            UserTag utobj = new UserTag()
                            {
                                Name = tag.Element("Name").Value
                            };
                            ut.UserTags.Add(utobj);
                        }
                        ulobj.UserTabs.Add(ut);
                    }
                    ul.Add(ulobj);
                }
                return ul;
            }
        }

        private List<UserLocation> GetUserAccessFromDB()
        {
            using (GMSEntities1 dbCOntext = new GMSEntities1())
            {
                List<UserLocation> usl = new List<UserLocation>();
                var locations = dbCOntext.GmsGTr_T_LocationTabMapping.ToList();
                var tabobj = dbCOntext.GmsGTr_T_TabMapping.ToList();
                var tagobj = dbCOntext.GmsGTr_T_Tags.ToList();
                foreach (var lm in locations)
                {
                UserLocation ul = new UserLocation();
                    ul.Location = lm.LocationName;
                    var tabids = !string.IsNullOrEmpty(lm.TabIds) ? lm.TabIds.Split(',').Select(i => int.Parse(i)).ToArray() : null;
                    ul.UserTabs = tabobj.Where(x => tabids.Contains(x.Id)).AsEnumerable().Select(s=>GetUserTabMapping(s)).ToList();
                    usl.Add(ul);
                }
                return usl;
            }
        }
        private static UserTab GetUserTabMapping(GmsGTr_T_TabMapping s)
        {
            using (GMSEntities1 dbContext = new GMSEntities1()) {
                UserTab ut = new UserTab();
                ut.DisplayName = s.TabName;
                ut.Node = s.TabName;
                var tags = !string.IsNullOrEmpty(s.TagIds) ? s.TagIds.Split(',').Select(i => int.Parse(i)).ToArray() : null;
                ut.UserTags = dbContext.GmsGTr_T_Tags.Where(x => tags.Contains(x.Id)).AsEnumerable().Select(uut => new UserTag()
                {
                    Name = uut.TagName
                }).ToList();
                return ut;
            }
        }
    }

}
