﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web.Http;
using System.Xml;
using WE.PowerMarketing.WebApi.Common;
using WE.PowerMarketing.WebApi.Models;

namespace WE.PowerMarketing.WebApi.Common
{
    public class EnergyCaching
    {
        private Pitag pitags = null;
        List<Pitag> piList = null;
        List<Pitag> totalwindData = null;
        List<Pitag> renewableEnergy = null;
        public EnergyCaching()
        {
            pitags = new Pitag();
            piList = new List<Pitag>();
            totalwindData = new List<Pitag>();
            renewableEnergy = new List<Pitag>();
        }
        public List<Pitag> getCachedData()
        {
            try
            {
                var windEmissionData = String.Empty;
                string soaUrl = ConfigurationManager.AppSettings["ServiceURL"];
                int windEmissionExpTime = Convert.ToInt32(ConfigurationManager.AppSettings["WindEmissionExpTime"]);
                string isCacheRequired = ConfigurationManager.AppSettings["IsCacheRequired"];
                int totalwindExpTime = Convert.ToInt32(ConfigurationManager.AppSettings["TotalWindExpTime"]);
                var hastotalWindValue = ConfigurationManager.AppSettings["TotalWindValue"];
                if (!string.IsNullOrEmpty(hastotalWindValue))
                {
                    double? totalwindValue = Convert.ToDouble(ConfigurationManager.AppSettings["TotalWindValue"]);
                    totalwindData.Add(new Pitag() { name = "Total wind energy to date", value = totalwindValue });
                }
                string requestXml = DataCacher.getSoA();
                if (!string.IsNullOrEmpty(requestXml))
                {
                    var soaRequestXml = requestXml.Replace("{0}", isCacheRequired);
                    try
                    {
                        windEmissionData = ServiceRoutine.CallWebService(soaUrl, "GET", null, soaRequestXml);
                        XmlDocument xmlDocument = new XmlDocument();
                        xmlDocument.LoadXml(windEmissionData);
                        XmlNode node = xmlDocument.GetElementsByTagName("tns:DataPointValues").Item(0);
                        //Loop through the child nodes
                        foreach (XmlNode item in node.ChildNodes)
                        {
                            if (item.Name == "ns3:PIDataPointValue")
                            {
                                Pitag tg = new Pitag();
                                tg.name = !string.IsNullOrEmpty(Convert.ToString(item.Attributes["Path"])) ? item.Attributes["Path"].Value : null;
                                tg.value = !string.IsNullOrEmpty(item.InnerText) ? Math.Round(Convert.ToDouble(item.InnerText.Replace("\r", ""))) : 0;
                                piList.Add(tg);
                            }
                        }
                    }
                    catch (Exception ex)
                    {

                    }
                }

                if (piList != null && piList.Count > 0 || totalwindData != null && totalwindData.Count > 0)
                {
                    if(piList != null)
                    {
                        var windemissionToken = DataCacher.AddCacheValue("windemission-token", piList, DateTimeOffset.UtcNow.AddMinutes(windEmissionExpTime));
                    }
                    if (totalwindData != null)
                    {
                        var totalwindToken = DataCacher.AddCacheValue("totalwind-token", totalwindData, DateTimeOffset.UtcNow.AddMinutes(totalwindExpTime));
                    }
                }
                if (piList == null || piList.Count == 0)
                {
                    var getwindemissionCacheData = DataCacher.GetCacheValue("windemission-token") as List<Pitag>;
                    var getTotalWindCacheData = DataCacher.GetCacheValue("totalwind-token") as List<Pitag>;
                    List<Pitag> addCacherList = new List<Pitag>();
                    if (getwindemissionCacheData != null && getwindemissionCacheData.Count > 0 && getTotalWindCacheData != null && getTotalWindCacheData.Count > 0)
                    {
                        addCacherList.AddRange(getwindemissionCacheData);
                        addCacherList.AddRange(getTotalWindCacheData);
                        return addCacherList;
                    }
                    else if (getTotalWindCacheData != null && getwindemissionCacheData == null)
                    {
                        addCacherList.AddRange(getTotalWindCacheData);
                        return addCacherList;
                    }
                    else if (getTotalWindCacheData == null && getwindemissionCacheData != null || getwindemissionCacheData.Count > 0)
                    {
                        addCacherList.AddRange(getwindemissionCacheData);
                        return addCacherList;
                    }
                }
               
                renewableEnergy.AddRange(piList);
                renewableEnergy.AddRange(totalwindData);        
            }

            catch (Exception ex)
            {

            }
            return renewableEnergy;

        }

    }
}