﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace WE.PowerMarketing.WebApi.Common
{
    public class ServiceRoutine
    {
        /// <summary>
        ///For Soap Services
        /// </summary>
        /// <param name="url"></param>
        /// <param name="method"></param>
        /// <param name="operation"></param>
        /// <param name="xmlPayload"></param>
        /// <returns></returns>
        public static string CallWebService(string url, string method, string operation, string xmlPayload)
        {
          
            string URL_ADDRESS = url;  //TODO: customize to your needs
                                       // ===== You shoudn't need to edit the lines below =====
            
            string username = "PM-RED", psw = "5qwV#33#opT$PMd";
            HttpWebRequest request = WebRequest.Create(new Uri(URL_ADDRESS)) as HttpWebRequest;
            request.Proxy.Credentials = new NetworkCredential(username, psw);
            Uri uri = new Uri(url);
            //var networkCredentials = request.Credentials.GetCredential(uri, "Basic");
            byte[] credentialBuffer = new UTF8Encoding().GetBytes(username + ":" + psw);

            // Create the web request

            // Set type to POST
            request.ContentType = "text/xml;charset=\"utf-8\"";
            request.Accept = "text/xml";
            request.Headers["Authorization"] = "Basic " + Convert.ToBase64String(credentialBuffer);
            request.Headers.Add(@"SOAPAction","");
            request.Method = "POST";
            // Create the data we want to send
            StringBuilder data = new StringBuilder();
            data.Append(xmlPayload);
            byte[] byteData = Encoding.UTF8.GetBytes(data.ToString());      // Create a byte array of the data we want to send
                                                                      
            XmlDocument SOAPReqBody = new XmlDocument();
            try
            {
                SOAPReqBody.LoadXml(xmlPayload);
                using (Stream stream = request.GetRequestStream())
                {
                    SOAPReqBody.Save(stream);
                }
                //Geting response from request  
                using (WebResponse Serviceres = request.GetResponse())
                {
                    using (StreamReader rd = new StreamReader(Serviceres.GetResponseStream()))
                    {
                        //reading stream  
                       return rd.ReadToEnd();
                        //writting stream result on console  

                    }
                }
            }
            catch (Exception ex)
            {
                //TODO: returns an XML with the error message
            }
            return "Inavlid Data";
        }

        public static string GetJsonResponse(string url, string method, Object reqObj, string wrapperText)
        {
            var URL = url;
            JavaScriptSerializer js = new JavaScriptSerializer();
            string DATA = JsonConvert.SerializeObject(reqObj, new JsonSerializerSettings { DateFormatHandling = DateFormatHandling.MicrosoftDateFormat, DateTimeZoneHandling = DateTimeZoneHandling.RoundtripKind });
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL);
            request.Method = method;


            if (method == "POST")
            {
                request.ContentType = "application/json; charset=utf-8";
                request.ContentLength = DATA.Length;

                using (Stream webStream = request.GetRequestStream())
                using (StreamWriter requestWriter = new StreamWriter(webStream, System.Text.Encoding.ASCII))
                {
                    requestWriter.Write(DATA);
                }
            }

            try
            {
                WebResponse webResponse = request.GetResponse();
                using (Stream webStream = webResponse.GetResponseStream())
                {
                    if (webStream != null)
                    {
                        using (StreamReader responseReader = new StreamReader(webStream))
                        {
                            string response = responseReader.ReadToEnd();

                            try
                            {
                                if (!string.IsNullOrWhiteSpace(wrapperText))
                                {
                                    var root = JObject.Parse(response);
                                    JToken result = root[wrapperText];
                                    try
                                    {
                                        JToken.Parse(result.ToString());
                                        return result.ToString();
                                    }
                                    catch
                                    {
                                        return JsonConvert.SerializeObject(result);
                                    }
                                }
                                else
                                {
                                    JToken.Parse(response);
                                    return response;
                                }
                            }
                            catch
                            {
                                if (response == string.Empty)
                                    response = null;
                                return JsonConvert.SerializeObject(response);
                            }


                        }
                    }
                }
            }
            catch (Exception)
            {
                return JsonConvert.SerializeObject(null);
            }

            return JsonConvert.SerializeObject(null);

        }


        public delegate void GetJsonResponse_Delegate(string url, string method, Object reqObj, string wrapperText);

        public static bool ServiceRequestOnly(string url, string method, Object reqObj, string wrapperText)
        {
            GetJsonResponse_Delegate md = new GetJsonResponse_Delegate(RequestOnly);
            if (md.BeginInvoke(url, method, reqObj, wrapperText, null, null) == null)
                return false;
            return true;
        }

        public static void RequestOnly(string url, string method, Object reqObj, string wrapperText)
        {
            var resp = GetJsonResponse(url, method, reqObj, wrapperText);
        }

        public static string GetXmlResponse(string url,string method)
        {
            HttpWebRequest webrequest = (HttpWebRequest)WebRequest.Create(url);
            webrequest.Method = "POST";
            webrequest.ContentType = "application/xml";
            webrequest.ContentLength = 0;
            Stream stream = webrequest.GetRequestStream();
            stream.Close();
            string result;
            using (WebResponse response = webrequest.GetResponse())
            {
                using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                {
                    result = reader.ReadToEnd();
                }
            }
            return result;
        }
       
    }
}