﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Caching;
using System.Xml;
using NLog;

namespace WE.PowerMarketing.WebApi.Common
{
    public static class DataCacher
    {
     
            private static Logger logger = LogManager.GetLogger("LoggerName");
            public static object GetCacheValue(string key)
            {
                MemoryCache memoryCache = MemoryCache.Default;
                return memoryCache.Get(key);
            }
            public static bool AddCacheValue(string key, object value, DateTimeOffset absExpiration)
            {            
                MemoryCache memoryCache = MemoryCache.Default;
                CacheItemPolicy policy = new CacheItemPolicy();
                policy.AbsoluteExpiration = absExpiration;
                logger.Info(key + "\t :Cache Expire Time is : \t" + policy.AbsoluteExpiration);
                return memoryCache.Add(key, value, policy.AbsoluteExpiration);

            }
            public static void DeleteCacheValue(string key)
            {
                MemoryCache memoryCache = MemoryCache.Default;
                if (memoryCache.Contains(key))
                {
                    memoryCache.Remove(key);
                }
            }
            public static string getSoA()
            {
                string requestXml = @"<soapenv:Envelope xmlns:soapenv=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:v1=""http://xmlns.westarenergy.com/CMN_GetPISnapshot/V1.0"" xmlns:v11=""http://xmlns.westarenergy.com/EBO/EnergyMarketing/V1.0"">
                <soapenv:Header/>
                <soapenv:Body>
                <v1:GetPISnapshotRequest>
                <v1:SourceApplication>SPP</v1:SourceApplication>,
                <v1:UseCache>{0}</v1:UseCache>
                    <v1:DataPoints>
                        <v11:PIDataPoint>PI:ANALOG:LOADS.EMISSFREEPMW</v11:PIDataPoint>
                        <v11:PIDataPoint>PI:ANALOG:LOADS.RENEWGEN_PMW</v11:PIDataPoint>
                    </v1:DataPoints>
                </v1:GetPISnapshotRequest>
                </soapenv:Body>
                </soapenv:Envelope>";
                return requestXml;
            }

        }

        }
    