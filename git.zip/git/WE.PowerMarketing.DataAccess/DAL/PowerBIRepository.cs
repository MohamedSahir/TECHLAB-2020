﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WE.PowerMarketing.DataAccess.Models;

namespace WE.PowerMarketing.DataAccess.DAL
{
    public class PowerBIRepository
    {
        private static GMSEntities1 _dbContext = new GMSEntities1();
        public PowerBIRepository()
        {

        }
        public static List<sp_getRealNodes_Result> GetNodes(string AssetOwnerName, string nodeName)
        {

            string GeneratorName = !string.IsNullOrEmpty(nodeName) ? nodeName : "";
            var result = _dbContext.sp_getRealNodes(AssetOwnerName, GeneratorName).ToList();
            return result;

        }
    }
}
