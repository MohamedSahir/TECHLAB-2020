﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WE.PowerMarketing.Common.Entities;
using WE.PowerMarketing.DataAccess.Models;

namespace WE.PowerMarketing.DataAccess.DAL
{
   public class DashboardDataAccess
    {
        public static List<DashboardLinks> GetAllDashboardLInks()
        {
            using (GMSEntities1 dbContext =new GMSEntities1())
            {
                List<DashboardLinks> urlList= dbContext.T_Web_Dash_WebAppDashboardLinks.ToList().AsEnumerable().Select(s => GetEntityToAdapter(s)).ToList();
                return urlList;
            }
        }

        public static List<PRRORCostss> GetCosts()
        {
            using (GMSEntities1 dbContext =new GMSEntities1())
            {

                List<PRRORCostss> costsList = dbContext.T_MMDD_PPROR_COST.ToList().AsEnumerable().Select(s => GetEntityCostToAdapter(s)).ToList();
                return costsList;
            }
        }

        public static PRRORCostss GetEntityCostToAdapter(T_MMDD_PPROR_COST c)
        {
            return new PRRORCostss()
            {
                MMDD_COST_B_CondensingLoad=c.MMDD_COST_B_CondensingLoad,
                MMDD_COST_B_CondOperStartCost=c.MMDD_COST_B_CondOperStartCost,
                MMDD_COST_B_CondOperVom=c.MMDD_COST_B_CondOperVom,
                MMDD_COST_B_MinEconCapLimitInput=c.MMDD_COST_B_MinEconCapLimitInput,
                MMDD_COST_B_NoLoadVom=c.MMDD_COST_B_NoLoadVom,
                MMDD_COST_B_NoLoadVomUnits=c.MMDD_COST_B_NoLoadVomUnits,
                MMDD_COST_B_ShutdownFuelHot=c.MMDD_COST_B_ShutdownFuelHot,
                MMDD_COST_B_StAddLaborCostOffPkCold=c.MMDD_COST_B_StAddLaborCostOffPkCold,
                MMDD_COST_B_StAddLaborCostOffPkHot=c.MMDD_COST_B_StAddLaborCostOffPkHot,
                MMDD_COST_B_StAddLaborCostOffPkIntermediate=c.MMDD_COST_B_StAddLaborCostOffPkIntermediate,
                MMDD_COST_B_StAddLaborCostOnPkCold=c.MMDD_COST_B_StAddLaborCostOnPkCold,
                MMDD_COST_B_StAddLaborCostOnPkHot=c.MMDD_COST_B_StAddLaborCostOnPkHot,
                MMDD_COST_B_StAddLaborCostOnPkIntermediate=c.MMDD_COST_B_StAddLaborCostOnPkIntermediate,
                MMDD_COST_B_StartFuelCold=c.MMDD_COST_B_StartFuelCold,
                StartFuelHot=c.MMDD_COST_B_StartFuelHot,
             

            };
        }
        public static DashboardLinks GetEntityToAdapter(T_Web_Dash_WebAppDashboardLinks s)
        {
            return new DashboardLinks()
            {
                WGroupAccess=s.Web_Dash_B_GroupAccess,
                Url=s.Web_Dash_B_Url,
                UrlDescription=s.Web_Dash_B_UrlDescription,
                UrlTitle=s.Web_Dash_B_UrlTitle,
                CreateUser=s.Web_Dash_M_CreateUser,
                Percentage="50%"
            };
        }
    }

}
