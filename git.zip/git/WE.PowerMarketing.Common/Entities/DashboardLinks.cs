﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WE.PowerMarketing.Common.Entities
{
    public class DashboardLinks
    {
        public string WGroupAccess { get; set; }
        public string Url { get; set; }
        public string UrlTitle { get; set; }
        public string UrlDescription { get; set; }
        public System.DateTimeOffset CreateDttmCpt { get; set; }
        public string CreateUser { get; set; }
        public string Percentage { get; set; }
        public System.DateTimeOffset UpdateDttmCpt { get; set; }
        public string UpdateUser { get; set; }
    }
    public class PRRORCostss
    {

        public long MMDD_P_Cost_Id { get; set; }
        public long MMDD_F_Unit_Id { get; set; }
        public long MMDD_M_AsOfDttmUtc { get; set; }
        public decimal StartFuelHot { get; set; }
        public decimal MMDD_COST_B_StartFuelIntermediate { get; set; }
        public decimal MMDD_COST_B_StartFuelCold { get; set; }
        public decimal MMDD_COST_B_ShutdownFuelHot { get; set; }
        public decimal MMDD_COST_B_StationServiceHot { get; set; }
        public decimal MMDD_COST_B_StationServiceIntermediate { get; set; }
        public decimal MMDD_COST_B_StationServiceCold { get; set; }
        public decimal MMDD_COST_B_StationServiceRate { get; set; }
        public decimal MMDD_COST_B_StartVomHot { get; set; }
        public decimal MMDD_COST_B_StartVomIntermediate { get; set; }
        public decimal MMDD_COST_B_StartVomCold { get; set; }
        public decimal MMDD_COST_B_StAddLaborCostOnPkHot { get; set; }
        public decimal MMDD_COST_B_StAddLaborCostOnPkIntermediate { get; set; }
        public decimal MMDD_COST_B_StAddLaborCostOnPkCold { get; set; }
        public decimal MMDD_COST_B_StAddLaborCostOffPkHot { get; set; }
        public decimal MMDD_COST_B_StAddLaborCostOffPkIntermediate { get; set; }
        public decimal MMDD_COST_B_StAddLaborCostOffPkCold { get; set; }
        public decimal MMDD_COST_B_SupAddLaborCost { get; set; }
        public decimal MMDD_COST_B_CondOperStartCost { get; set; }
        public decimal MMDD_COST_B_CondOperVom { get; set; }
        public decimal MMDD_COST_B_CondensingLoad { get; set; }
        public decimal MMDD_COST_B_MinEconCapLimitInput { get; set; }
        public decimal MMDD_COST_B_NoLoadVom { get; set; }
        public string MMDD_COST_B_NoLoadVomUnits { get; set; }
        public System.DateTimeOffset MMDD_M_CreateDttm { get; set; }
        public string MMDD_M_CreateUser { get; set; }
    }
}
