﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WE.PowerMarketing.Common.Entities;
using WE.PowerMarketing.DataAccess.DAL;
namespace WE.PowerMarketing.BusinessLogic.BAL
{
    public class DashboardBLL
    {
        public static List<DashboardLinks> GetAllLinks()
        {
            return DashboardDataAccess.GetAllDashboardLInks();
        }
        public static List<PRRORCostss> GetALLCosts()
        {
            return DashboardDataAccess.GetCosts();

            
        }
    }
}
